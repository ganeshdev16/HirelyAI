import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';

import {RootStackScreenProps} from '../../types/navigation';
import {
  fetchEditedJobList,
  getUserData,
  removeEditJobDetail,
  reviewRequest,
} from '../../services/api';
import {useAuth} from '../../context/AuthContext';
import Loader from '../../components/Loader';
import {ActivityIndicator} from 'react-native-paper';
import GlobalSettingsModal from '../../components/LocationModal';

const RequestScreen = ({
  navigation,
}: Readonly<RootStackScreenProps<'RequestScreen'>>) => {
  const [isLoading, setIsLoading] = useState(false);
  const [userEmail, setUserEmail] = useState<{[key: string]: string}>({});
  const [loadingJobs, setLoadingJobs] = useState<{[key: string]: boolean}>({});

  const handleMarkAsDone = async (job_id: string) => {
    setLoadingJobs(prev => ({...prev, [job_id]: true}));
    try {
      const response = await reviewRequest(job_id);
      if (response.message === 'success') {
        const removejob = await removeEditJobDetail(job_id);
        if (removejob.message && removejob.message.includes('success')) {
          // Remove the specific job that was marked as done
          setjobs(prevJobs => prevJobs.filter(job => job.job_id !== job_id));
        }
      }
    } catch (error) {
      console.error('Error marking job as done:', error);
      // Optionally show an error message to the user
    } finally {
      setLoadingJobs(prev => ({...prev, [job_id]: false}));
    }
  };

  const [jobs, setjobs] = useState<
    {
      id: string;
      updatedAt: string;
      propertyAddress: string;
      job_id: string;
      user_id: string;
      status: string;
      user_name: string;
    }[]
  >([]);
  const {userId} = useAuth();

  useEffect(() => {
    setIsLoading(true);
    const fetchJobs = async () => {
      try {
        const result = await fetchEditedJobList(userId);
        // Filter for active jobs when initially fetching
        const activeJobs =
          result.data?.filter((job: any) => job.status === 'active') || [];
        setjobs(activeJobs);
        console.log('CC', result);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchJobs();
  }, [userId]);

  function formatDate(dateString: string): string {
    if (!dateString.endsWith('Z') && !dateString.includes('+')) {
      dateString += 'Z'; // treat as UTC
    }
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      hour: 'numeric',
      minute: 'numeric',
      timeZone: 'America/New_York',
      hour12: true,
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };

    return date.toLocaleString('en-US', options);
  }

  const currentDateTime = new Date().toLocaleString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Image
          source={require('../../assets/images/redline-logo.png')}
          resizeMode="contain"
        />
      </View>
      <View style={styles.requestContainer}>
        <Text style={styles.requestText}>Requests</Text>
      </View>
      <Text style={styles.currentDate}>{currentDateTime}</Text>
      <ScrollView style={styles.scrollViewContainer}>
        {isLoading && <Loader size="large" text="Loading Request" />}
        {!isLoading && jobs.length === 0 && (
          <View style={styles.emptyContainer}>
            <AntDesign name="download" size={64} color="#787878" />
            <Text style={styles.emptyText}>No requests available</Text>
          </View>
        )}
        {jobs.map(item => (
          <View key={item.id} style={styles.requestCard}>
            <Entypo
              style={styles.warningIcon}
              name="warning"
              size={32}
              color="#FFC107"
            />

            <Text style={styles.cardTitle}>Job Update Request</Text>
            <Text style={styles.cardText}>
              <Text style={styles.bold}>
                Guard Name: {item.user_name || 'Loading...'}
              </Text>
            </Text>
            <Text style={styles.cardText}>
              <Text style={styles.bold}>Time:</Text>
              {formatDate(item.updatedAt)}
            </Text>
            <Text style={styles.cardText}>
              <Text style={styles.bold}>Location:</Text> {item.propertyAddress}
            </Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleMarkAsDone(item.job_id)}>
              {loadingJobs[item.job_id] ? (
                <ActivityIndicator size="small" color="#000" />
              ) : (
                <Text style={styles.buttonText}>Mark as Done</Text>
              )}
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
      <GlobalSettingsModal />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 18,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    alignContent: 'center',
  },

  logo: {
    height: 30,
    width: 120,
  },
  requestContainer: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginBottom: 16,
  },
  requestText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 20,
  },
  requestCard: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: '#090909',
    borderRadius: 16,
    paddingHorizontal: 16,
    padding: 16,
    marginBottom: 16,
    gap: 4,
  },
  currentDate: {
    paddingHorizontal: 16,
    color: '#aaa',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  cardText: {
    fontSize: 14,
    color: '#ccc',
    marginBottom: 8,
  },
  bold: {
    fontWeight: 'bold',
    color: '#fff',
  },
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 16,
    paddingVertical: 10,
    paddingHorizontal: 16,
    width: 157,
    marginTop: 16,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  scrollViewContainer: {
    paddingHorizontal: 16,
    paddingVertical: 24,
  },
  warningIcon: {
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
});

export default RequestScreen;
