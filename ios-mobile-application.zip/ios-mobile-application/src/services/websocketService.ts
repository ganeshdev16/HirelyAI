import {LocationDetails} from '../types/location';

interface WebSocketConfig {
  url: string;
}

let wsInstance: WebSocket | null = null;
let lastUpdateTime = 0;
const UPDATE_INTERVAL = 10000; // 10 seconds
const MAX_RECONNECT_ATTEMPTS = 5;
let reconnectAttempts = 0;

export const websocketService = {
  init: ({url}: WebSocketConfig) => {
    if (wsInstance?.readyState === WebSocket.OPEN) {
      return;
    }
    console.log(url);
    wsInstance = new WebSocket(url);

    wsInstance.onopen = () => {
      console.log('WebSocket Connected');
      reconnectAttempts = 0;
    };

    wsInstance.onclose = () => {
      console.log('WebSocket Disconnected');
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        setTimeout(() => websocketService.init({url}), 3000);
      }
    };

    wsInstance.onerror = error => {
      console.error('WebSocket Error:', error);
    };
  },

  sendLocation: (location: LocationDetails, shiftId: string) => {
    const currentTime = Date.now();
    console.log('Sending location and shiftId:', location, shiftId);

    // Check if enough time has passed since last update
    if (currentTime - lastUpdateTime < UPDATE_INTERVAL) {
      return;
    }

    if (wsInstance?.readyState === WebSocket.OPEN) {
      const payload = {
        action: 'updateLocation',
        shift_id: shiftId,
        latitude: location.latitude,
        longitude: location.longitude,
        timestamp: new Date().toISOString(),
      };
      console.log(payload);

      wsInstance.send(JSON.stringify(payload));
      lastUpdateTime = currentTime;
    }
  },

  disconnect: () => {
    if (wsInstance) {
      wsInstance.close();
      wsInstance = null;
    }
    lastUpdateTime = 0;
  },

  isConnected: () => {
    return wsInstance?.readyState === WebSocket.OPEN;
  },
};
