import axios from 'axios';
import {shiftData} from '../types/shift';
export const SIGNUP_ENDPOINT = '/signup';
export const LOGIN_ENDPOINT = '/loginCognito';
export const FORGOT_PASSWORD_ENDPOINT = '/forgotPasswordOtp';
export const FORGOT_PASSWORD_UPDATE = '/forgotPasswordUpdate';
export const VERIFY_EMAIL = '/verifyEmail';
export const JOB_DETAILS = '/jobDetails';
export const UPDATE_STEPS = '/updateSteps';
export const Fetch_Job_List = '/fetchJobList';
export const INCIDENT_REPORT = '/incidentReport';
export const LOGIN_WITH_TOKEN = '/refreshtokenlogin';
export const RESEND_OTP = '/resendOtp';
export const START_SHIFT_ENDPOINT = '/startShift';
export const VALIDATE_ACCES_TOKEN = '/validateAccessToken';
export const REFRESH_TOKEN = '/refreshToken';
export const UPLOAD_IMAGE_ENDPOINT = '/insertImage';
export const UPDATE_FCM_TOKEN = '/updateFCMToken';
export const Emergency_991_CallAlert = '/911CallAlert';
export const GET_SPECIFIC_JOBDETAIL = '/getSpecificJobDetail';
export const STORE_EDITED_DETAILS = '/storeEditedUserDetails';
export const REVIEW_REQUEST = '/userEditRequest';
export const FETCH_EDITED_JOB = '/fetchEditedJobDetail';
export const EDIT_JOB_BY_MANAGER = '/editJobDetailByManager';
export const DELETE_EDITED_JOB = '/removeEditedDetail';
export const GET_USER_DATA = '/getUserData';
export const DELETE_JOB = '/deleteJob';
export const SHIFT_CHECK = '/shiftCheck';
export const checking_report = '/checkingreport';
export const END_SESSION = '/endSession';
export const INSERT_IMAGE_TO_SHIFT = '/insertImageToShift';
export const GET_SHIFT_IMAGE = '/getShiftImages';
export const STORE_LOGS = '/storeShiftLogs';
export const GET_HOMEBASE_LOCATION = '/getHomeBaseLocation';
export const DELETE_NOTIFICATION = '/deleteNotification';
const FETCH_NOTIFICATION = '/fetchNotification';
export const PDF_GENERATOR = '/pdfGenerator';
export const GET_USER_HOMEBASE_LOCATION = 'getUserLocation';
const GET_INCIDENT_NOTIFICATION = '/fetchIncidentNotificationManager';
const FETCH_ADMIN_JOB_LIST = '/fetchAllLocation';
const FETCH_TAMPA_LOCATION = '/fetchTampaLocation';
const FETCH_NJ_LOCATION = '/fetchNewJerseyLocation';

const api = axios.create({
  baseURL: 'https://lnj3544yvk.execute-api.us-east-1.amazonaws.com/prod',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const signUp = async (userData: {
  email: string;
  password: string;
  role: string;
  location: string;
}) => {
  console.log(api.getUri());
  try {
    const response = await api.post(SIGNUP_ENDPOINT, userData);
    return response.data;
  } catch (error: any) {
    if (error.response) {
      const apiError = new Error(
        error.response.data?.message || 'Request failed',
      );
      (apiError as any).status = error.response.status;
      (apiError as any).response = error.response;
      (apiError as any).data = error.response.data;
      throw apiError;
    } else if (error.request) {
      const networkError = new Error('Network error');
      (networkError as any).status = null;
      throw networkError;
    } else {
      throw error;
    }
  }
};

export const signIn = async (credentials: {
  email: string;
  password: string;
}) => {
  try {
    const response = await api.post(LOGIN_ENDPOINT, credentials);
    console.log(response);
    return response.data;
  } catch (error) {
    console.log(error);
    throw error;
  }
};

export const forgotPasswordOtp = async (email: string) => {
  try {
    const response = await api.post(FORGOT_PASSWORD_ENDPOINT, {email});
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const forgotPasswordUpdate = async (
  email: string,
  otp: string,
  newPassword: string,
) => {
  try {
    const response = await api.post(FORGOT_PASSWORD_UPDATE, {
      email,
      otp,
      newPassword,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const verifyEmail = async (payload: {
  email: string;
  confirmationCode: string;
}) => {
  try {
    const response = await api.post(VERIFY_EMAIL, payload);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const jobDetails = async (payload: {
  propertyName: string;
  propertyAddress: string;
  propertyManagerName: string;
  propertyManagerPhone: string;
  buildingNo: string;
  gateAccess?: string;
  gateAccessrestroom?: string;
  latitude?: number;
  longitude?: number;
  managerId: string | null;
  homebaselocationId: any;
}) => {
  try {
    const response = await api.post(JOB_DETAILS, payload);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const submitIncidentReport = async (payload: {
  incident_title: string;
  description: string;
  incident_type: string;
  date: string;
  time: string;
  location: string;
  user_id: string;
  shift_id: string;
  othertype: string;
}) => {
  try {
    const response = await api.post(INCIDENT_REPORT, payload, {
      headers: {
        Authorization: '',
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const fetchJobList = async (locationId: any) => {
  try {
    const response = await api.post(Fetch_Job_List, {locationId: locationId});
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const updateSteps = async (payload: {
  shiftId: string;
  steps: number;
}) => {
  try {
    const response = await api.post(UPDATE_STEPS, payload);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const resendOtp = async (email: string) => {
  try {
    const response = await api.post(RESEND_OTP, {email});
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const startShift = async (shift: shiftData) => {
  try {
    const response = await api.post(START_SHIFT_ENDPOINT, shift);
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const ValidateAccesToken = async (token: string | null) => {
  try {
    const response = await api.post(VALIDATE_ACCES_TOKEN, {
      access_token: token,
    });

    return response.data;
  } catch (error) {
    return null;
  }
};
export const refreshAccessToken = async (token: string | null) => {
  try {
    const response = await api.post(REFRESH_TOKEN, {refresh_token: token});
    return response.data;
  } catch (error) {
    return null;
  }
};

export const getPresignedUrl = async (shiftId: string) => {
  try {
    const response = await api.post(UPLOAD_IMAGE_ENDPOINT, {shift_id: shiftId});
    const data = await response.data;
    return {
      uploadURL: data.uploadURL,
      Key: data.Key,
      fullURL: `https://redline-firewatch.s3.amazonaws.com/${data.Key}`, // Add full URL
    };
  } catch (error) {
    console.error('Error fetching presigned URL:', error);
    throw new Error('Failed to get pre-signed URL');
  }
};
export const uploadToS3 = async (uploadUrl: string, imageBlob: Blob) => {
  try {
    const response = await fetch(uploadUrl, {
      method: 'PUT',
      headers: {'Content-Type': 'image/jpeg'},
      body: imageBlob,
    });

    if (!response.ok) {
      throw new Error('Image upload failed');
    }
    return true;
  } catch (error) {
    console.error('Error uploading image to S3:', error);
    throw new Error('Failed to upload image to S3');
  }
};
export const submitValidationData = async (
  shiftId: string,
  imageKeys: string[],
) => {
  try {
    const response = await api.post(UPLOAD_IMAGE_ENDPOINT, {
      shift_id: shiftId,
      images: imageKeys,
    });

    if (!response.data) {
      throw new Error('Validation submission failed');
    }

    return response.data;
  } catch (error) {
    console.error('Error submitting validation data:', error);
    throw new Error('Failed to submit validation data');
  }
};

export const updateFCMToken = async (credentials: {
  email: string;
  fcmToken: string;
}) => {
  try {
    const response = await api.post(UPDATE_FCM_TOKEN, credentials);
    console.log(response);
    return response.data;
  } catch (error) {
    console.log(error);
    throw error;
  }
};

export const getSpecificJobDetail = async (job_id?: string) => {
  try {
    const response = await api.post(GET_SPECIFIC_JOBDETAIL, {job_id: job_id});
    return response.data;
  } catch (error) {
    return null;
  }
};
export const storeEditedJobDetail = async (payload: any) => {
  try {
    const response = await api.post(STORE_EDITED_DETAILS, payload);
    return response.data;
  } catch (error) {
    console.log(error);
    throw error;
  }
};
export const reviewRequest = async (job_id: string) => {
  try {
    const response = await api.post(REVIEW_REQUEST, {job_id: job_id});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const fetchEditedJobList = async (managerId: any) => {
  try {
    const response = await api.post(FETCH_EDITED_JOB, {managerId: managerId});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const managerEditJobDetail = async (payload: any) => {
  try {
    const response = await api.post(EDIT_JOB_BY_MANAGER, payload);
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const removeEditJobDetail = async (job_id: string) => {
  try {
    const response = await api.post(DELETE_EDITED_JOB, {job_id});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const getUserData = async (user_id: string) => {
  try {
    const response = await api.post(GET_USER_DATA, {user_id});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const deleteJobByManager = async (id: string) => {
  try {
    const response = await api.post(DELETE_JOB, {id});
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const emergency911CallAlert = async (credentials: {
  sender_id: string;
  sender_name: string;
  recepient_id: string;
  shift_id: string;
  status: string;
}) => {
  try {
    console.log('Sending 911 alert with credentials:', credentials);
    const response = await api.post(Emergency_991_CallAlert, credentials);
    console.log(response);
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const checkShiftStatus = async (userId: any) => {
  try {
    const response = await api.post(SHIFT_CHECK, {
      userId: userId,
    });

    const data = response.data;
    return data;
  } catch (error) {
    console.error('Error checking shift status:', error);
    throw error;
  }
};
export const checkingreport = async (credentials: {
  shiftId: string;
  managerId: string | null;
}) => {
  try {
    const response = await api.post(checking_report, credentials);
    return response.data;
  } catch (error) {
    console.log(error);
    throw error;
  }
};
export const insertImageToShift = async (
  shiftId: string,
  images: {imageUrl: string; timeOfTaken: string}[],
) => {
  try {
    const payload = {
      shiftId,
      images,
    };

    const response = await api.post(INSERT_IMAGE_TO_SHIFT, payload);

    const data = response.data;
    console.log('Successfully inserted images:', data);

    return data;
  } catch (error) {
    console.error('Error inserting images to shift:', error);
    throw error;
  }
};
export const getShiftImage = async (shiftId: string) => {
  try {
    const response = await api.post(
      GET_SHIFT_IMAGE,
      {shiftId},
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    return response.data; // Returns the full response.data
  } catch (error) {
    throw error; // Let the caller handle the error
  }
};
export const storeFireWatchLogs = async (
  shiftId: string,
  logs: {
    name: string;
    isAllClear: boolean;
    note: string;
    starttime: string;
    endtime: string;
  },
) => {
  try {
    const payload = {
      shiftId,
      log: logs,
    };

    const response = await api.post(STORE_LOGS, payload);

    const data = response.data;
    console.log('Successfully inserted logs:', data);

    return data;
  } catch (error) {
    console.error('Error storing logs:', error);
    throw error;
  }
};

export const endSession = async (shiftId: string, endTime: string) => {
  try {
    const response = await api.post(END_SESSION, {
      shiftId,
      endTime,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

interface PdfGeneratorPayload {
  shiftId: string;
  jobData: any;
  mapImage?: string | null;
  totalDistance?: number;
  userId: string;
}

export const pdfGenerator = async (
  shiftId: string,
  jobData: any,
  mapImage: string | null = null,
  totalDistance: number | null = null,
  userId: string | null = null,
) => {
  try {
    const payload: PdfGeneratorPayload = {
      shiftId,
      jobData,
      userId: userId || '',
    };

    if (mapImage) {
      payload.mapImage = mapImage;
      console.log('Including map image in PDF generation request');
    }
    if (totalDistance !== null) {
      payload.totalDistance = totalDistance;
      console.log(
        'Including total distance in PDF generation request:',
        totalDistance,
      );
    }

    const response = await api.post(PDF_GENERATOR, payload);

    return response.data;
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw error;
  }
};
export const fetchHomeBaseLocation = async () => {
  try {
    const response = await api.get(GET_HOMEBASE_LOCATION);
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const getAllNotifications = async (manager_id: string) => {
  try {
    const response = await api.post(FETCH_NOTIFICATION, {manager_id});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const getIncidentlNotifications = async (user_id: string) => {
  try {
    const response = await api.post(GET_INCIDENT_NOTIFICATION, {user_id});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const handleDeleteNotification = async (notification_id: string) => {
  try {
    const response = await api.post(DELETE_NOTIFICATION, {notification_id});
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const getuserhomebaseID = async (userId: string) => {
  try {
    const response = await api.post(GET_USER_HOMEBASE_LOCATION, {userId});
    console.log('res', response);

    return response.data;
  } catch (error) {
    throw error;
  }
};
export const fetchAllJobLocations = async () => {
  try {
    const response = await api.get(FETCH_ADMIN_JOB_LIST);
    console.log('res', response);

    return response.data;
  } catch (error) {
    throw error;
  }
};
export const fetchTampaJobLocation = async () => {
  try {
    const response = await api.get(FETCH_TAMPA_LOCATION);
    console.log(response.data);

    return response.data;
  } catch (error) {
    throw error;
  }
};
export const fetchNewJerseyLocation = async () => {
  try {
    const response = await api.get(FETCH_NJ_LOCATION);
    console.log(response.data);

    return response.data;
  } catch (error) {
    throw error;
  }
};
export default api;
