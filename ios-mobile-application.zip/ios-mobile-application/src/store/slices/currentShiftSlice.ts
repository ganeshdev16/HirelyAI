// store/slices/currentShiftSlice.ts
import {createSlice, PayloadAction} from '@reduxjs/toolkit';

interface CurrentShiftState {
  shiftId: string | null;
}

const initialState: CurrentShiftState = {
  shiftId: null,
};

const currentShiftSlice = createSlice({
  name: 'currentShift',
  initialState,
  reducers: {
    setCurrentShiftId: (state, action: PayloadAction<string>) => {
      state.shiftId = action.payload;
    },
    clearCurrentShiftId: state => {
      state.shiftId = null;
    },
  },
});

export const {setCurrentShiftId, clearCurrentShiftId} =
  currentShiftSlice.actions;
export default currentShiftSlice.reducer;
