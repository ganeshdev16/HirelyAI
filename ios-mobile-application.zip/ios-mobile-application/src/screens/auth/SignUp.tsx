import React, {useEffect, useState} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Pressable,
  TouchableWithoutFeedback,
} from 'react-native';

import {fetchHomeBaseLocation, resendOtp, signUp} from '../../services/api';
import RedlineLogo from '../../components/RedLineLogo';
import {HomeBaseLocationData} from '../../types/locationdata';
import {KeyboardAvoidingView} from 'react-native';

const RoleDropdown = ({
  onSelectRole,
  roleError,
  isOpen,
  setIsOpen,
}: {
  onSelectRole: (role: string) => void;
  roleError: string;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}) => {
  const [selectedRole, setSelectedRole] = useState('');
  const roles = ['Manager', 'Guard'];

  const dropdownButtonStyle = [
    styles.dropdownButton,
    roleError || isOpen ? styles.inputError : null,
    isOpen ? styles.dropdownOpen : null,
  ];

  return (
    <View style={styles.inputContainer}>
      <Text style={styles.label}>Role</Text>
      <TouchableOpacity
        onPress={() => setIsOpen(!isOpen)}
        style={dropdownButtonStyle}>
        <Text style={[styles.dropdownText, selectedRole && styles.activeText]}>
          {selectedRole || 'Select your role'}
        </Text>
        <AntDesign name={isOpen ? 'up' : 'down'} size={20} color="#666666" />
      </TouchableOpacity>
      {roleError && <Text style={styles.errorText}>{roleError}</Text>}

      {isOpen && (
        <View style={styles.dropdownList}>
          {roles.map(role => (
            <TouchableOpacity
              key={role}
              style={styles.option}
              onPress={() => {
                setSelectedRole(role);
                onSelectRole(role);
                setIsOpen(false);
              }}>
              <Text style={styles.optionText}>{role}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );
};

const LocationDropdown = ({
  onSelectLocation,
  locationError,
  isOpen,
  setIsOpen,
}: {
  onSelectLocation: (location: string) => void;
  locationError: string;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}) => {
  const [selectedLocation, setSelectedLocation] = useState('');
  const [isClicked, setIsClicked] = useState(false);
  const [locations, setLocation] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Add this useEffect to reset isClicked when dropdown closes
  useEffect(() => {
    if (!isOpen) {
      setIsClicked(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const fetchLocations = async () => {
      setIsLoading(true);
      try {
        const response = await fetchHomeBaseLocation();

        if (response.locations && Array.isArray(response.locations)) {
          const locationNames = response.locations.map((item: any) => {
            return item.area ? `${item.name} (${item.area})` : item.name;
          });
          setLocation(locationNames);
        } else if (Array.isArray(response)) {
          setLocation(response.map((item: HomeBaseLocationData) => item.name));
        } else {
          console.error('Unexpected response format:', response);
          setLocation([]);
        }
      } catch (error) {
        console.error('Error fetching locations:', error);
        setLocation([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchLocations();
  }, []);

  return (
    <View style={styles.inputContainer}>
      <Text style={styles.label}>Location</Text>

      <TouchableOpacity
        onPress={() => {
          setIsOpen(!isOpen);
          setIsClicked(true);
        }}
        style={[
          styles.dropdownButton,
          locationError || isClicked ? styles.inputError : null,
          isOpen ? styles.dropdownOpen : null,
        ]}>
        <Text
          style={[styles.dropdownText, selectedLocation && styles.activeText]}>
          {selectedLocation || 'Select your Location'}
        </Text>
        <AntDesign name={isOpen ? 'up' : 'down'} size={20} color="#666666" />
      </TouchableOpacity>
      {locationError && <Text style={styles.errorText}>{locationError}</Text>}
      {isOpen && (
        <View style={styles.dropdownList}>
          {isLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            locations.map(location => (
              <TouchableOpacity
                key={location}
                style={styles.option}
                onPress={() => {
                  setSelectedLocation(location);
                  onSelectLocation(location);
                  setIsOpen(false);
                  setIsClicked(false);
                }}>
                <Text style={styles.optionText}>{location}</Text>
              </TouchableOpacity>
            ))
          )}
        </View>
      )}
    </View>
  );
};

export default function SignUpScreen({navigation}: any) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [locationDropdownOpen, setLocationDropdownOpen] = useState(false);
  // const [focusedField, setFocusedField] = useState<'email' | 'password' | null>(
  //   null,
  // );
  // const {startLocationTracking} = useLocationTracker();

  const [focusedField, setFocusedField] = useState<'email' | 'password' | null>(
    null,
  );
  const [isLoading, setIsLoading] = useState(false);

  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [roleError, setRoleError] = useState('');
  const [locationError, setLocationError] = useState('');
  const [termsError, setTermsError] = useState('');

  const [generalError, setGeneralError] = useState('');

  const isValidEmail = (emailText: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(emailText);
  };

  const handleEmailChange = (text: string) => {
    setEmail(text);
    setEmailError('');
    setGeneralError('');
  };
  const handleResetOtp = async () => {
    try {
      const response = await resendOtp(email);
      if (response) {
        navigation.navigate('OtpVerification', {email: email});
      }
    } catch (error) {
      setGeneralError('Failed to resend OTP. Please try again.');
    }
  };

  const handleSignUp = async () => {
    // Clear all previous errors
    setEmailError('');
    setPasswordError('');
    setRoleError('');
    setLocationError('');
    setTermsError('');
    setGeneralError('');
    let hasError = false;

    // Validate role
    if (!selectedRole) {
      setRoleError('Please select a role');
      hasError = true;
    }

    // Validate location
    if (!selectedLocation) {
      setLocationError('Please select a location');
      hasError = true;
    }

    // Validate email
    if (!email) {
      setEmailError('Please enter your email');
      hasError = true;
    } else if (!isValidEmail(email)) {
      setEmailError('Please enter a valid email address');
      hasError = true;
    }

    // Validate password
    if (!password) {
      setPasswordError('Please enter your password');
      hasError = true;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      hasError = true;
    }

    // Validate terms
    if (!agreeToTerms) {
      setTermsError('Please agree to the terms and conditions');
      hasError = true;
    }

    if (!hasError) {
      setIsLoading(true);
      try {
        const userData = {
          email,
          password,
          role: selectedRole,
          location: selectedLocation,
        };
        const response = await signUp(userData);

        if (response.status === 'SUCCESS') {
          navigation.navigate('OtpVerification', {email: email});
        }
      } catch (error: any) {
        const statusCode = error.status || error.response?.status;
        const apiStatus = error.response?.data?.status || error.data?.status;

        switch (statusCode) {
          case 400:
            if (apiStatus === 'VALIDATION_ERROR') {
              const missingFields =
                error.response?.data?.data?.missing_fields || [];
              if (missingFields.length > 0) {
                setGeneralError(
                  `Please fill in all required fields: ${missingFields.join(
                    ', ',
                  )}`,
                );
              } else {
                setGeneralError('Please check your input and try again.');
              }
            } else if (apiStatus === 'CONFLICT_ERROR') {
              setEmailError(
                'This email is already registered. Please use a different email or sign in.',
              );
              handleResetOtp();
            } else {
              setGeneralError('Please check your information and try again.');
            }
            break;

          case 403:
            setGeneralError(
              'You are not authorized in Homebase. Please contact support.',
            );
            break;

          case 500:
            setGeneralError('Server error. Please try again later.');
            break;

          case 404:
            setGeneralError('Service unavailable. Please contact support.');
            break;

          case 429:
            setGeneralError('Too many requests. Please wait and try again.');
            break;

          default:
            if (!statusCode) {
              setGeneralError(
                'Please check your internet connection and try again.',
              );
            } else {
              setGeneralError('Something went wrong. Please try again.');
            }
        }
      } finally {
        setIsLoading(false);
      }
    }
  };
  const handleClickAway = () => {
    if (roleDropdownOpen) {
      setRoleDropdownOpen(false);
    }
    if (locationDropdownOpen) {
      setLocationDropdownOpen(false);
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Sign Up</Text>
        <View style={styles.logo}>
          <RedlineLogo height="28" width="101" />
        </View>
      </View>
      <TouchableWithoutFeedback onPress={handleClickAway}>
        <View style={styles.form}>
          {generalError ? (
            <View style={styles.generalErrorContainer}>
              <Text style={styles.generalErrorText}>{generalError}</Text>
            </View>
          ) : null}

          <RoleDropdown
            onSelectRole={setSelectedRole}
            roleError={roleError}
            isOpen={roleDropdownOpen}
            setIsOpen={setRoleDropdownOpen}
          />

          <LocationDropdown
            onSelectLocation={setSelectedLocation}
            locationError={locationError}
            isOpen={locationDropdownOpen}
            setIsOpen={setLocationDropdownOpen}
          />

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Email</Text>
            <View
              style={[
                styles.inputWrapper,
                focusedField === 'email' ? styles.inputFocused : null,
                emailError ? styles.inputError : null,
              ]}>
              <TextInput
                style={styles.input}
                placeholder="Enter your email"
                placeholderTextColor="#666666"
                value={email}
                onChangeText={handleEmailChange}
                keyboardType="email-address"
                autoCapitalize="none"
                onFocus={() => setFocusedField('email')}
                onBlur={() => setFocusedField(null)}
              />
              {email.length > 0 && isValidEmail(email) && (
                <View style={styles.iconWrapper}>
                  <AntDesign name="check" size={20} color="#787878" />
                </View>
              )}
            </View>
            {emailError ? (
              <Text style={styles.errorText}>{emailError}</Text>
            ) : null}
          </View>
          <KeyboardAvoidingView>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Password</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'password' ? styles.inputFocused : null,
                  passwordError ? styles.inputError : null,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your password"
                  placeholderTextColor="#666666"
                  value={password}
                  onChangeText={(text: React.SetStateAction<string>) => {
                    setPassword(text);
                    setPasswordError('');
                  }}
                  // onChangeText={handlePasswordChange}
                  secureTextEntry={!showPassword}
                  onFocus={() => setFocusedField('password')}
                  onBlur={() => setFocusedField(null)}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.iconWrapperpwd}>
                  <AntDesign
                    name="eye"
                    size={20}
                    color={showPassword ? '#fff' : '#787878'}
                  />
                </TouchableOpacity>
              </View>
              {passwordError ? (
                <Text style={styles.errorText}>{passwordError}</Text>
              ) : null}
            </View>
          </KeyboardAvoidingView>

          <View style={styles.termsContainer}>
            <TouchableOpacity
              style={[styles.checkbox, agreeToTerms && styles.checkedBox]}
              onPress={() => {
                setAgreeToTerms(!agreeToTerms);
                setTermsError('');
              }}>
              {agreeToTerms && (
                <AntDesign name="check" size={18} color="white" />
              )}
            </TouchableOpacity>
            <View style={styles.termsandprivacyContainer}>
              <Text style={styles.agreeText}>I agree to the</Text>
              <Pressable
                hitSlop={20}
                onPress={() => navigation.navigate('TermsAndConditions')}>
                <Text style={styles.highlightText}>Terms and Conditions</Text>
              </Pressable>
              <Text style={styles.agreeText}>and the</Text>
              <Pressable
                hitSlop={15}
                onPress={() => navigation.navigate('PrivacyPolicy')}>
                <Text style={styles.highlightText}>Privacy Policy</Text>
              </Pressable>
              <Text style={styles.agreeText}>.</Text>
            </View>
          </View>
          {termsError ? (
            <Text style={styles.errorText}>{termsError}</Text>
          ) : null}

          <TouchableOpacity
            style={[styles.signUpButton, isLoading && styles.disabledButton]}
            onPress={handleSignUp}
            disabled={isLoading}>
            {isLoading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.signUpButtonText}>Sign Up</Text>
            )}
          </TouchableOpacity>

          <View style={styles.signInContainer}>
            <Text style={styles.signInText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('SignIn')}>
              <Text style={styles.signInLink}>Sign in</Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 8,
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter_18pt-SemiBold',
    marginLeft: 16,
    fontWeight: 'bold',
  },
  logo: {
    width: 100,
    height: 24,
    marginLeft: 'auto',
  },
  form: {
    padding: 16,
    flex: 1,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
    marginBottom: 8,
  },
  iconWrapper: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#2E2E2E',
    justifyContent: 'center',
    alignItems: 'center',
    right: -5,
  },
  iconWrapperpwd: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: 'black',
    borderWidth: 2,
    borderColor: '#2E2E2E',
    justifyContent: 'center',
    alignItems: 'center',
    right: -5,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 56,
    backgroundColor: '#090909',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#333333',
    paddingHorizontal: 16,
  },
  inputFocused: {
    borderColor: '#B40B0B',
    borderWidth: 1.5,
  },
  inputError: {
    borderColor: '#B40B0B',
    borderWidth: 1.5,
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  dropdownButton: {
    height: 56,
    backgroundColor: '#090909',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#333333',
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dropdownText: {
    color: '#666666',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  activeText: {
    color: '#FFFFFF',
  },
  dropdownList: {
    position: 'absolute',
    top: 96,
    left: 0,
    right: 0,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    backgroundColor: '#090909',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#B40B0B',
    padding: 8,
    zIndex: 1000,
  },
  dropdownOpen: {
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
  },
  option: {
    padding: 12,
    borderRadius: 4,
  },
  optionText: {
    color: '#666666',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  errorText: {
    color: '#B40B0B',
    fontSize: 12,
    marginTop: 4,
    fontFamily: 'Inter_18pt-Regular',
  },
  termsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#666666',
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkedBox: {
    borderColor: '#242424',
  },
  termsText: {
    columnGap: 3,
    width: 322,
    color: '#666666',
    fontSize: 14,
    fontWeight: 400,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',

    fontFamily: 'Inter_18pt-Regular',
  },
  signUpButton: {
    height: 56,
    backgroundColor: '#B40B0B',
    borderRadius: 16,
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    marginTop: 24,
  },
  disabledButton: {},
  signUpButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-SemiBold',
    fontWeight: '600',
  },

  signInContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
  },
  signInText: {
    color: '#8C8C8C',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  signInLink: {
    color: '#B40B0B',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
  },
  generalErrorContainer: {
    backgroundColor: '#B40B0B',
    borderRadius: 8,
    padding: 12,
  },
  generalErrorText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_18pt-Regular',
  },
  highlightText: {
    color: '#B40B0B',
    textDecorationLine: 'underline',
    paddingHorizontal: 5,
    fontWeight: 500,
    fontSize: 14,
  },
  termsandprivacyContainer: {
    gap: 3,
    marginLeft: 4,
    width: 322,
    height: 32,
    flexWrap: 'wrap',
    display: 'flex',
    flexDirection: 'row',
  },
  agreeText: {color: '#ffffff', fontSize: 14, fontWeight: 500},
});
