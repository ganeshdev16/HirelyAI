// declare module 'react-native-push-notification' {
//     export default class PushNotification {
//         static localNotification(options: { channelId: string; title: string; message: string }): void;
//         static createChannel(options: any): Promise<void>;
//     }
//   }
