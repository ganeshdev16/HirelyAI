import React from 'react';
import {View, ActivityIndicator, Text, StyleSheet} from 'react-native';

const Loader = ({size = 'large', color = '#B40B0B', text = 'Loading...'}) => {
  const validSize = size === 'large' || size === 'small' ? size : 'large';
  return (
    <View style={styles.loaderContainer}>
      <ActivityIndicator
        size={validSize}
        color={color}
        style={styles.spinner}
      />
      <Text style={[styles.loadingText]}>{text}</Text>
    </View>
  );
};

export default Loader;

const styles = StyleSheet.create({
  loaderContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
  },
  spinner: {
    marginBottom: 8,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
});
