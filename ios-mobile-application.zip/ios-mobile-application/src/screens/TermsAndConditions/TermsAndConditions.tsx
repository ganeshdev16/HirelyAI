import React from 'react';
import {
  SafeAreaView,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import {RootStackScreenProps} from '../../types/navigation';
import AntDesign from 'react-native-vector-icons/AntDesign';
import RedlineLogo from '../../components/RedLineLogo';
import {ScrollView} from 'react-native-gesture-handler';
import termsData from '../../constants/terms.json';

function TermsAndConditions({
  navigation,
}: Readonly<RootStackScreenProps<'TermsAndConditions'>>) {
  const terms = termsData.terms_and_conditions;

  return (
    <SafeAreaView style={styles.container}>
      {/* Header with Back Button */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <RedlineLogo height="29" width="101" />
      </View>

      <Text style={styles.headertext}>Terms and Conditions</Text>
      <Text style={styles.datetext}>Last Updated: {terms.last_updated}</Text>
      <ScrollView contentContainerStyle={styles.contentContainer}>
        <View style={styles.section}>
          <Text style={styles.subHeader}>Introduction</Text>
          <Text style={styles.text}>{terms.introduction}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.subHeader}>1.Definitions</Text>
          {Object.entries(terms.definitions).map(([key, value]) => (
            <View key={key} style={styles.definitionItem}>
              <Text style={styles.definitionNumber}>{key}</Text>
              <Text style={styles.definitionText}>{value}</Text>
            </View>
          ))}
        </View>
        {/* Purpose and scope */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>2. Purpose and Scope</Text>

          {/* Display the description */}
          {terms.purpose_and_scope['2.1'].description && (
            <View style={styles.definitionItem}>
              <Text style={styles.definitionText}>
                <Text style={styles.definitionNumber}>2.1 </Text>
                {terms.purpose_and_scope['2.1'].description}
              </Text>
            </View>
          )}

          {/* Map through the 'a' sub-items */}
          {Object.entries(terms.purpose_and_scope['2.1'].a).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {terms.purpose_and_scope['2.2'].description && (
            <View style={styles.definitionItem}>
              <Text style={styles.definitionText}>
                <Text style={styles.definitionNumber}>2.2 </Text>
                {terms.purpose_and_scope['2.2'].description}
              </Text>
            </View>
          )}
          {Object.entries(terms.purpose_and_scope['2.2'].a).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {/* User RESPONSIBILITY */}
          <Text style={styles.subHeader}>3.User Responsibility</Text>

          {Object.entries(terms.user_responsibilities['3.1']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.user_responsibilities['3.2']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.user_responsibilities['3.3']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.user_responsibilities['3.4']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          <Text style={styles.definitionText}>
            {terms.user_responsibilities.consequences}
          </Text>
          {/* Data Collection & Reporting Features */}
          <Text style={styles.subHeader}>
            4.Data Collection & Reporting Features
          </Text>

          {Object.entries(terms.data_collection_reporting_features['4.1']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.data_collection_reporting_features['4.2']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.data_collection_reporting_features['4.3']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}

          {/* Confidentiality & Data Protection */}
          <Text style={styles.subHeader}>
            5.Confidentiality & Data Protection
          </Text>
          {Object.entries(terms.confidentiality_data_protection).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {/* Intellectual Property */}
          <Text style={styles.subHeader}>6.Intellectual Property</Text>
          {Object.entries(terms.intellectual_property).map(([key, value]) => (
            <View key={key} style={styles.definitionItem}>
              <Text style={styles.definitionNumber}>{key}</Text>
              <Text style={styles.definitionText}>{value}</Text>
            </View>
          ))}
          {/* Limitations of Liability */}
          <Text style={styles.subHeader}>7.Limitations of Liability</Text>

          {Object.entries(terms.limitations_of_liability['7.1']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.limitations_of_liability['7.2']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {Object.entries(terms.limitations_of_liability['7.3']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {/* Account Suspension or Termination  */}
          <Text style={styles.subHeader}>
            8.Account Suspension or Termination
          </Text>
          {Object.entries(terms.account_suspension_termination['8.1']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {/* Modifications to These Terms  */}
          <Text style={styles.subHeader}>9. Modifications to These Terms</Text>
          {Object.entries(terms.modifications_to_terms).map(([key, value]) => (
            <View key={key} style={styles.definitionItem}>
              <Text style={styles.definitionNumber}>{key}</Text>
              <Text style={styles.definitionText}>{value}</Text>
            </View>
          ))}
          {/* Governing Law & Dispute Resolution   */}
          <Text style={styles.subHeader}>
            10. Governing Law & Dispute Resolution
          </Text>
          {Object.entries(terms.governing_law_dispute_resolution).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionNumber}>{key}</Text>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {/* Contact Information */}
          <Text style={styles.subHeader}>11. Contact Information</Text>
          {Object.entries(terms.contact_information['11.1']).map(
            ([key, value]) => (
              <View key={key} style={styles.definitionItem}>
                <Text style={styles.definitionText}>{value}</Text>
              </View>
            ),
          )}
          {/* Acknowledgment   */}
          <Text style={styles.subHeader}>12. Acknowledgment</Text>
          {Object.entries(terms.acknowledgment).map(([key, value]) => (
            <View key={key} style={styles.definitionItem}>
              <Text style={styles.definitionText}>{value}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    margin: 8,
    display: 'flex',
    backgroundColor: '#000000',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  subDefinitionItem: {
    marginLeft: 20,
    marginBottom: 5,
  },

  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 8,
  },
  headertext: {
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-Bold',
    fontSize: 20,
    color: 'white',
    paddingHorizontal: 16,
    paddingVertical: 5,
    backgroundColor: '#000000',
  },
  contentContainer: {
    marginTop: 32,
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 10,
  },
  subHeader: {
    fontFamily: 'Inter_18pt-Bold',
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 10,
    marginBottom: 10,
  },
  text: {
    color: 'white',
    fontFamily: 'Inter_18pt-Regular',
    fontWeight: 500,
    marginBottom: 5,
    letterSpacing: 0.5,
  },
  datetext: {
    fontWeight: 500,
    fontStyle: 'italic',
    fontFamily: 'Inter_18pt-Regular',

    fontSize: 12,
    paddingHorizontal: 16,
    paddingVertical: 5,
    color: '#6A6A6A',
  },
  definitionNumber: {
    fontFamily: 'Inter_18pt-Regular',
    fontWeight: 500,
    color: 'white',
    marginRight: 8, // Space between number and text
  },
  list: {
    fontFamily: 'Inter_18pt-Regular',
    fontWeight: 500,
    fontSize: 14,
    color: 'white',
    marginRight: 8,
  },
  definitionText: {
    fontFamily: 'Inter_18pt-Regular',
    fontWeight: 500,
    color: 'white',
    flex: 1, // Allows text to wrap and take remaining space
    lineHeight: 20, // Adjust for better readability
  },
  definitionItem: {
    flexDirection: 'row',
    marginVertical: 5,
  },
});

export default TermsAndConditions;
