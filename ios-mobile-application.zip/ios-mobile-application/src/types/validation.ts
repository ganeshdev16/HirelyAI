export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
}

export interface LocationServicesManagerInterface {
  checkLocationStatus(): Promise<{
    locationEnabled: boolean;
    hasPermission: boolean;
  }>;
  requestLocationPermission(): Promise<boolean>;
  turnOnLocation(): Promise<{
    locationEnabled: boolean;
    status: string;
  }>;
}

export interface CameraCaptureProps {
  isVisible: boolean;
  onClose: () => void;
  onPhotoTaken: (path: string) => void;
}
