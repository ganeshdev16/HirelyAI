import { StyleSheet } from 'react-native';

export const buttonstyles = StyleSheet.create({
  submitButton: {
    width: 361,
    height: 61,
    borderRadius: 16,
    opacity: 1,
    backgroundColor: '#ffffff',
  },
});
