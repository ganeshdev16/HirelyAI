import {StyleSheet, View, Text} from 'react-native';
import React from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
export const EmptyComponent = () => (
  <View style={styles.emptyContainer}>
    <AntDesign name="inbox" size={64} color="#787878" />
    <Text style={styles.emptyText}>No jobs available</Text>
    <Text style={styles.emptySubText}>
      Add a job to get started by clicking the + icon.
    </Text>
  </View>
);

const styles = StyleSheet.create({
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  emptySubText: {
    color: '#787878',
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
});
