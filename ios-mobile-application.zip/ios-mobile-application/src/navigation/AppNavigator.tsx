import {createStackNavigator, TransitionPresets} from '@react-navigation/stack';
import SignIn from '../screens/auth/SignIn';
import SignUp from '../screens/auth/SignUp';
import WelcomeScreen from '../screens/auth/WelcomeScreen';
import ClockInScreen from '../screens/clock/ClockIn';
import ForgotPasswordScreen from '../screens/auth/ForgotPasswordScreen';
import OtpPasswordSetup from '../screens/auth/OtpPasswordSetup';
import Dashboard from '../screens/Dashboard/Dashboard';
import EmergencyOption from '../screens/Emergency/EmergencyOption';
import OtpVerification from '../screens/auth/OtpVerification';
import {RootStackParamList} from '../types/navigation';
import React from 'react';
import jobDetailScreen from '../screens/jobDetails/jobDetail';
import JobList from '../screens/JobList/JobList';
import ManagerDashboard from '../screens/Dashboard/ManagerDashboard';
import Notification from '../screens/Notification/Notification';
import ValidationScreen from '../screens/validation/validation';
import RequestScreen from '../screens/Request/RequestScreen';
import ReportIncidentScreen from '../screens/Report/reportIncident';
import {useAuth} from '../context/AuthContext';
import SplashScreen from '../components/SplashScreen';
import EditJobDetail from '../screens/EditJobDetail/EditJobDetail';
import TermsAndConditions from '../screens/TermsAndConditions/TermsAndConditions';
import PrivacyPolicy from '../screens/PrivacyPolicy/PrivacyPolicy';
import FireWatchLogs from '../screens/FireWatchLogs/FireWatchLogs';

const Stack = createStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  const {isAuthenticated, isLoading, role} = useAuth();

  if (isLoading) {
    return <SplashScreen />;
  }
  return (
    <Stack.Navigator
      initialRouteName={
        isAuthenticated
          ? role === 'Manager'
            ? 'ManagerDashboard'
            : 'JobList'
          : 'Welcome'
      }
      screenOptions={{
        headerShown: false,
        cardStyle: {backgroundColor: '#000000'},
        ...TransitionPresets.SlideFromRightIOS,
      }}>
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen name="SignUp" component={SignUp} />
      <Stack.Screen name="SignIn" component={SignIn} />
      <Stack.Screen name="ClockIn" component={ClockInScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
      <Stack.Screen name="OtpPasswordSetup" component={OtpPasswordSetup} />
      <Stack.Screen name="Dashboard" component={Dashboard} />
      <Stack.Screen name="EmergencyOption" component={EmergencyOption} />
      <Stack.Screen name="OtpVerification" component={OtpVerification} />
      <Stack.Screen name="Validation" component={ValidationScreen} />
      <Stack.Screen name="jobDetail" component={jobDetailScreen} />
      <Stack.Screen name="reportIncident" component={ReportIncidentScreen} />
      <Stack.Screen name="JobList" component={JobList} />
      <Stack.Screen name="ManagerDashboard" component={ManagerDashboard} />
      <Stack.Screen name="Notification" component={Notification} />
      <Stack.Screen name="RequestScreen" component={RequestScreen} />
      <Stack.Screen name="TermsAndConditions" component={TermsAndConditions} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="FireWatchLogs" component={FireWatchLogs} />
      <Stack.Screen name="EditJobDetail" component={EditJobDetail} />
    </Stack.Navigator>
  );
}
