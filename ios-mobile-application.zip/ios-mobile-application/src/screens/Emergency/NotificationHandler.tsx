// import React, {useEffect} from 'react';
// import messaging from '@react-native-firebase/messaging';
// const PushNotification = require('react-native-push-notification');
// import {Platform} from 'react-native';
// import {useNavigation} from '@react-navigation/native';
// // Define our own Importance enum since the library doesn't export it properly
// enum Importance {
//   DEFAULT = 3,
//   MAX = 5,
//   HIGH = 4,
//   LOW = 2,
//   MIN = 1,
//   NONE = 0,
// }
// interface ChannelConfig {
//   channelId: string;
//   channelName: string;
//   channelDescription: string;
//   playSound: boolean;
//   soundName: string;
//   importance: number;
//   vibrate: boolean;
// }
// interface LocalNotificationProps {
//   channelId: string;
//   title: string;
//   message: string;
//   playSound?: boolean;
//   soundName?: string;
//   importance?: number | string;
//   priority?: 'high' | 'max' | 'low' | 'min' | 'default';
//   vibrate?: boolean;
//   userInfo?: any;
// }
// const NotificationHandler: React.FC = () => {
//   const navigation = useNavigation();
//   useEffect(() => {
//     if (Platform.OS === 'android') {
//       const channelConfig: ChannelConfig = {
//         channelId: 'emergency',
//         channelName: 'Emergency Alerts',
//         channelDescription: 'Emergency notifications channel',
//         playSound: true,
//         soundName: 'default',
//         importance: Importance.HIGH,
//         vibrate: true,
//       };
//       PushNotification.createChannel(channelConfig);
//     }
//     const showLocalNotification = (remoteMessage: any) => {
//       const notificationConfig: LocalNotificationProps = {
//         channelId: 'emergency',
//         title: remoteMessage.notification?.title ?? 'New Notification',
//         message:
//           remoteMessage.notification?.body ?? 'You have a new notification',
//         playSound: true,
//         soundName: 'default',
//         importance: Importance.HIGH,
//         priority: 'high',
//         vibrate: true,
//         userInfo: remoteMessage.data,
//       };
//       PushNotification.localNotification(notificationConfig);
//     };
//     const unsubscribe = messaging().onMessage(async remoteMessage => {
//       console.log('Received foreground message:', remoteMessage);
//       showLocalNotification(remoteMessage);
//     });
//     messaging().setBackgroundMessageHandler(async remoteMessage => {
//       console.log('Received background message:', remoteMessage);
//       showLocalNotification(remoteMessage);
//     });
//     // PushNotification.configure({
//     //   onNotification: function (notification: any) {
//     //    console.log('Notification clicked:', notification);
//     //    const data = notification.data || {};
//     //    if (data.action === 'open_job_details') {
//     //      // @ts-ignore - Adding this to bypass the type checking for navigation.navigate
//     //      navigation.navigate('RequestScreen', {jobId: data.job_id});
//     //    }
//     //   },
//     //   requestPermissions: Platform.OS === 'ios',
//     // });
//     return () => {
//       unsubscribe();
//       PushNotification.removeAllDeliveredNotifications();
//     };
//   }, [navigation]);
//   return null;
// };
// export default NotificationHandler;
