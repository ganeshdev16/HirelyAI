import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  TouchableOpacityProps,
  StyleProp,
  ViewStyle,
  TextStyle,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

interface LinearGradientButtonProps extends TouchableOpacityProps {
  title: string;
  colors?: string[];
  buttonStyle?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
}

const LinearGradientButton: React.FC<LinearGradientButtonProps> = ({
  title,
  colors = ['#B40B0B', '#B21F1F'],
  buttonStyle,
  textStyle,
  ...touchableProps
}) => {
  return (
    <TouchableOpacity {...touchableProps}>
      <LinearGradient colors={colors} style={[styles.button, buttonStyle]}>
        <Text style={[styles.buttonText, textStyle]}>{title}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: {
    fontFamily: 'Inter_18pt-SemiBold',

    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default LinearGradientButton;
