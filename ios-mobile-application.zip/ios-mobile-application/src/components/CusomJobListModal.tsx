import React, {useState, useCallback} from 'react';
import {Modal, View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import {useCheckLocation} from '../hooks/usecheckLocation';

interface SettingsModalProps {
  isVisible: boolean;
  onOpenSettings: () => void;
}

const JobListSettingsModal: React.FC<SettingsModalProps> = ({
  isVisible,
  onOpenSettings,
}) => {
  return (
    <Modal visible={isVisible} transparent={true} animationType="fade">
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Enable Location</Text>
          <Text style={styles.modalText}>
            Before starting your shift please enable your location.
          </Text>
          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={[styles.modalButton, styles.modalButtonPrimary]}
              onPress={onOpenSettings}>
              <Text
                style={[styles.modalButtonText, styles.modalButtonTextPrimary]}>
                Open Settings
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const CustomJobListSettingsModal: React.FC = () => {
  const {isLocationEnabled, openSettings, checkLocationStatus} =
    useCheckLocation();
  const [isModalVisible, setIsModalVisible] = useState(!isLocationEnabled);

  useFocusEffect(
    useCallback(() => {
      checkLocationStatus();
      setIsModalVisible(!isLocationEnabled);
    }, [isLocationEnabled, checkLocationStatus]),
  );

  const handleOpenSettings = async () => {
    await openSettings();
    await checkLocationStatus(); // Ensure status is updated after settings
  };

  return (
    <JobListSettingsModal
      isVisible={isModalVisible}
      onOpenSettings={handleOpenSettings}
    />
  );
};

export default CustomJobListSettingsModal;

export const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1C1C1E',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Inter_18pt-SemiBold',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 14,
    fontFamily: 'Inter_18pt-Regular',
    color: '#8E8E93',
    textAlign: 'center',
    marginBottom: 20,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'center', // Center the single button
    width: '100%',
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#3A3A3C',
  },
  modalButtonPrimary: {
    backgroundColor: '#FF0000',
    borderColor: '#FF0000',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_18pt-SemiBold',
  },
  modalButtonTextPrimary: {
    color: '#FFFFFF',
  },
});
