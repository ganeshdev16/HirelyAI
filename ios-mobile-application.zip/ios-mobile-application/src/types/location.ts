export interface Location {
  currentLocation: any;
  locationHistory: LocationHistory[];
  isInsideCircle: boolean;
  isTracking: boolean;
  error: any;
  isLocationEnabled?: boolean;
  hasPermission?: boolean;
  totalDistance: number;

}

export interface LocationDetails {
  latitude: number;
  longitude: number;
}

export interface LocationHistory {
  latitude: any;
  longitude: any;
  timestamp?: any;
}

export interface LocationData {
  latitude: any;
  longitude: any;
  accuracy?: any;
  timestamp?: any;
}
