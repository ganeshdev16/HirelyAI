import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Platform,
  Pressable,
  Modal,
  TouchableWithoutFeedback,
} from 'react-native';
import {RootStackScreenProps} from '../../types/navigation';
import AntDesign from 'react-native-vector-icons/AntDesign';
import RedlineLogo from '../../components/RedLineLogo';
import DateTimePicker from '@react-native-community/datetimepicker';
import {ActivityIndicator} from 'react-native-paper';
import {storeFireWatchLogs} from '../../services/api';
import GlobalSettingsModal from '../../components/LocationModal';
import {FireWatchLog} from '../../types/firewatchLogs';
import {useSelector} from 'react-redux';
import {useSmoothLocation} from '../../hooks/useSmoothLocation';

export default function FireWatchLogs({
  route,
  navigation,
}: Readonly<RootStackScreenProps<'FireWatchLogs'>>) {
  const [formData, setFormData] = useState<FireWatchLog>({
    startTime: new Date(),
    endTime: new Date(new Date().getTime() + 30 * 60 * 1000),
    name: '',
    isAllClear: false,
    note: '',
  });

  const [focusedField, setFocusedField] = useState<keyof FireWatchLog | null>(
    null,
  );
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [isEditingStartTime, setIsEditingStartTime] = useState(true);
  const [loading, setLoading] = useState(false);
  const [tempTime, setTempTime] = useState<Date>(new Date()); // For iOS modal

  const {shiftId} = route.params;
  type FormErrors = Partial<Record<keyof FireWatchLog, string>> & {
    submit?: string;
  };
  const [errors, setErrors] = useState<FormErrors>({});
  const selectIsInsideCircle = (state: any) => state.location.isInsideCircle;
  const isInside = useSelector(selectIsInsideCircle);
  useSmoothLocation(isInside);

  const formatTime = (time: Date): string => {
    return time.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZone: 'America/New_York', // Eastern Time
    });
  };

  const formatTimeRange = (): string => {
    return `${formatTime(formData.startTime)} - ${formatTime(
      formData.endTime,
    )}`;
  };

  const handleOutsidePress = () => {
    // Only clear focus if we're not interacting with form elements
    setFocusedField(null);
  };

  const onTimeChange = (event: any, selectedTime?: Date): void => {
    if (Platform.OS === 'android') {
      setShowTimePicker(false);
      if (selectedTime) {
        if (isEditingStartTime) {
          setFormData(prev => ({...prev, startTime: selectedTime}));
          setErrors(prev => ({...prev, startTime: undefined}));
        } else {
          setFormData(prev => ({...prev, endTime: selectedTime}));
          setErrors(prev => ({...prev, endTime: undefined}));
        }
      }
      // Clear focus after time selection
      setFocusedField(null);
    } else {
      // iOS - just update temp time
      if (selectedTime) {
        setTempTime(selectedTime);
      }
    }
  };

  const handleTimePickerPress = () => {
    // Set focus to the time field
    setFocusedField(isEditingStartTime ? 'startTime' : 'endTime');
    setTempTime(isEditingStartTime ? formData.startTime : formData.endTime);
    setShowTimePicker(true);
  };

  const handleIOSTimeConfirm = () => {
    if (isEditingStartTime) {
      setFormData(prev => ({...prev, startTime: tempTime}));
      setErrors(prev => ({...prev, startTime: undefined}));
    } else {
      setFormData(prev => ({...prev, endTime: tempTime}));
      setErrors(prev => ({...prev, endTime: undefined}));
    }
    setShowTimePicker(false);
    // Clear focus after confirmation
    setFocusedField(null);
  };

  const handleIOSTimeCancel = () => {
    setShowTimePicker(false);
    // Clear focus on cancel
    setFocusedField(null);
  };

  const switchTime = () => {
    setIsEditingStartTime(!isEditingStartTime);
    setTempTime(isEditingStartTime ? formData.endTime : formData.startTime);
    // Update focus to the new time being edited
    setFocusedField(isEditingStartTime ? 'endTime' : 'startTime');
  };

  const updateFormField = (
    field: keyof FireWatchLog,
    value: string | boolean | Date,
  ) => {
    setFormData(prev => ({...prev, [field]: value}));
    setErrors(prev => ({...prev, [field]: undefined}));
  };

  const validateForm = () => {
    const newErrors: FormErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    } else if (!/^[A-Za-z\s]+$/.test(formData.name.trim())) {
      newErrors.name = 'Name must contain only alphabets';
    }
    if (!formData.note.trim()) {
      newErrors.note = 'Note is required';
    }
    if (formData.endTime <= formData.startTime) {
      newErrors.endTime = 'End time must be after start time';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    const payload = {
      name: formData.name,
      isAllClear: formData.isAllClear,
      note: formData.note,
      starttime: formatTime(formData.startTime),
      endtime: formatTime(formData.endTime),
    };
    console.log(payload);

    try {
      const response = await storeFireWatchLogs(shiftId, payload);

      if (response.message === 'success') {
        navigation.replace('Validation');
      }

      setFormData({
        startTime: new Date(),
        endTime: new Date(new Date().getTime() + 30 * 60 * 1000),
        name: '',
        isAllClear: false,
        note: '',
      });
      setErrors({});
    } catch (error: any) {
      console.error('Error submitting fire watch log:', error);
      const errorMessage =
        error.response?.data?.message || 'An unexpected error occurred.';
      setErrors(prev => ({...prev, submit: errorMessage}));
    } finally {
      setLoading(false);
    }
  };

  const handleAllClearToggle = () => {
    updateFormField('isAllClear', !formData.isAllClear);
    setFocusedField('isAllClear');
  };

  const renderIOSTimePicker = () => (
    <Modal
      visible={showTimePicker}
      transparent={true}
      animationType="slide"
      onRequestClose={handleIOSTimeCancel}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={handleIOSTimeCancel}>
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              Select {isEditingStartTime ? 'Start' : 'End'} Time
            </Text>
            <TouchableOpacity onPress={handleIOSTimeConfirm}>
              <Text style={[styles.modalButtonText, styles.confirmText]}>
                Done
              </Text>
            </TouchableOpacity>
          </View>

          <DateTimePicker
            value={tempTime}
            mode="time"
            display="spinner"
            onChange={onTimeChange}
            style={styles.iosTimePicker}
            locale="en-US"
            textColor="#FFFFFF"
            themeVariant="dark"
          />

          <TouchableOpacity
            style={styles.switchTimeButton}
            onPress={switchTime}>
            <Text style={styles.switchTimeText}>
              Switch to {isEditingStartTime ? 'End Time' : 'Start Time'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <RedlineLogo height="29" width="101" />
      </View>

      <TouchableWithoutFeedback onPress={handleOutsidePress}>
        <View style={styles.formContainer}>
          <Text style={styles.headertext}>Fire Watch Logs</Text>
          <View style={styles.form}>
            {/* Time Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Time</Text>
              <Pressable
                onPress={handleTimePickerPress}
                style={[
                  styles.dateTimeInput,
                  (focusedField === 'startTime' ||
                    focusedField === 'endTime') &&
                    styles.inputFocused,
                  (errors.startTime || errors.endTime) && styles.inputError,
                ]}>
                <View style={styles.timeDisplayContainer}>
                  <View style={styles.timeItem}>
                    <Text style={styles.dateTimeText}>
                      {formatTime(formData.startTime)}
                    </Text>
                  </View>
                  <Text style={styles.timeSeparator}>-</Text>
                  <View style={styles.timeItem}>
                    <Text style={styles.dateTimeText}>
                      {formatTime(formData.endTime)}
                    </Text>
                  </View>
                </View>
                <AntDesign name="clockcircleo" size={20} color="#666666" />
              </Pressable>
              {(errors.startTime || errors.endTime) && (
                <Text style={styles.errorText}>
                  {errors.startTime || errors.endTime}
                </Text>
              )}
            </View>

            {/* Name Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'name' && styles.inputFocused,
                  errors.name && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter name"
                  placeholderTextColor="#666666"
                  value={formData.name}
                  onChangeText={value => updateFormField('name', value)}
                  onFocus={() => setFocusedField('name')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.name && (
                <Text style={styles.errorText}>{errors.name}</Text>
              )}
            </View>

            {/* Note Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Note</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'note' && styles.inputFocused,
                  errors.note && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter note"
                  placeholderTextColor="#666666"
                  value={formData.note}
                  onChangeText={value => updateFormField('note', value)}
                  onFocus={() => setFocusedField('note')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.note && (
                <Text style={styles.errorText}>{errors.note}</Text>
              )}
            </View>

            {/* All Clear Checkbox */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>All Clear</Text>
              <TouchableOpacity
                style={[
                  styles.inputCheckBoxWrapper,
                  focusedField === 'isAllClear' && styles.inputFocused,
                ]}
                onPress={handleAllClearToggle}
                activeOpacity={0.7}>
                <Text style={styles.label}>All Clear</Text>
                <TouchableOpacity
                  style={[
                    styles.customRadioButton,
                    formData.isAllClear && styles.customRadioButtonChecked,
                  ]}
                  onPress={handleAllClearToggle}
                  activeOpacity={0.7}>
                  {formData.isAllClear && (
                    <AntDesign name="check" size={20} color="black" />
                  )}
                </TouchableOpacity>
              </TouchableOpacity>
            </View>

            {/* Submit Button */}
            <View style={styles.btContainer}>
              <TouchableOpacity
                style={styles.submitButton}
                onPress={handleSubmit}
                disabled={loading}>
                {loading ? (
                  <ActivityIndicator size="small" color="black" />
                ) : (
                  <Text style={styles.submitButtonText}>Submit</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>

          {Platform.OS === 'android' && showTimePicker && (
            <DateTimePicker
              value={isEditingStartTime ? formData.startTime : formData.endTime}
              mode="time"
              display="default"
              onChange={onTimeChange}
              locale="en-US"
            />
          )}

          {Platform.OS === 'ios' && renderIOSTimePicker()}
        </View>
      </TouchableWithoutFeedback>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    margin: 8,
    display: 'flex',
    backgroundColor: '#000000',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 8,
  },
  headertext: {
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-Bold',
    fontSize: 20,
    color: 'white',
    paddingHorizontal: 16,
    paddingVertical: 5,
    backgroundColor: '#000000',
  },
  formContainer: {
    backgroundColor: '#000000',
    height: '100%',
    paddingHorizontal: 11,
  },
  form: {
    paddingHorizontal: 8,
    marginTop: 24,
    gap: 16,
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: 8,
  },
  dateTimeInput: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 56,
    backgroundColor: '#090909',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#242424',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  timeDisplayContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  timeItem: {
    flexDirection: 'column',
    alignItems: 'flex-start',
  },
  timeLabel: {
    color: '#999999',
    fontSize: 12,
    fontFamily: 'Inter_18pt-Medium',
    marginBottom: 2,
  },
  timeSeparator: {
    color: '#666666',
    fontSize: 18,
    fontFamily: 'Inter_18pt-Regular',
    marginHorizontal: 8,
  },
  dateTimeText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  label: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
    paddingHorizontal: 8,
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
    padding: 0,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 56,
    paddingHorizontal: 16,
    backgroundColor: '#090909',
    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 16,
  },
  inputCheckBoxWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 56,
    paddingHorizontal: 16,
    backgroundColor: '#090909',
    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 16,
  },
  customRadioButton: {
    width: 25,
    height: 25,
    borderRadius: 12.5,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1d1d1d',
  },
  customRadioButtonChecked: {
    backgroundColor: 'white',
  },
  customRadioButtonInner: {
    width: 13,
    height: 13,
    borderRadius: 6.5,
    backgroundColor: '#FFFFFF',
  },
  btContainer: {
    paddingHorizontal: 10,
  },
  submitButton: {
    backgroundColor: '#FFFFFF',
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
    marginBottom: 32,
    borderRadius: 16,
    paddingHorizontal: 10,
  },
  submitButtonText: {
    color: '#090909',
    fontSize: 16,
    fontFamily: 'Inter_18pt-SemiBold',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  inputFocused: {
    borderColor: '#B40B0B',
    borderWidth: 2,
  },
  inputError: {
    borderColor: '#B40B0B',
    borderWidth: 2,
  },
  errorText: {
    color: '#B40B0B',
    fontSize: 12,
    gap: 0,
    margin: 0,
    paddingHorizontal: 8,
    fontFamily: 'Inter_18pt-Regular',
  },
  // iOS Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 34,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontFamily: 'Inter_18pt-Medium',
  },
  modalButtonText: {
    color: '#666666',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  confirmText: {
    color: '#B40B0B',
    fontFamily: 'Inter_18pt-SemiBold',
  },
  iosTimePicker: {
    backgroundColor: '#1a1a1a',
  },
  timePickerText: {
    color: '#FFFFFF',
  },
  switchTimeButton: {
    backgroundColor: '#B40B0B',
    marginHorizontal: 20,
    marginTop: 20,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  switchTimeText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
    fontWeight: '600',
  },
});
