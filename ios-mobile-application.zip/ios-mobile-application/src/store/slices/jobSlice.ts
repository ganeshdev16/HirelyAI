import {createSlice, PayloadAction} from '@reduxjs/toolkit';

interface JobState {
  jobId: string | null | undefined;
}

const initialState: JobState = {
  jobId: null,
};

const jobSlice = createSlice({
  name: 'job',
  initialState,
  reducers: {
    setJobId: (state, action: PayloadAction<string>) => {
      state.jobId = action.payload;
    },
    clearJobId: state => {
      state.jobId = null;
    },
  },
});

export const {setJobId, clearJobId} = jobSlice.actions;
export default jobSlice.reducer;
