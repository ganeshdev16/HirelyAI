import { Middleware } from '@reduxjs/toolkit';
import { isEqual, throttle } from 'lodash';

export const geofenceLoggingMiddleware: Middleware = (store) => {
  let previousState: any = {};

  const throttledLog = throttle((currentLocation: any, isInsideCircle: any) => {
    console.log('Updated Geofence Info:', {
      currentLocation,
      isInsideCircle,
    });
  }, 3000);

  return (next) => (action) => {
    const result = next(action);

    const currentState = store.getState();
    const currentLocation = currentState.location.currentLocation;
    const isInsideCircle = currentState.location.isInsideCircle;


    if (
      !isEqual(previousState.currentLocation, currentLocation) ||
      previousState.isInsideCircle !== isInsideCircle
    ) {
      throttledLog(currentLocation, isInsideCircle);


      previousState = {
        currentLocation,
        isInsideCircle,
      };
    }

    return result;
  };
};
