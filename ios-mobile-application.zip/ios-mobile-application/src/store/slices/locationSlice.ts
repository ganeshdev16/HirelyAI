// locationSlice.js
import {createSlice, PayloadAction} from '@reduxjs/toolkit';

import {Location, LocationHistory} from '../../types/location';
const initialState: Location = {
  currentLocation: {},
  locationHistory: [],
  isInsideCircle: true,
  isTracking: false,
  error: null,
  isLocationEnabled: true,
  totalDistance:0
  // setLocationStatus,
};

const locationSlice = createSlice({
  name: 'location',
  initialState,
  reducers: {
    setCurrentLocation: (state, action) => {
      state.currentLocation = action.payload;
    },
    setLocationHistory(state, action: PayloadAction<LocationHistory>) {
      state.locationHistory = [...state.locationHistory, action.payload];
    },
    setIsInsideCircle: (state, action) => {
      state.isInsideCircle = action.payload;
    },
    setIsTracking: (state, action) => {
      state.isTracking = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
    setLocationStatus: (state, action: PayloadAction<boolean>) => {
      state.isLocationEnabled = action.payload;
    },
    setLocationHistoryData: (state, action: any) => {
      state.locationHistory = action.payload;
    },
    clearLocationHistory: state => {
      state.locationHistory = [];
    },
    clearCurrentLocation: state => {
      state.currentLocation = {}; // Clear the current location object
    },
  },
});

export const {
  setCurrentLocation,
  setIsInsideCircle,
  clearCurrentLocation,
  clearLocationHistory,
  setLocationHistory,
  setLocationStatus,
  setIsTracking,
  setError,
  setLocationHistoryData,
} = locationSlice.actions;

export default locationSlice.reducer;
