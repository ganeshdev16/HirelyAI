import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Platform,
  ActivityIndicator,
  Modal,
  KeyboardAvoidingView,
} from 'react-native';
import {googlePlacesStyles} from './GooglePlacesStyles';
import DateTimePicker from '@react-native-community/datetimepicker';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import {RootStackScreenProps} from '../../types/navigation';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {styles} from './ReportIncidentStyles';
import {IncidentData} from '../../types/reportIncident';
import {submitIncidentReport} from '../../services/api';
import {incidentType} from '../../constants/incidentType';
import RedlineLogo from '../../components/RedLineLogo';
import GlobalSettingsModal from '../../components/LocationModal';
import {useSelector} from 'react-redux';
import {useSmoothLocation} from '../../hooks/useSmoothLocation';
import {useAuth} from '../../context/AuthContext';
const TypeDropdown = ({
  onSelectType,
  typeError = '',
  focusedField,
  setFocusedField,
}: {
  onSelectType: (type: string) => void;
  typeError?: string;
  focusedField: keyof IncidentData | null;
  setFocusedField: (field: keyof IncidentData | null) => void;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedType, setSelectedType] = useState('');

  const dropdownButtonStyle = [
    styles.dropdownButton,
    typeError && styles.inputError,
    isOpen && styles.dropdownOpen,
    focusedField === 'type' && styles.inputFocused,
  ];
  const toggleDropdown = () => {
    if (!isOpen) {
      setFocusedField('type');
    } else {
      setFocusedField(null);
    }
    setIsOpen(!isOpen);
  };

  return (
    <View style={styles.inputContainer}>
      <Text style={styles.label}>Incident Type</Text>
      <TouchableOpacity onPress={toggleDropdown} style={dropdownButtonStyle}>
        <Text style={[styles.dropdownText, selectedType && styles.activeText]}>
          {selectedType || 'Select incident type'}
        </Text>
        <AntDesign name={isOpen ? 'up' : 'down'} size={20} color="#666666" />
      </TouchableOpacity>
      {typeError && <Text style={styles.errorText}>{typeError}</Text>}
      {isOpen && (
        <View style={styles.dropDownContainer}>
          <ScrollView
            showsVerticalScrollIndicator={true}
            nestedScrollEnabled={true}
            style={styles.dropdownList}>
            {incidentType.map(type => (
              <TouchableOpacity
                key={type}
                style={styles.option}
                onPress={() => {
                  setSelectedType(type);
                  onSelectType(type);
                  toggleDropdown();
                }}>
                <Text style={styles.optionText}>{type}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );
};

export default function ReportIncidentScreen({
  navigation,
}: RootStackScreenProps<'reportIncident'>) {
  const [formData, setFormData] = useState<IncidentData>({
    title: '',
    type: '',
    location: '',
    date: new Date(),
    time: new Date(),
    description: '',
    otherType: '',
  });

  const [focusedField, setFocusedField] = useState<keyof IncidentData | null>(
    null,
  );
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [showIOSDatePicker, setShowIOSDatePicker] = useState(false);
  const [showIOSTimePicker, setShowIOSTimePicker] = useState(false);
  const [tempDate, setTempDate] = useState(new Date());
  const [tempTime, setTempTime] = useState(new Date());

  type FormErrors = Partial<Record<keyof IncidentData, string>> & {
    submit?: string;
  };
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string>('');
  const {userId} = useAuth();
  const shiftId = useSelector((state: any) => state.currentShift.shiftId);
  console.log(shiftId, userId);
  const selectIsInsideCircle = (state: any) => state.location.isInsideCircle;
  const isInside = useSelector(selectIsInsideCircle);
  useSmoothLocation(isInside);

  const handleLocationSelect = (data: any, details: any) => {
    try {
      if (!data || !details) {
        setErrors(prev => ({
          ...prev,
          location: 'Invalid location data',
        }));
        return;
      }
      const address = data.description || '';
      const lat = details?.geometry?.location?.lat;
      const lng = details?.geometry?.location?.lng;

      if (typeof lat !== 'number' || typeof lng !== 'number') {
        setErrors(prev => ({
          ...prev,
          location: 'Unable to retrieve location coordinates',
        }));
        return;
      }

      setFormData(prev => ({
        ...prev,
        location: address,
        latitude: lat,
        longitude: lng,
      }));
      setErrors(prev => ({...prev, location: undefined}));
      setFocusedField(null);
    } catch (error) {
      console.error('Error handling location selection:', error);
      setErrors(prev => ({
        ...prev,
        location: 'Failed to process location. Please try again.',
      }));
    }
  };

  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
      .format(date)
      .replace(/\//g, '/');
  };

  const formatTime = (time: Date): string => {
    return time.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
  };

  const onDateChange = (event: any, selectedDate?: Date): void => {
    const currentDate = selectedDate || formData.date;
    if (Platform.OS === 'android') {
      setShowDatePicker(false);
    }
    setFormData(prev => ({...prev, date: currentDate}));
    setErrors(prev => ({...prev, date: undefined}));
  };

  const onTimeChange = (event: any, selectedTime?: Date): void => {
    const currentTime = selectedTime || formData.time;
    if (Platform.OS === 'android') {
      setShowTimePicker(false);
    }
    setFormData(prev => ({...prev, time: currentTime}));
    setErrors(prev => ({...prev, time: undefined}));
  };

  const handleIOSDatePickerOpen = () => {
    setTempDate(formData.date);
    setShowIOSDatePicker(true);
  };

  const handleIOSDatePickerCancel = () => {
    setShowIOSDatePicker(false);
    setTempDate(formData.date);
  };

  const handleIOSDatePickerDone = () => {
    setFormData(prev => ({...prev, date: tempDate}));
    setErrors(prev => ({...prev, date: undefined}));
    setShowIOSDatePicker(false);
  };

  const handleIOSTimePickerOpen = () => {
    setTempTime(formData.time);
    setShowIOSTimePicker(true);
  };

  const handleIOSTimePickerCancel = () => {
    setShowIOSTimePicker(false);
    setTempTime(formData.time);
  };

  const handleIOSTimePickerDone = () => {
    setFormData(prev => ({...prev, time: tempTime}));
    setErrors(prev => ({...prev, time: undefined}));
    setShowIOSTimePicker(false);
  };

  const renderIOSDatePicker = () => (
    <Modal
      visible={showIOSDatePicker}
      transparent={true}
      animationType="slide"
      onRequestClose={handleIOSDatePickerCancel}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={handleIOSDatePickerCancel}
              style={styles.modalButton}>
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Select Incident Date</Text>
            <TouchableOpacity
              onPress={handleIOSDatePickerDone}
              style={styles.modalButton}>
              <Text style={[styles.modalButtonText, styles.doneButtonText]}>
                Done
              </Text>
            </TouchableOpacity>
          </View>
          <DateTimePicker
            value={tempDate}
            maximumDate={new Date()}
            mode="date"
            display="spinner"
            textColor="#FFFFFF"
            locale="en-US"
            onChange={(event, selectedDate) => {
              if (selectedDate) {
                setTempDate(selectedDate);
              }
            }}
            style={styles.datePicker}
          />
        </View>
      </View>
    </Modal>
  );

  const renderIOSTimePicker = () => (
    <Modal
      visible={showIOSTimePicker}
      transparent={true}
      animationType="slide"
      onRequestClose={handleIOSTimePickerCancel}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={handleIOSTimePickerCancel}
              style={styles.modalButton}>
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Select Incident Time</Text>
            <TouchableOpacity
              onPress={handleIOSTimePickerDone}
              style={styles.modalButton}>
              <Text style={[styles.modalButtonText, styles.doneButtonText]}>
                Done
              </Text>
            </TouchableOpacity>
          </View>
          <DateTimePicker
            value={tempTime}
            mode="time"
            display="spinner"
            textColor="#FFFFFF"
            locale="en-US"
            onChange={(event, selectedTime) => {
              if (selectedTime) {
                setTempTime(selectedTime);
              }
            }}
            style={styles.timePicker}
          />
        </View>
      </View>
    </Modal>
  );

  const updateFormField = (field: keyof IncidentData, value: string | Date) => {
    setFormData(prev => ({...prev, [field]: value}));
    setErrors(prev => ({...prev, [field]: undefined}));
  };

  const handleTypeSelection = (type: string) => {
    console.log('Selected Type:', type);
    setFormData(prev => ({
      ...prev,
      type,
      otherType: type === 'Other (Specify)' ? '' : prev.otherType,
    }));
    setErrors(prev => ({...prev, type: undefined}));
  };

  const validateForm = () => {
    const newErrors: Partial<Record<keyof IncidentData, string>> = {};
    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    } else if (!/^[A-Za-z\s]+$/.test(formData.title.trim())) {
      newErrors.title = 'Please enter a valid title';
    }
    if (
      formData.type === 'Other (Specify)' &&
      formData.otherType &&
      !formData.otherType.trim()
    ) {
      newErrors.otherType = 'Please specify the incident type';
    }
    if (!formData.type) {
      newErrors.type = 'Please select the type';
    }
    if (!formData.location.trim()) {
      newErrors.location = 'Location is required';
    }
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (
      formData.location.trim() &&
      (typeof formData.latitude !== 'number' ||
        typeof formData.longitude !== 'number')
    ) {
      newErrors.location = 'Invalid location selected';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    const payload = {
      incident_title: formData.title,
      description: formData.description,
      incident_type: formData.type,
      date: formatDate(formData.date),
      time: formatTime(formData.time),
      location: formData.location,
      user_id: userId as any,
      shift_id: shiftId,
      othertype: formData.otherType || '',
    };
    console.log('CCC', payload);

    setLoading(true);
    try {
      const response = await submitIncidentReport(payload);
      console.log('CC', response);

      if (response.status === 'success') {
        setSuccessMessage('Incident report submitted successfully!');
        setFormData({
          title: '',
          type: '',
          location: '',
          date: new Date(),
          time: new Date(),
          description: '',
          otherType: '',
        });
        setErrors({});
        navigation.reset({
          index: 0,
          routes: [{name: 'Dashboard'}],
        });
      }
    } catch (error: any) {
      console.error('Error submitting report:', error);
      const errorMessage =
        error.response?.data?.message || 'An unexpected error occurred.';
      setErrors(prev => ({...prev, submit: errorMessage}));
      setSuccessMessage('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <RedlineLogo height="29" width="101" />
      </View>

      <KeyboardAvoidingView
        style={{flex: 1}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
        <ScrollView
          style={styles.scrollView}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{flexGrow: 1, paddingBottom: 20}}>
          <Text style={styles.headerText}>Incident Report</Text>
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Incident Title</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'title' && styles.inputFocused,
                  errors.title && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter incident title"
                  placeholderTextColor="#666666"
                  value={formData.title}
                  onChangeText={value => updateFormField('title', value)}
                  onFocus={() => setFocusedField('title')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.title && (
                <Text style={styles.errorText}>{errors.title}</Text>
              )}
            </View>

            <TypeDropdown
              onSelectType={handleTypeSelection}
              typeError={errors.type}
              focusedField={focusedField}
              setFocusedField={setFocusedField}
            />
            {formData.type === 'Other (Specify)' && (
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Specify Incident Type</Text>
                <View
                  style={[
                    styles.inputWrapper,
                    focusedField === 'otherType' && styles.inputFocused,
                    errors.otherType && styles.inputError,
                  ]}>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter incident type"
                    placeholderTextColor="#666666"
                    value={formData.otherType}
                    onChangeText={value =>
                      setFormData(prev => ({...prev, otherType: value}))
                    }
                    onFocus={() => setFocusedField('otherType')}
                    onBlur={() => setFocusedField(null)}
                  />
                </View>
                {errors.otherType && (
                  <Text style={styles.errorText}>{errors.otherType}</Text>
                )}
              </View>
            )}

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Incident Location</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'location' && styles.inputFocused,
                  errors.location && styles.inputError,
                ]}>
                <GooglePlacesAutocomplete
                  placeholder="Search address"
                  onPress={handleLocationSelect}
                  enablePoweredByContainer={false}
                  debounce={300}
                  textInputProps={{
                    placeholderTextColor: '#666666',
                    style: googlePlacesStyles.textInputs,
                    onFocus: () => setFocusedField('location'),
                    onBlur: () => setFocusedField(null),
                  }}
                  query={{
                    key: 'AIzaSyBPmUI0hbgP19R7hzF1yRmo4URTw7vjWpI',
                    language: 'en',
                    components: 'country:us',
                  }}
                  styles={{
                    textInput: googlePlacesStyles.textInput,
                    container: googlePlacesStyles.container,
                    listView: googlePlacesStyles.listView,
                    row: googlePlacesStyles.row,
                    separator: googlePlacesStyles.separator,
                    description: googlePlacesStyles.description,
                  }}
                  fetchDetails={true}
                  renderRow={rowData => {
                    const title = rowData.structured_formatting.main_text;
                    const address =
                      rowData.structured_formatting.secondary_text;
                    return (
                      <View>
                        <Text style={styles.mainText}>{title}</Text>
                        <Text style={styles.secondaryText}>{address}</Text>
                      </View>
                    );
                  }}
                />
              </View>
              {errors.location && (
                <Text style={styles.errorText}>{errors.location}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Incident Date</Text>
              <TouchableOpacity
                onPress={
                  Platform.OS === 'ios'
                    ? handleIOSDatePickerOpen
                    : () => setShowDatePicker(true)
                }
                style={[
                  styles.dateTimeInput,
                  focusedField === 'date' && styles.inputFocused,
                ]}>
                <Text style={styles.dateTimeText}>
                  {formatDate(formData.date)}
                </Text>
                <AntDesign name="calendar" size={20} color="#666666" />
              </TouchableOpacity>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Incident Time</Text>
              <TouchableOpacity
                onPress={
                  Platform.OS === 'ios'
                    ? handleIOSTimePickerOpen
                    : () => setShowTimePicker(true)
                }
                style={[
                  styles.dateTimeInput,
                  focusedField === 'time' && styles.inputFocused,
                ]}>
                <Text style={styles.dateTimeText}>
                  {formatTime(formData.time)}
                </Text>
                <AntDesign name="clockcircleo" size={20} color="#666666" />
              </TouchableOpacity>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Description</Text>
              <View
                style={[
                  styles.inputWrapper,
                  styles.descriptionWrapper,
                  focusedField === 'description' && styles.inputFocused,
                  errors.description && styles.inputError,
                ]}>
                <TextInput
                  style={[styles.input, styles.descriptionInput]}
                  placeholder="Describe the incident in detail..."
                  placeholderTextColor="#666666"
                  value={formData.description}
                  onChangeText={value => updateFormField('description', value)}
                  multiline
                  numberOfLines={4}
                  textAlignVertical="top"
                  onFocus={() => setFocusedField('description')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.description && (
                <Text style={styles.errorText}>{errors.description}</Text>
              )}
            </View>

            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmit}
              disabled={loading}>
              {loading ? (
                <ActivityIndicator size="large" color="black" />
              ) : (
                <Text style={styles.submitButtonText}>Submit Report</Text>
              )}
            </TouchableOpacity>
            {successMessage ? (
              <Text style={styles.successMessage}>{successMessage}</Text>
            ) : null}
            {errors.submit && (
              <Text style={styles.errorText}>{errors.submit}</Text>
            )}
          </View>

          {showDatePicker && Platform.OS === 'android' && (
            <DateTimePicker
              value={formData.date}
              mode="date"
              locale="en-US"
              display="default"
              onChange={onDateChange}
            />
          )}
          {showTimePicker && Platform.OS === 'android' && (
            <DateTimePicker
              value={formData.time}
              mode="time"
              locale="en-US"
              display="default"
              onChange={onTimeChange}
            />
          )}
        </ScrollView>
      </KeyboardAvoidingView>
      {Platform.OS === 'ios' && renderIOSDatePicker()}
      {Platform.OS === 'ios' && renderIOSTimePicker()}
    </SafeAreaView>
  );
}
