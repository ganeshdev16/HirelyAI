import React, {useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

import {RootStackScreenProps} from '../../types/navigation';
import {editJobData} from '../../types/jobDetails';
import AntDesign from 'react-native-vector-icons/AntDesign';
import 'react-native-get-random-values';
import {
  GooglePlacesAutocomplete,
  GooglePlaceData,
  GooglePlaceDetail,
} from 'react-native-google-places-autocomplete';
import RedlineLogo from '../../components/RedLineLogo';
// import {googlePlacesStyles} from '../jobDetails/GooglePlacesStyles';
import {styles} from '../jobDetails/JobDetailStyles';
import {
  getSpecificJobDetail,
  managerEditJobDetail,
  storeEditedJobDetail,
} from '../../services/api';
import {useAuth} from '../../context/AuthContext';
import {useSelector} from 'react-redux';
import {RootState} from '../../store';
import type {GooglePlacesAutocompleteRef} from 'react-native-google-places-autocomplete';
import Loader from '../../components/Loader';

const EditJobDetail: React.FC<RootStackScreenProps<'EditJobDetail'>> = ({
  route,
  navigation,
}) => {
  const {page} = route.params;
  const jobId = useSelector((state: any) => state.job.jobId);
  const shiftId = useSelector((state: RootState) => state.currentShift.shiftId);
  const {userId, role, username} = useAuth();
  const googlePlacesRef = useRef<GooglePlacesAutocompleteRef>(null);
  const [jobdata, setJobData] = useState<editJobData>();
  const [isloading, setIsLoading] = useState(false);
  const [ispageLoading, setIsPageLoading] = useState(false);
  function capitalizeName(name: string) {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
  // Store original data for comparison
  const [originalFormData, setOriginalFormData] = useState<editJobData>({
    buildingNo: '',
    gateAccess: '',
    gateAccessrestroom: '',
    propertyManagerName: '',
    propertyManagerPhone: '',
    propertyName: '',
    propertyAddress: '',
    propertyclientName: '',
    managerId: '',
    propertyclientPhonenumber: '',
    user_id: userId as string,
  });

  const [formData, setFormData] = useState<editJobData>({
    buildingNo: '',
    gateAccess: '',
    gateAccessrestroom: '',
    propertyManagerName: '',
    propertyManagerPhone: '',
    propertyName: '',
    propertyAddress: jobdata?.propertyAddress as string,
    propertyclientName: '',
    managerId: '',
    propertyclientPhonenumber: '',
    user_id: userId as string,
  });

  // Function to check if form has changes
  const hasFormChanged = (): boolean => {
    const fieldsToCompare: (keyof editJobData)[] = [
      'buildingNo',
      'gateAccess',
      'gateAccessrestroom',
      'propertyManagerName',
      'propertyManagerPhone',
      'propertyName',
      'propertyAddress',
      'propertyclientName',
      'propertyclientPhonenumber',
    ];

    return fieldsToCompare.some(field => {
      const original = originalFormData[field]?.toString().trim() || '';
      const current = formData[field]?.toString().trim() || '';
      return original !== current;
    });
  };

  useEffect(() => {
    setIsPageLoading(true);
    const fetchJobDetail = async () => {
      try {
        const response = await getSpecificJobDetail(jobId);
        if (response.message === 'success') {
          setJobData(response.data);

          const fetchedData = {
            buildingNo: response.data.buildingNo || '',
            gateAccess: response.data.gateAccess || '',
            gateAccessrestroom: response.data.gateAccessrestroom || '',
            propertyManagerName: response.data.propertyManagerName || '',
            propertyManagerPhone: response.data.propertyManagerPhone || '',
            propertyName: response.data.propertyName || '',
            propertyAddress: response.data.propertyAddress || '',
            propertyclientName: response.data.propertyclientName || '',
            propertyclientPhonenumber:
              response.data.propertyclientPhonenumber || '',
            managerId: response.data.managerId || '',
            user_id: userId as string,
          };

          // Set both original and current form data
          setOriginalFormData(fetchedData);
          setFormData(fetchedData);
        }
      } catch (error) {
        Alert.alert(
          'Error',
          'There was an error fetching the job details. Please try again later.',
        );
      } finally {
        setIsPageLoading(false);
      }
    };
    fetchJobDetail();
  }, [jobId, userId]);

  useEffect(() => {
    if (googlePlacesRef.current) {
      googlePlacesRef.current.setAddressText(formData.propertyAddress);
    }
  }, [formData.propertyAddress]);

  const [focusedField, setFocusedField] = useState<keyof editJobData | null>(
    null,
  );
  const [errors, setErrors] = useState<
    Partial<Record<keyof editJobData, string>>
  >({});
  const [showAddressModal, setShowAddressModal] = useState(false);

  const updateField = (
    field: keyof editJobData,
    value: string | boolean,
  ): void => {
    setFormData(prev => ({...prev, [field]: value}));
    if (errors[field]) {
      setErrors(prev => ({...prev, [field]: ''}));
    }
  };

  const handleLocationSelect = (
    data: GooglePlaceData,
    details: GooglePlaceDetail | null,
  ): void => {
    try {
      if (!data || !details) {
        return;
      }

      const address = data.description || '';
      const lat = details?.geometry?.location?.lat;
      const lng = details?.geometry?.location?.lng;

      if (typeof lat === 'number' && typeof lng === 'number') {
        setFormData(prev => ({
          ...prev,
          propertyAddress: address,
          latitude: lat,
          longitude: lng,
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          propertyAddress: address,
        }));
      }

      if (errors.propertyAddress) {
        setErrors(prev => ({...prev, propertyAddress: ''}));
      }

      setShowAddressModal(false);
    } catch (error) {
      Alert.alert(
        'Error',
        'There was an error selecting the address. Please try again.',
      );
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof editJobData, string>> = {};
    const clientname = formData.propertyclientName.trim();
    const propertyName = formData.propertyName.trim();

    if (!clientname) {
      newErrors.propertyclientName = 'Client name is required.';
    } else if (!/^[A-Za-z ]+$/.test(clientname)) {
      newErrors.propertyclientName = 'Name should contain only letters.';
    }

    if (!propertyName) {
      newErrors.propertyName = 'Property name is required';
    } else if (/^\d+$/.test(propertyName)) {
      newErrors.propertyName = 'Property name cannot be numbers only';
    } else if (!/^[a-zA-Z0-9 ]+$/.test(propertyName)) {
      newErrors.propertyName =
        'Property name cannot contain special characters';
    }
    if (!formData.propertyAddress?.trim()) {
      newErrors.propertyAddress = 'Property address is required';
    }
    if (!formData.propertyManagerName.trim()) {
      newErrors.propertyManagerName = 'Manager name is required.';
    } else if (!/^[A-Za-z ]+$/.test(formData.propertyManagerName.trim())) {
      newErrors.propertyManagerName =
        'Manager name should contain only letters.';
    }
    if (!formData.propertyManagerPhone?.trim()) {
      newErrors.propertyManagerPhone = 'Phone number is required';
    } else if (
      formData.propertyManagerPhone &&
      !/^(\+1[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}$/.test(
        formData.propertyManagerPhone.trim(),
      )
    ) {
      newErrors.propertyManagerPhone = 'Please enter a valid US phone number';
    }
    if (!formData.buildingNo?.trim()) {
      newErrors.buildingNo = 'Building number is required';
    }
    if (!formData.gateAccess?.trim()) {
      newErrors.gateAccess = 'Gate access is required';
    }
    if (!formData.gateAccessrestroom?.trim()) {
      newErrors.gateAccessrestroom = 'Restroom access is required';
    }

    if (!formData.propertyclientPhonenumber?.trim()) {
      newErrors.propertyclientPhonenumber = 'Phone number is required';
    } else if (
      formData.propertyclientPhonenumber &&
      !/^(\+1[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}$/.test(
        formData.propertyclientPhonenumber.trim(),
      )
    ) {
      newErrors.propertyclientPhonenumber =
        'Please enter a valid US phone number';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleRequest = async () => {
    setIsLoading(true);
    try {
      const response = await storeEditedJobDetail({
        buildingNo: formData.buildingNo,
        gateAccess: formData.gateAccess,
        gateAccessrestroom: formData.gateAccessrestroom,
        propertyManagerName: formData.propertyManagerName,
        propertyManagerPhone: formData.propertyManagerPhone,
        propertyName: formData.propertyName,
        propertyAddress: formData.propertyAddress,
        id: jobdata?._id,
        user_id: userId,
        managerId: jobdata?.managerId,
        propertyclientName: formData.propertyclientName,
        propertyclientPhonenumber: formData.propertyclientPhonenumber,
        shift_id: shiftId,
        user_name: capitalizeName(username as string),
      });
      if (response.message === 'success') {
        if (page === 'Dashboard') {
          navigation.navigate('Dashboard');
        } else {
          navigation.replace('JobList');
        }
      }
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const formatPhoneNumber = (value: string): string => {
    // Remove all non-digits
    const phoneNumber = value.replace(/\D/g, '');

    // Format with parentheses: (123) 456-7890
    if (phoneNumber.length <= 3) {
      return phoneNumber;
    } else if (phoneNumber.length <= 6) {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
    } else {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(
        3,
        6,
      )}-${phoneNumber.slice(6, 10)}`;
    }
  };

  const handlePhoneInputChange = (text: string, field: keyof editJobData) => {
    const formattedNumber = formatPhoneNumber(text);
    updateField(field, formattedNumber);
  };

  const handleEditByManager = async () => {
    setIsLoading(true);
    try {
      const response = await managerEditJobDetail({
        buildingNo: formData.buildingNo,
        gateAccess: formData.gateAccess,
        gateAccessrestroom: formData.gateAccessrestroom,
        propertyManagerName: formData.propertyManagerName,
        propertyManagerPhone: formData.propertyManagerPhone,
        propertyName: formData.propertyName,
        propertyAddress: formData.propertyAddress,
        id: jobdata?._id,
        propertyclientName: formData.propertyclientName,
        propertyclientPhonenumber: formData.propertyclientPhonenumber,
      });

      if (response.message === 'success') {
        if (page === 'Dashboard') {
          navigation.navigate('Dashboard');
        } else {
          navigation.replace('ManagerDashboard');
        }
      }
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Check if button should be disabled
  const isButtonDisabled = isloading || !hasFormChanged();

  if (ispageLoading) {
    return (
      <SafeAreaView style={styles.loaderContainer}>
        <Loader text="Loading Job Details..." />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <View style={styles.backTitleContainer}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}>
            <AntDesign name="left" size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
        <View style={styles.logo}>
          <RedlineLogo height="29" width="101" />
        </View>
      </View>

      <KeyboardAvoidingView
        style={{flex: 1}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          <Text style={styles.headerText}>Edit Job Details</Text>

          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyName' && styles.inputFocused,
                  errors.propertyName && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter property name"
                  placeholderTextColor="#666666"
                  value={formData.propertyName}
                  onChangeText={text => updateField('propertyName', text)}
                  onFocus={() => setFocusedField('propertyName')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.propertyName && (
                <Text style={styles.errorText}>{errors.propertyName}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Address</Text>
              <TouchableOpacity
                onPress={() => setShowAddressModal(true)}
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyAddress' && styles.inputFocused,
                  errors.propertyAddress && styles.inputError,
                ]}>
                {!formData.propertyAddress ? (
                  <Text style={styles.addressPlaceholderText}>
                    Search address
                  </Text>
                ) : (
                  <Text style={styles.addressValueText}>
                    {formData.propertyAddress}
                  </Text>
                )}
              </TouchableOpacity>
              {errors.propertyAddress && (
                <Text style={styles.errorText}>{errors.propertyAddress}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Manager's Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyManagerName' && styles.inputFocused,
                  errors.propertyManagerName && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter manager's name"
                  placeholderTextColor="#666666"
                  value={formData.propertyManagerName}
                  onChangeText={text =>
                    updateField('propertyManagerName', text)
                  }
                  onFocus={() => setFocusedField('propertyManagerName')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.propertyManagerName && (
                <Text style={styles.errorText}>
                  {errors.propertyManagerName}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Manager Phone Number</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyManagerPhone' &&
                    styles.inputFocused,
                  errors.propertyManagerPhone && styles.inputError,
                ]}>
                <Text style={styles.countryCode}>+1</Text>
                <View style={styles.separator} />
                <TextInput
                  style={styles.input}
                  placeholder="Enter phone number"
                  placeholderTextColor="#666666"
                  keyboardType="phone-pad"
                  value={formData.propertyManagerPhone}
                  onChangeText={text =>
                    handlePhoneInputChange(text, 'propertyManagerPhone')
                  }
                  onFocus={() => setFocusedField('propertyManagerPhone')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.propertyManagerPhone && (
                <Text style={styles.errorText}>
                  {errors.propertyManagerPhone}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Client Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyclientName' && styles.inputFocused,
                  errors.propertyclientName && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter client name"
                  placeholderTextColor="#666666"
                  value={formData.propertyclientName}
                  onChangeText={text => updateField('propertyclientName', text)}
                  onFocus={() => setFocusedField('propertyclientName')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.propertyclientName && (
                <Text style={styles.errorText}>
                  {errors.propertyclientName}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Client Phone Number</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyclientPhonenumber' &&
                    styles.inputFocused,
                  errors.propertyclientPhonenumber && styles.inputError,
                ]}>
                <Text style={styles.countryCode}>+1</Text>
                <View style={styles.separator} />
                <TextInput
                  style={styles.input}
                  placeholder="Enter client phone number"
                  placeholderTextColor="#666666"
                  keyboardType="phone-pad"
                  value={formData.propertyclientPhonenumber}
                  onChangeText={text =>
                    handlePhoneInputChange(text, 'propertyclientPhonenumber')
                  }
                  onFocus={() => setFocusedField('propertyclientPhonenumber')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.propertyclientPhonenumber && (
                <Text style={styles.errorText}>
                  {errors.propertyclientPhonenumber}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Building No. (limit of 10)</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'buildingNo' && styles.inputFocused,
                  errors.buildingNo && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter building number"
                  placeholderTextColor="#666666"
                  keyboardType="numeric"
                  maxLength={10}
                  value={formData.buildingNo}
                  onChangeText={text => updateField('buildingNo', text)}
                  onFocus={() => setFocusedField('buildingNo')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.buildingNo && (
                <Text style={styles.errorText}>{errors.buildingNo}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Gate Access</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'gateAccess' && styles.inputFocused,
                  errors.gateAccess && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter Gate Access"
                  placeholderTextColor="#666666"
                  value={formData.gateAccess}
                  onChangeText={text => updateField('gateAccess', text)}
                  onFocus={() => setFocusedField('gateAccess')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.gateAccess && (
                <Text style={styles.errorText}>{errors.gateAccess}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Restroom Access</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'gateAccessrestroom' && styles.inputFocused,
                  errors.gateAccessrestroom && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter Restroom Access"
                  placeholderTextColor="#666666"
                  value={formData.gateAccessrestroom}
                  onChangeText={text => updateField('gateAccessrestroom', text)}
                  onFocus={() => setFocusedField('gateAccessrestroom')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.gateAccessrestroom && (
                <Text style={styles.errorText}>
                  {errors.gateAccessrestroom}
                </Text>
              )}
            </View>

            <Pressable
              disabled={isButtonDisabled}
              onPress={() => {
                if (validateForm()) {
                  if (role === 'Manager') {
                    handleEditByManager();
                  } else if (role === 'Guard') {
                    handleRequest();
                  }
                }
              }}
              style={[
                styles.submitButton,
                isButtonDisabled && styles.disablebtn,
              ]}>
              {isloading ? (
                <ActivityIndicator size="small" color="black" />
              ) : (
                <Text
                  style={[
                    styles.submitButtonText,
                    isButtonDisabled && styles.disablebtntxt,
                  ]}>
                  {role === 'Guard' ? 'Request' : 'Apply Changes'}
                </Text>
              )}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={showAddressModal}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setShowAddressModal(false)}
        onShow={() => {
          // Focus the input after a small delay to ensure the modal is fully rendered
          setTimeout(() => {
            googlePlacesRef.current?.focus();
          }, 100);
        }}>
        <SafeAreaView style={styles.modalSafeArea}>
          <View style={styles.modalHeaderContainer}>
            <TouchableOpacity
              onPress={() => setShowAddressModal(false)}
              style={styles.modalBackButton}>
              <AntDesign name="left" size={20} color="#FFFFFF" />
            </TouchableOpacity>

            <Text style={styles.modalTitleText}>Property Address</Text>
          </View>

          <View style={[styles.searchContainer, styles.noTopBorder]}>
            <GooglePlacesAutocomplete
              ref={googlePlacesRef}
              placeholder="Search by address"
              onPress={handleLocationSelect}
              enablePoweredByContainer={false}
              fetchDetails={true}
              debounce={300}
              query={{
                key: '',
                language: 'en',
                components: 'country:us',
              }}
              styles={{
                container: {
                  flex: 1,
                  width: '100%',
                  backgroundColor: '#000000',
                  borderWidth: 0,
                },
                textInputContainer: {
                  width: '100%',
                  backgroundColor: 'transparent',
                  borderTopWidth: 0,
                  borderBottomWidth: 0,
                  paddingHorizontal: 10,
                },
                textInput: {
                  height: 60,
                  color: '#FFFFFF',
                  fontSize: 16,
                  backgroundColor: '#090909',
                  borderRadius: 16,
                  paddingHorizontal: 16,
                  borderWidth: 2,
                  borderColor: '#242424',
                  fontFamily: 'Inter_18pt-Regular',
                  paddingLeft: 40,
                },
                listView: {
                  flex: 1,
                  width: '100%',
                  marginTop: 10,
                  backgroundColor: '#090909',
                  borderRadius: 16,
                  borderWidth: 2,
                  borderColor: '#242424',
                  overflow: 'hidden',
                },
                row: {
                  padding: 15,
                  borderBottomWidth: 1,
                  borderBottomColor: '#242424',
                  backgroundColor: '#090909',
                },
                separator: {
                  height: 1,
                  backgroundColor: '#242424',
                },
                description: {
                  color: '#FFFFFF',
                  fontFamily: 'Inter_18pt-Regular',
                },
                poweredContainer: {
                  backgroundColor: '#090909',
                  display: 'none',
                },
              }}
              renderLeftButton={() => (
                <View style={styles.searchIconContainer}>
                  <AntDesign name="search1" size={20} color="#666666" />
                </View>
              )}
              renderRow={data => (
                <View style={styles.addressRow}>
                  <Text style={styles.addressText}>{data.description}</Text>
                </View>
              )}
              keyboardShouldPersistTaps="always"
            />
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
};

export default EditJobDetail;
