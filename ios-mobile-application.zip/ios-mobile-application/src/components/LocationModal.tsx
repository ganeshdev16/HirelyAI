import React, {useState, useEffect, useCallback} from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Linking,
  Alert,
  PermissionsAndroid,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import {useLocationTracker} from '../hooks/useLocationTracker';
import {useSelector, useDispatch} from 'react-redux';
import Geolocation from '@react-native-community/geolocation';

interface SettingsModalProps {
  isVisible: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({
  isVisible,
  onClose,
  onOpenSettings,
}) => {
  return (
    <Modal visible={isVisible} transparent={true} animationType="fade">
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Enable Location</Text>
          <Text style={styles.modalText}>
            Please enable location services to use this feature.
          </Text>
          <View style={styles.modalButtons}>
            <TouchableOpacity style={styles.modalButton} onPress={onClose}>
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, styles.modalButtonPrimary]}
              onPress={onOpenSettings}>
              <Text
                style={[styles.modalButtonText, styles.modalButtonTextPrimary]}>
                Open Settings
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const GlobalSettingsModal: React.FC = () => {
  const dispatch = useDispatch();
  const isLocationEnabled = useSelector(
    (state: any) => state.location.isLocationEnabled,
  );
  const [isModalVisible, setIsModalVisible] = useState(!isLocationEnabled);
  const [isChecking, setIsChecking] = useState(false);

  /**
   * Checks if location services are enabled and permission is granted
   * @returns Promise<boolean> - true if location is available, false otherwise
   */
  const checkLocation = useCallback(async (): Promise<boolean> => {
    try {
      if (Platform.OS === 'ios') {
        return new Promise(resolve => {
          Geolocation.getCurrentPosition(
            position => {
              // Successfully got location, services are enabled
              resolve(true);
            },
            error => {
              // Check error codes to determine if location is disabled
              switch (error.code) {
                case 1: // PERMISSION_DENIED
                  console.log('Location permission denied');
                  resolve(false);
                  break;
                case 2: // POSITION_UNAVAILABLE
                  console.log('Location position unavailable');
                  resolve(false);
                  break;
                case 3: // TIMEOUT
                  console.log('Location request timeout');
                  // Timeout doesn't necessarily mean location is disabled
                  resolve(true);
                  break;
                default:
                  console.log('Unknown location error:', error.message);
                  resolve(false);
                  break;
              }
            },
            {
              enableHighAccuracy: false,
              timeout: 5000,
              maximumAge: 60000,
            },
          );
        });
      } else {
        // Android handling
        try {
          const granted = await PermissionsAndroid.check(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          );
          return granted;
        } catch (err) {
          console.log('Error checking Android location permission:', err);
          return false;
        }
      }
    } catch (error) {
      console.error('Error in checkLocation:', error);
      return false;
    }
  }, []);

  // Function to check location and update state
  const checkLocationServices = useCallback(async () => {
    if (isChecking) return; // Prevent multiple simultaneous checks

    setIsChecking(true);
    try {
      const isEnabled = await checkLocation(); // Using standalone function
      // Update Redux store with location status
      // dispatch(setLocationEnabled(isEnabled));

      // Update modal visibility based on location status
      setIsModalVisible(!isEnabled);

      return isEnabled;
    } catch (error) {
      console.error('Error checking location services:', error);
      return false;
    } finally {
      setIsChecking(false);
    }
  }, [dispatch, isChecking]);

  // Sync modal visibility with location status
  useEffect(() => {
    setIsModalVisible(!isLocationEnabled);
  }, [isLocationEnabled]);

  // Check location services when component mounts
  useEffect(() => {
    checkLocationServices();
  }, []);

  // Recheck location services status when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      checkLocationServices();
    }, [checkLocationServices]),
  );

  const handleClose = () => {
    setIsModalVisible(false);
  };

  const handleOpenSettings = async () => {
    try {
      if (Platform.OS === 'ios') {
        const supported = await Linking.canOpenURL(
          'App-Prefs:Privacy&path=LOCATION',
        );
        if (supported) {
          await Linking.openURL('App-Prefs:Privacy&path=LOCATION');
        } else {
          await Linking.openSettings();
        }
      } else {
        // Android
        await Linking.openSettings();
      }

      // Recheck status after a delay (user might have changed settings)
      setTimeout(() => {
        checkLocationServices();
      }, 1000);
    } catch (error) {
      console.error('Error opening settings:', error);
      Alert.alert('Error', 'Unable to open location settings.');
    }
  };

  return (
    <SettingsModal
      isVisible={isModalVisible}
      onClose={handleClose}
      onOpenSettings={handleOpenSettings}
    />
  );
};

export default GlobalSettingsModal;

export const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1C1C1E',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 14,
    color: '#8E8E93',
    textAlign: 'center',
    marginBottom: 20,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#3A3A3C',
  },
  modalButtonPrimary: {
    backgroundColor: '#FF0000',
    borderColor: '#FF0000',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  modalButtonTextPrimary: {
    color: '#FFFFFF',
  },
});
