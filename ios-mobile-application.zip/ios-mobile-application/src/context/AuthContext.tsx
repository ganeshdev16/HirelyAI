import React, {createContext, useState, useContext, useEffect} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {AuthContextType, AuthResponse, AuthState} from '../types/auth';
import {refreshAccessToken, ValidateAccesToken} from '../services/api';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{children: React.ReactNode}> = ({
  children,
}) => {
  const [authState, setAuthState] = useState<AuthState>({
    accessToken: null,
    refreshToken: null,
    userId: null,
    role: undefined,
    username: null,
  });

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadStoredAuth = async () => {
      try {
        const [accessToken, refreshToken, userId, role, username] =
          await Promise.all([
            AsyncStorage.getItem('userToken'),
            AsyncStorage.getItem('refreshToken'),
            AsyncStorage.getItem('userId'),
            AsyncStorage.getItem('role'),
            AsyncStorage.getItem('username'),
          ]);
        if (accessToken) {
          const validateResponse = await ValidateAccesToken(accessToken);

          if (validateResponse.status === 'success') {
            setAuthState({
              accessToken,
              refreshToken,
              userId,
              username: username ? JSON.parse(username) : null,
              role: role ? JSON.parse(role) : null,
            });
          } else if (validateResponse.status === 'expired' && refreshToken) {
            try {
              const refreshAccessTokenResponse = await refreshAccessToken(
                refreshToken,
              );
              console.log(
                'Refresh Access Token Response:',
                refreshAccessTokenResponse,
              );
              // Remove the previous access token
              await AsyncStorage.removeItem('userToken');
              // Set the new access token
              await AsyncStorage.setItem(
                'userToken',
                refreshAccessTokenResponse.access_token,
              );
              setAuthState({
                accessToken: refreshAccessTokenResponse.access_token,
                refreshToken,
                userId,
                role: role ? JSON.parse(role) : null,
                username: username ? JSON.parse(username) : null,
              });
            } catch (error) {
              await signOut(); // Sign out if refresh token is invalid
            }
          } else {
            await signOut(); // If access token is invalid and no refresh token, sign out
          }
        }
      } catch (error) {
        console.error('Error loading auth state:', error);
        await signOut();
      } finally {
        setIsLoading(false);
      }
    };

    loadStoredAuth();
  }, []);

  const setAuthTokens = async (response: AuthResponse) => {
    try {
      await AsyncStorage.setItem('userToken', response.access_token);
      await AsyncStorage.setItem('refreshToken', response.refresh_token);
      await AsyncStorage.setItem('userId', response.user_id);
      await AsyncStorage.setItem('role', JSON.stringify(response.role));
      await AsyncStorage.setItem('username', JSON.stringify(response.username));

      setAuthState({
        accessToken: response.access_token,
        refreshToken: response.refresh_token,
        userId: response.user_id,
        role: response.role,
        username: response.username,
      });
    } catch (error) {
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await AsyncStorage.multiRemove([
        'userToken',
        'refreshToken',
        'userId',
        'role',
      ]);
      setAuthState({
        accessToken: null,
        refreshToken: null,
        userId: null,
        role: undefined,
        username: null,
      });
    } catch (error) {
      console.error('Error during sign out:', error);
    }
  };

  const value = {
    ...authState,
    setAuthTokens,
    signOut,
    isAuthenticated: !!authState.accessToken,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthProvider;
