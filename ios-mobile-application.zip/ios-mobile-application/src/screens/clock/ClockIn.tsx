import React, {useState, useEffect} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Platform,
  Image,
} from 'react-native';
import Svg, {G, Line, Circle} from 'react-native-svg';
import type {RootStackScreenProps} from '../../types/navigation';
import GlobalSettingsModal from '../../components/LocationModal';

export default function ClockInScreen({
  navigation,
}: RootStackScreenProps<'ClockIn'>) {
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date): string => {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  const minuteRotation = (currentTime.getMinutes() / 60) * 360;
  const hourRotation =
    (((currentTime.getHours() % 12) + currentTime.getMinutes() / 60) / 12) *
    360;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Image
          source={require('../../assets/images/redline-logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      <View style={styles.mainContent}>
        <View style={styles.timeDisplay}>
          <Text style={styles.timeLabel}>CURRENT LOCAL TIME</Text>
          <Text style={styles.digitalTime}>{formatTime(currentTime)}</Text>
        </View>

        <View style={styles.clockContainer}>
          <Image
            source={require('../../assets/images/clock.jpg')}
            style={styles.clockBackground}
            resizeMode="contain"
          />
          <View style={styles.clockFace}>
            <Svg width="100%" height="100%" viewBox="0 0 200 200">
              {/* Hour hand */}
              <Line
                x1="100"
                y1="100"
                x2="100"
                y2="60"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                transform={`rotate(${hourRotation}, 100, 100)`}
              />
              {/* Minute hand - split into two parts */}
              <G transform={`rotate(${minuteRotation}, 100, 100)`}>
                {/* Inner half - white */}
                <Line
                  x1="100"
                  y1="100"
                  x2="100"
                  y2="50"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="butt"
                />
                {/* Outer half - red */}
                <Line
                  x1="100"
                  y1="50"
                  x2="100"
                  y2="30"
                  stroke="#DC2626"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </G>
              {/* Center Dot */}
              <Circle cx="100" cy="100" r="5" fill="white" />
            </Svg>
          </View>
        </View>

        <Text style={styles.bottomText}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod
        </Text>

        <TouchableOpacity
          style={styles.clockInButton}
          // onPress={() => navigation.navigate('Validation')}
        >
          <Text style={styles.clockInText}>Clock in</Text>
        </TouchableOpacity>
      </View>
      {/* <GlobalSettingsModal /> */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 8,
    top: 30,
  },
  mainContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  timeDisplay: {
    alignItems: 'center',
    marginBottom: 32,
  },
  timeLabel: {
    color: '#6B7280',
    fontSize: 14,
    marginBottom: 8,
  },
  digitalTime: {
    fontSize: 72,
    fontWeight: 'bold',
    color: '#FFFFFF',
    letterSpacing: 2,
  },
  logo: {
    position: 'absolute',
    left: 262,
    top: 40,
    width: 112,
    height: 35,
    paddingVertical: 13,
    paddingHorizontal: 16,
  },
  clockContainer: {
    width: 256,
    height: 256,
    marginBottom: 32,
    position: 'relative',
  },
  clockBackground: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  clockFace: {
    width: '100%',
    height: '100%',
    position: 'relative',
  },
  centerDot: {
    position: 'absolute',
    width: 12,
    height: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 6,
    top: '50%',
    left: '50%',
    marginLeft: -6,
    marginTop: -6,
  },
  bottomText: {
    color: '#4B5563',
    textAlign: 'center',
    fontSize: 14,
    maxWidth: 320,
    marginBottom: 32,
    paddingHorizontal: 16,
  },
  clockInButton: {
    width: '100%',
    maxWidth: 448,
    backgroundColor: '#DC2626',
    paddingVertical: 16,
    borderRadius: 6,
    marginBottom: 32,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: {width: 0, height: 2},
        shadowOpacity: 0.25,
        shadowRadius: 4,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  clockInText: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '600',
  },
});
