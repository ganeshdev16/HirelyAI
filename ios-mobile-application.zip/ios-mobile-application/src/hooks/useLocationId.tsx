import {useState, useEffect} from 'react';
import {getuserhomebaseID} from '../services/api';

const useLocationId = (userId: string | null) => {
  const [locationId, setLocationId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLocation = async () => {
      if (!userId) return;

      setLoading(true);
      try {
        const response = await getuserhomebaseID(userId);
        if (response.message === 'success') {
          setLocationId(response.data.homebase_location_id);
        } else {
          setError('Failed to fetch location ID');
        }
      } catch (err) {
        setError('An error occurred while fetching location ID');
      } finally {
        setLoading(false);
      }
    };

    fetchLocation();
  }, [userId]);

  return {locationId, loading, error};
};

export default useLocationId;
