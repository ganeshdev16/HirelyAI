declare module '@env' {
    export const API_BASE_URL: string;
    export const SIGNUP_ENDPOINT: string;
    export const LOGIN_ENDPOINT: string;
    export const FORGOT_PASSWORD_ENDPOINT: string;
    export const FORGOT_PASSWORD_UPDATE: string;
    export const VERIFY_EMAIL: string;
    export const WEB_SOCKET_URI: string;
}

