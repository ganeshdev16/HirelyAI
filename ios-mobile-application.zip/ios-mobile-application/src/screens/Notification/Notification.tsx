/* eslint-disable @typescript-eslint/no-shadow */
import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  SafeAreaView,
  StatusBar,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import {Swipeable} from 'react-native-gesture-handler';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {RootStackScreenProps} from '../../types/navigation';
import GlobalSettingsModal from '../../components/LocationModal';
import {
  getAllNotifications,
  getIncidentlNotifications,
  handleDeleteNotification,
} from '../../services/api';
import {useAuth} from '../../context/AuthContext';
import RedlineLogo from '../../components/RedLineLogo';
import {NOTIFICATIONS} from '../../types/notifications';

export default function Notification({
  navigation,
}: Readonly<RootStackScreenProps<'Notification'>>) {
  const {userId} = useAuth();
  const [notification, setNotification] = useState<NOTIFICATIONS[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [pendingDelete, setPendingDelete] = useState<NOTIFICATIONS | null>(
    null,
  );

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        setIsLoading(true);

        // Fetch both types of notifications concurrently
        const [allNotificationsResponse, incidentNotificationsResponse] =
          await Promise.all([
            getAllNotifications(userId as string),
            getIncidentlNotifications(userId as string),
          ]);

        // Combine notifications (assuming both return { notifications: [...] })
        const allNotifications = allNotificationsResponse.notifications || [];
        const incidentNotifications =
          incidentNotificationsResponse.notifications || [];

        // Filter out archived notifications and merge
        const combinedNotifications = [
          ...allNotifications.filter(
            (n: NOTIFICATIONS) => n.status !== 'archived',
          ),
          ...incidentNotifications.filter(
            (n: NOTIFICATIONS) => n.status !== 'archived',
          ),
        ];

        // Remove duplicates if needed (e.g., by _id)
        const uniqueNotifications = Array.from(
          new Map(combinedNotifications.map(n => [n._id, n])).values(),
        );

        setNotification(uniqueNotifications);
      } catch (error) {
        throw error;
      } finally {
        setIsLoading(false);
      }
    };

    if (userId) {
      fetchNotifications();
    }
  }, [userId]);
  console.log(notification);

  const handleArchive = (id: string) => {
    const notificationToDelete = notification.find(n => n._id === id);
    if (notificationToDelete) {
      // Temporarily remove from list and show undo option
      setPendingDelete(notificationToDelete);
      setNotification(prev => prev.filter(n => n._id !== id));
    }
  };

  const handleUndo = () => {
    if (pendingDelete) {
      // Add the notification back to the list
      setNotification(prev => [pendingDelete, ...prev]);
      setPendingDelete(null);
    }
  };

  const handleCancel = async () => {
    if (pendingDelete) {
      try {
        const response = await handleDeleteNotification(pendingDelete._id);
        console.log('Delete response:', response);

        if (response.message !== 'success') {
          setNotification(prev => [pendingDelete, ...prev]);
          console.warn('Failed to delete notification');
        }
      } catch (error) {
        // If error occurs, add it back to the list
        setNotification(prev => [pendingDelete, ...prev]);
        console.error('Error deleting notification:', error);
      } finally {
        setPendingDelete(null);
      }
    }
  };

  function formatDate(dateString: string): string {
    if (!dateString.endsWith('Z') && !dateString.includes('+')) {
      dateString += 'Z'; // treat as UTC
    }
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      hour: 'numeric',
      minute: 'numeric',
      timeZone: 'America/New_York',
      hour12: true,
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };

    return date.toLocaleString('en-US', options);
  }

  const renderRightActions = (id: string) => (
    <View style={styles.rightAction}>
      <TouchableOpacity onPress={() => handleArchive(id)}>
        <Text style={styles.deleteText}>Delete</Text>
      </TouchableOpacity>
    </View>
  );
  console.log(notification);

  return (
    <GestureHandlerRootView style={styles.gestureHandler}>
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />

        {/* Header Section */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}>
            <AntDesign name="left" size={20} color="#FFFFFF" />
          </TouchableOpacity>
          <RedlineLogo height="29" width="101" />
        </View>
        <View style={styles.bellContainer}>
          <Image
            source={require('../../assets/images/Bell-icon.png')}
            style={styles.Bellicon}
          />
        </View>

        {/* Main Card Section */}
        <View style={styles.mainCard}>
          {isLoading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#FFFFFF" />
              <Text style={styles.loadingText}>Loading Notifications...</Text>
            </View>
          ) : notification.length > 0 ? (
            <ScrollView
              style={styles.scrollView}
              contentContainerStyle={styles.scrollContent}
              showsVerticalScrollIndicator={false}>
              {notification.map((notification: NOTIFICATIONS) => (
                <Swipeable
                  key={notification._id}
                  renderRightActions={() =>
                    renderRightActions(notification._id)
                  }>
                  <View style={styles.notification}>
                    <Text style={styles.cardTitle}>{notification.type}</Text>
                    <View style={styles.cardRow}>
                      <Text style={styles.cardDetails}>
                        {notification.message}
                      </Text>
                    </View>

                    <>
                      <View style={styles.cardRow}>
                        <Text style={styles.cardDetailsTitle}>Time:</Text>
                        <Text style={styles.cardDetails}>
                          {formatDate(notification.created_at)}
                        </Text>
                      </View>
                      {notification.location && (
                        <View style={styles.cardRow}>
                          <Text style={styles.cardDetailsTitle}>Location:</Text>
                          <Text style={styles.cardDetails}>
                            {notification.location}
                          </Text>
                        </View>
                      )}
                    </>

                    <View style={styles.verticalDivider} />
                  </View>
                </Swipeable>
              ))}
            </ScrollView>
          ) : (
            <View style={styles.noNotificationContainer}>
              <Text style={styles.noNotificationText}>
                All caught up! No new Notifications.
              </Text>
            </View>
          )}
        </View>

        {/* Undo Snackbar */}
        {pendingDelete && (
          <View style={styles.undoContainer}>
            <Text style={styles.undoText}>Notification deleted</Text>
            <View style={styles.undoButtons}>
              <TouchableOpacity onPress={handleUndo}>
                <Text style={styles.undoButton}>Undo</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleCancel}>
                <Text style={styles.cancelButton}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </SafeAreaView>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  gestureHandler: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 10,
  },
  logo: {
    width: 112,
    height: 35,
  },
  bellContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  Bellicon: {
    width: 18,
    height: 22,
    marginRight: 1,
    position: 'absolute',
    right: 10,
  },
  mainCard: {
    flex: 1,
    margin: 16,
    backgroundColor: '#090909',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#242424',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 16,
  },
  notification: {
    paddingVertical: 7,
  },
  cardTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  cardRow: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  cardDetailsTitle: {
    color: '#5A5A5A',
    fontSize: 14,
    fontWeight: '500',
    marginRight: 4,
  },
  cardDetails: {
    color: '#AAAAAA',
    fontSize: 14,
    fontWeight: '400',
  },
  verticalDivider: {
    height: 1,
    backgroundColor: '#5A5A5A',
    marginVertical: 16,
  },
  rightAction: {
    height: 90,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 10,
    marginVertical: 4,
  },
  deleteText: {
    color: 'red',
    fontSize: 14,
    fontWeight: 600,
  },
  undoContainer: {
    backgroundColor: '#333333',
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  undoText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  undoButtons: {
    flexDirection: 'row',
  },
  undoButton: {
    color: '#00FF00',
    fontSize: 16,
    marginHorizontal: 8,
  },
  cancelButton: {
    color: '#FF0000',
    fontSize: 16,
    marginHorizontal: 8,
  },
  noNotificationContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  noNotificationText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginTop: 10,
  },
  backButton: {
    width: 38,
    height: 38,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,

    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 10,
  },
});
