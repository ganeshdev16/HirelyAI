import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { UserState, UserProfile } from '../../types/user';

const initialState: UserState = {
  profile: null,
  settings: {},
  loading: false,
  error: null,
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setProfile: (state, action: PayloadAction<UserProfile>) => {
      state.profile = action.payload;
    },
    setSettings: (state, action: PayloadAction<Record<string, any>>) => {
      state.settings = action.payload;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
  },
});

export const { setProfile, setSettings, setLoading, setError } = userSlice.actions;
export default userSlice.reducer;
