export interface IncidentData {
  title: string;
  type: string;
  location: string;
  latitude?: number;
  longitude?: number;
  date: Date;
  time: Date;
  description: string;
  otherType?: string;
}
