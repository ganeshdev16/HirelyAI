import React, {useState, useRef} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  Platform,
  ActivityIndicator,
  Alert,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import type {RootStackScreenProps} from '../../types/navigation';
import {verifyEmail} from '../../services/api';
import RedlineLogo from '../../components/RedLineLogo';
import ProfileIcon from '../../components/ProfileIcon';

export default function OtpVerification({
  route,
  navigation,
}: RootStackScreenProps<'OtpVerification'>) {
  const {email} = route.params;
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const inputRefs = useRef<Array<TextInput | null>>([]);

  const handleOtpChange = (text: string, index: number) => {
    setError('');
    const newOtp = [...otp];
    newOtp[index] = text;
    setOtp(newOtp);

    if (text && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (event: any, index: number) => {
    if (event.nativeEvent.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
      const newOtp = [...otp];
      newOtp[index - 1] = '';
      setOtp(newOtp);
    }
  };

  const handleVerify = async () => {
    // Check if any OTP digit is empty
    if (otp.some(digit => !digit)) {
      setError('Please enter full OTP');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const payload = {
        email: email,
        confirmationCode: otp.join(''),
      };

      const response = await verifyEmail(payload);

      // Check if the response is successful
      if (response.status === 'success') {
        navigation.navigate('SignIn');
      } else if (response && response.message) {
        // Display backend error message
        if (response.message.toLowerCase().includes('incorrect')) {
          setError('Incorrect otp. Please try again.');
        } else if (response.message.toLowerCase().includes('expired')) {
          setError('The otp has expired. Please request a new one.');
        } else {
          setError(response.message);
        }
      } else {
        setError('Verification failed. Please try again.');
      }
    } catch (caughtError: any) {
      console.error('Verification error:', caughtError);

      if (caughtError.response) {
        // Handle different response statuses
        if (caughtError.response.status === 200) {
          navigation.navigate('SignIn');
        } else if (caughtError.response.status === 400) {
          setError('Email or otp is missing. Please try again.');
        } else if (caughtError.response.status === 401) {
          setError('Incorrect otp. Please try again.');
        } else if (caughtError.response.status === 410) {
          setError('The otp has expired. Please request a new one.');
        } else if (caughtError.response.status === 422) {
          setError('Invalid otp format. Please check and try again.');
        } else if (caughtError.response.status === 404) {
          setError('User not found. Please check the email and try again.');
        } else if (caughtError.response.status === 500) {
          setError('An unexpected error occurred. Please try again later.');
        } else {
          setError('Verification failed. Please try again.');
        }
      } else if (caughtError.message?.includes('Network')) {
        Alert.alert('Error', 'Network error. Please check your connection.');
      } else {
        Alert.alert('Error', 'Verification failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Sign Up</Text>
        <View style={styles.logo}>
          <RedlineLogo height="29" width="101" />
        </View>
      </View>

      <View style={styles.contentContainer}>
        <ProfileIcon />
        <View style={styles.otpSection}>
          <Text style={styles.enterOtpText}>Enter OTP</Text>
          <Text style={styles.subText}>
            Please enter the verification code sent to {email}
          </Text>

          {error ? (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <View style={styles.otpContainer}>
            {otp.map((digit, index) => (
              <TextInput
                key={index}
                ref={ref => {
                  inputRefs.current[index] = ref;
                }}
                style={[
                  styles.otpInput,
                  error && styles.otpInputError,
                  digit && styles.otpInputFilled,
                ]}
                value={digit}
                onChangeText={text => handleOtpChange(text, index)}
                onKeyPress={event => handleKeyPress(event, index)}
                keyboardType="number-pad"
                maxLength={1}
                placeholder=""
                placeholderTextColor="#666666"
                textAlign="center"
                textAlignVertical="bottom"
                editable={!loading}
              />
            ))}
          </View>
        </View>

        <TouchableOpacity
          onPress={handleVerify}
          disabled={loading}
          style={styles.verifyButton}>
          <LinearGradient
            colors={['#B40B0B', '#B21F1F']}
            style={[styles.gradientButton, loading && styles.disabledButton]}>
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.buttonText}>Verify OTP</Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#090909',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 0 : 40,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 5,
  },
  headerText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
    flex: 1,
  },
  logo: {
    width: 150,
    height: 40,
  },
  contentContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 40,
  },
  profileSection: {
    width: '100%',
    height: 150,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  lineContainer: {
    position: 'absolute',
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    height: '100%',
  },
  leftLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#242424',
    marginRight: 74,
  },
  rightLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#242424',
    marginLeft: 74,
  },
  profileContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#090909',
    zIndex: 2,
  },
  profileImage: {
    width: 148,
    height: 148,
    tintColor: '#666666',
  },
  otpSection: {
    width: '100%',
    alignItems: 'flex-start',
    marginTop: 20,
  },
  enterOtpText: {
    color: '#FFFFFF',
    fontSize: 18,
    marginBottom: 8,
    textAlign: 'left',
    fontFamily: 'Inter_18pt-Regular',
  },
  subText: {
    color: '#666666',
    fontSize: 14,
    marginBottom: 24,
  },
  errorContainer: {
    backgroundColor: 'rgba(255, 59, 48, 0.1)',
    borderRadius: 8,
    padding: 12,
    width: '100%',
    marginBottom: 16,
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 14,
    textAlign: 'center',
  },
  otpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: '100%',
    marginBottom: 32,
    gap: 8,
  },
  otpInput: {
    width: 50,
    height: 50,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#3A3A3C',
    backgroundColor: '#090909',
    color: '#FFFFFF',
    fontSize: 24,
    padding: Platform.select({ios: 0, android: 0}),
    textAlign: 'center',
    textAlignVertical: 'bottom',
    paddingBottom: Platform.select({ios: 10, android: 6}),
    justifyContent: 'flex-end',
    alignItems: 'center',
    includeFontPadding: false,
    lineHeight: Platform.select({ios: 24, android: 25}),
  },
  otpInputError: {
    borderColor: '#FF3B30',
  },
  otpInputFilled: {
    borderColor: '#B40B0B',
  },
  verifyButton: {
    width: '100%',
    marginBottom: 16,
  },
  gradientButton: {
    width: '100%',
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledButton: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-SemiBold',
  },
});
