/* eslint-disable react-hooks/exhaustive-deps */
import {useEffect, useCallback, useRef} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import Geolocation from '@react-native-community/geolocation';
import notifee, {AndroidImportance} from '@notifee/react-native';
import messaging from '@react-native-firebase/messaging';
import {PermissionsAndroid, Platform, Alert, Linking} from 'react-native';

import {
  setError,
  setIsInsideCircle,
  setCurrentLocation,
  setIsTracking,
  setLocationHistory,
} from '../store/slices/locationSlice';
import {LocationDetails} from '../types/location';
import {websocketService} from '../services/websocketService';

const RADIUS = 500; // Radius in meters

// Enhanced location smoothing configuration
const LOCATION_CONFIG = {
  enableHighAccuracy: true,
  timeout: 10000,
  maximumAge: 3000,
  distanceFilter: 15,
  accuracyThreshold: 16, // Only accept locations with accuracy better than 15m
  smoothingFactor: 0.3, // For location smoothing (0-1, lower = more smoothing)
  bufferSize: 4, // Number of recent locations to average
  interval: 5000,
  fastestInterval: 4000,
};

export const useLocationTracker = () => {
  const dispatch = useDispatch();
  const watchIdRef = useRef<number | null>(null);
  const locationBuffer = useRef<LocationDetails[]>([]);
  const lastValidLocation = useRef<LocationDetails | null>(null);
  const shiftId = useSelector((state: any) => state.currentShift.shiftId);

  // Helper function to smooth location using weighted average
  const smoothLocation = useCallback(
    (
      buffer: LocationDetails[],
      lastLocation: LocationDetails | null,
      smoothingFactor: number,
    ) => {
      if (buffer.length === 0) return null;

      // If we only have one location, return it
      if (buffer.length === 1) {
        return buffer[0];
      }

      // Calculate weighted average of recent locations
      let totalWeight = 0;
      let weightedLat = 0;
      let weightedLng = 0;

      buffer.forEach((location, index) => {
        // Give more weight to recent locations
        const weight = (index + 1) / buffer.length;
        totalWeight += weight;
        weightedLat += location.latitude * weight;
        weightedLng += location.longitude * weight;
      });

      const averagedLocation = {
        ...buffer[buffer.length - 1], // Keep other properties from latest
        latitude: weightedLat / totalWeight,
        longitude: weightedLng / totalWeight,
      };

      // Apply smoothing with previous location if available
      if (lastLocation && smoothingFactor > 0) {
        return {
          ...averagedLocation,
          latitude:
            lastLocation.latitude +
            (averagedLocation.latitude - lastLocation.latitude) *
              smoothingFactor,
          longitude:
            lastLocation.longitude +
            (averagedLocation.longitude - lastLocation.longitude) *
              smoothingFactor,
        };
      }

      return averagedLocation;
    },
    [],
  );

  const requestLocationPermission = async () => {
    try {
      if (Platform.OS === 'ios') {
        return new Promise(resolve => {
          Geolocation.requestAuthorization(
            () => {
              console.log('iOS location permission granted');
              resolve(true);
            },
            error => {
              console.log('iOS location permission denied:', error);
              if (error.code === 1) {
                // Permission denied - show alert to go to settings
                Alert.alert(
                  'Location Permission Required',
                  'Please enable location access in Settings to use this feature.',
                  [
                    {text: 'Cancel', style: 'cancel'},
                    {
                      text: 'Open Settings',
                      onPress: () => Linking.openSettings(),
                    },
                  ],
                );
              }
              resolve(false);
            },
          );
        });
      } else {
        // Android logic (your existing code)
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Location Permission',
            message:
              'This app needs access to your location to track your position.',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          },
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      }
    } catch (err) {
      console.error('Permission request error:', err);
      dispatch(setError('Failed to request location permission'));
      return false;
    }
  };

  const requestNotificationPermission = async () => {
    try {
      if (Platform.OS === 'android' && Platform.Version >= 33) {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
          {
            title: 'Notification Permission',
            message: 'This app requires permission to send notifications',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Deny',
            buttonPositive: 'Allow',
          },
        );

        if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
          Alert.alert(
            'Permission Denied',
            'Please enable notifications in settings',
          );
        }
      } else {
        await messaging().requestPermission();
        await notifee.requestPermission();
      }
    } catch (err) {
      console.error('Notification permission error:', err);
    }
  };

  // Register FCM token (replaces PushNotification.configure's onRegister)
  const registerDeviceForPush = useCallback(async () => {
    try {
      const token = await messaging().getToken();
      console.log('FCM TOKEN:', token);

      messaging().onTokenRefresh(newToken => {
        console.log('Refreshed TOKEN:', newToken);
      });
    } catch (error) {
      console.error('Error getting FCM token:', error);
    }
  }, []);

  const createLocationChannel = useCallback(async () => {
    try {
      await notifee.createChannel({
        id: 'location-channel',
        name: 'Location Alerts',
        description: 'Channel for location-based alerts',
        sound: 'default',
        importance: AndroidImportance.HIGH,
        vibration: true,
      });
      console.log('Notification channel created');
    } catch (error) {
      console.error('Error creating location channel:', error);
    }
  }, []);

  const calculateDistance = useCallback(
    (lat1: number, lon1: number, lat2: number, lon2: number) => {
      const R = 6371e3;
      const φ1 = (lat1 * Math.PI) / 180;
      const φ2 = (lat2 * Math.PI) / 180;
      const Δφ = ((lat2 - lat1) * Math.PI) / 180;
      const Δλ = ((lon2 - lon1) * Math.PI) / 180;

      const a =
        Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

      return R * c;
    },
    [],
  );

  const checkIfInsideCircle = useCallback(
    (
      location: LocationDetails,
      jobLocation: {latitude: any; longitude: any},
    ) => {
      if (!jobLocation) {
        return false;
      }

      const distance = calculateDistance(
        location.latitude,
        location.longitude,
        jobLocation.latitude,
        jobLocation.longitude,
      );

      const isInside = distance <= RADIUS;
      dispatch(setIsInsideCircle(isInside));
      return isInside;
    },
    [calculateDistance, dispatch],
  );

  // Enhanced location processing with smoothing
  const processLocationUpdate = useCallback(
    (position: any, jobLocation: {latitude: any; longitude: any}) => {
      const rawCoord: LocationDetails = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        altitude: position.coords.altitude,
        altitudeAccuracy: position.coords.altitudeAccuracy,
        heading: position.coords.heading,
        speed: position.coords.speed,
      };

      console.log('Raw location accuracy:', position.coords.accuracy);

      // Filter out inaccurate readings
      if (position.coords.accuracy > LOCATION_CONFIG.accuracyThreshold) {
        console.log(
          `Rejected location - Poor accuracy: ${position.coords.accuracy}m`,
        );
        return;
      }

      // Add to buffer for smoothing
      locationBuffer.current.push(rawCoord);
      if (locationBuffer.current.length > LOCATION_CONFIG.bufferSize) {
        locationBuffer.current.shift();
      }

      // Calculate smoothed location
      const smoothedCoord = smoothLocation(
        locationBuffer.current,
        lastValidLocation.current,
        LOCATION_CONFIG.smoothingFactor,
      );

      if (!smoothedCoord) return;

      console.log('Smoothed location:', smoothedCoord);

      // Update last valid location
      lastValidLocation.current = smoothedCoord;

      // Dispatch smoothed location
      dispatch(setCurrentLocation(smoothedCoord));
      dispatch(setLocationHistory(smoothedCoord));

      // Send to websocket if shift is active
      if (shiftId) {
        websocketService.sendLocation(smoothedCoord, shiftId);
      }

      // Check if inside circle with smoothed coordinates
      checkIfInsideCircle(smoothedCoord, jobLocation);
    },
    [dispatch, shiftId, checkIfInsideCircle, smoothLocation],
  );

  const startLocationTracking = useCallback(
    async (jobLocation: {latitude: any; longitude: any}): Promise<boolean> => {
      try {
        // const hasPermission = await requestLocationPermission();
        // console.log('Location permission:', hasPermission);
        // if (!hasPermission) {
        //   dispatch(setError('Location permission denied'));
        //   return false;
        // }

        // Clear previous location data
        locationBuffer.current = [];
        lastValidLocation.current = null;

        return new Promise(resolve => {
          Geolocation.getCurrentPosition(
            position => {
              console.log('Initial position obtained');
              processLocationUpdate(position, jobLocation);

              const isInside = checkIfInsideCircle(
                position.coords,
                jobLocation,
              );

              // Start watching position with enhanced settings
              watchIdRef.current = Geolocation.watchPosition(
                watchPosition => {
                  processLocationUpdate(watchPosition, jobLocation);
                },
                error => {
                  console.error('Watch position error:', error);
                  dispatch(setError(error.message));
                  resolve(false);
                },
                {
                  enableHighAccuracy: LOCATION_CONFIG.enableHighAccuracy,
                  timeout: LOCATION_CONFIG.timeout,
                  maximumAge: LOCATION_CONFIG.maximumAge,
                  distanceFilter: LOCATION_CONFIG.distanceFilter,
                  interval: LOCATION_CONFIG.interval,
                  fastestInterval: LOCATION_CONFIG.fastestInterval,
                },
              );

              dispatch(setIsTracking(true));
              resolve(isInside);
            },
            _error => {
              console.log(
                'Initial position failed, trying with lower accuracy',
              );
              Geolocation.getCurrentPosition(
                retryPosition => {
                  processLocationUpdate(retryPosition, jobLocation);
                  const isInside = checkIfInsideCircle(
                    retryPosition.coords,
                    jobLocation,
                  );
                  resolve(isInside);
                },
                retryError => {
                  console.error('Retry position error:', retryError);
                  dispatch(setError(retryError.message));
                  resolve(false);
                },
                {
                  enableHighAccuracy: false,
                  timeout: 1000,
                  maximumAge: 1000,
                },
              );
            },
            {
              enableHighAccuracy: true,
              timeout: 3000,
              maximumAge: 1000,
            },
          );
        });
      } catch (err) {
        console.error('Location tracking failed:', err);
        dispatch(setError('Location tracking failed'));
        return false;
      }
    },
    [dispatch, checkIfInsideCircle, processLocationUpdate],
  );

  const stopLocationTracking = useCallback(() => {
    if (watchIdRef.current !== null) {
      Geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }

    // Clear location buffers
    locationBuffer.current = [];
    lastValidLocation.current = null;

    dispatch(setIsTracking(false));
  }, [dispatch]);

  useEffect(() => {
    requestNotificationPermission();
    registerDeviceForPush();

    if (Platform.OS === 'android') {
      createLocationChannel();
    }

    return () => {
      stopLocationTracking();
    };
  }, [createLocationChannel, stopLocationTracking, registerDeviceForPush]);

  return {
    startLocationTracking,
    stopLocationTracking,
    checkIfInsideCircle,
    calculateDistance,
  };
};
