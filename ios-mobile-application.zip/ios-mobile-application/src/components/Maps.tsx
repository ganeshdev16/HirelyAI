import React, {useEffect, useState, useRef} from 'react';
import {StyleSheet, Dimensions} from 'react-native';
import MapView, {Polyline, LatLng, Provider, Region} from 'react-native-maps';
import {useSelector} from 'react-redux';
import {darkMapStyle} from '../screens/validation/validation';

const {width, height} = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.0008;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
export type GradientPolylinesFunctionalProps = {
  provider: Provider;
};

const Map = (props: GradientPolylinesFunctionalProps) => {
  const locationHistory = useSelector(
    (state: any) => state.location.locationHistory || [],
  );
  const currentLocation = useSelector(
    (state: any) => state.location.currentLocation,
  );

  const [region, setRegion] = useState<null | {
    latitude: number;
    longitude: number;
    latitudeDelta: number;
    longitudeDelta: number;
  }>(currentLocation);

  const [polylineSteps, setPolylineSteps] = useState<LatLng[]>([]);
  const mapRef = useRef<MapView>(null);

  // Update region when currentLo tion changes
  useEffect(() => {
    if (currentLocation?.latitude && currentLocation?.longitude) {
      setRegion({
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        latitudeDelta: LATITUDE_DELTA * 1.5,
        longitudeDelta: LONGITUDE_DELTA * 1.5,
      });
    }
  }, [currentLocation]);

  // Update polyline when locationHistory changes
  useEffect(() => {
    if (locationHistory && Array.isArray(locationHistory)) {
      setPolylineSteps(locationHistory);
    }
  }, [locationHistory]);

  // Handle map ready event and animate to current location
  const handleMapReady = () => {
    if (
      mapRef.current &&
      currentLocation?.latitude &&
      currentLocation?.longitude
    ) {
      const targetRegion = {
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      };

      // Animate to the current location with a smooth transition
      mapRef.current.animateToRegion(targetRegion, 1000); // 1000ms = 1 second animation
    }
  };

  return (
    <MapView
      ref={mapRef}
      customMapStyle={darkMapStyle}
      zoomEnabled={true}
      provider={props.provider}
      style={styles.container}
      initialRegion={region as Region}
      showsUserLocation={true}
      onMapReady={handleMapReady}>
      {polylineSteps.length > 0 && (
        <Polyline
          coordinates={polylineSteps}
          strokeColor="#4b9cdb"
          strokeWidth={4}
          geodesic={true}
        />
      )}
    </MapView>
  );
};

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
  },
});

export default Map;
