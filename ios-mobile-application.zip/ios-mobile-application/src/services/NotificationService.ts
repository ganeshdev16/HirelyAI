// services/NotificationService.ts
import messaging from '@react-native-firebase/messaging';
import notifee, { AndroidImportance, EventType } from '@notifee/react-native';
import { Platform } from 'react-native';
import { navigationRef } from './NavigationService';

export async function requestUserPermission() {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    console.log('Notification permission granted:', authStatus);
  }
}

export async function createNotificationChannel() {
  if (Platform.OS === 'android') {
    await notifee.createChannel({
      id: 'emergency',
      name: 'Emergency Alerts',
      sound: 'default',
      importance: AndroidImportance.HIGH,
      vibration: true,
    });
  }
}

export function listenForForegroundMessages() {
  messaging().onMessage(async remoteMessage => {
    console.log('Foreground FCM:', remoteMessage);
    await notifee.displayNotification({
      title: remoteMessage.notification?.title || 'New Alert',
      body: remoteMessage.notification?.body || 'You have a new notification',
      android: {
        channelId: 'emergency',
        importance: AndroidImportance.HIGH,
        sound: 'default',
        smallIcon: 'ic_launcher', // Make sure you have this icon in `res`
      },
    });
  });
}

export function listenForNotificationEvents() {
  notifee.onForegroundEvent(({ type, detail }) => {
    if (type === EventType.PRESS && navigationRef.isReady()) {
      const data = detail.notification?.data;

      if (data?.action === 'open_job_details') {
        const jobId = data.job_id;

        if (typeof jobId === 'string' || typeof jobId === 'number') {
          navigationRef.navigate('RequestScreen', { jobId });
        } else {
          console.error('Invalid jobId:', jobId);
        }
      }
    }
  });
}
