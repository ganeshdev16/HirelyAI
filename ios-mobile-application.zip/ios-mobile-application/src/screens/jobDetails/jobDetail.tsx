import React, {useState, useRef, useEffect} from 'react';
import type {GooglePlacesAutocompleteRef} from 'react-native-google-places-autocomplete';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import {getuserhomebaseID, jobDetails} from '../../services/api';
import {RootStackScreenProps} from '../../types/navigation';
import {FormData} from '../../types/jobDetails';
import AntDesign from 'react-native-vector-icons/AntDesign';
import 'react-native-get-random-values';
import {useAuth} from '../../context/AuthContext';
import {
  GooglePlacesAutocomplete,
  GooglePlaceData,
  GooglePlaceDetail,
} from 'react-native-google-places-autocomplete';
import {styles} from './JobDetailStyles';
// import {googlePlacesModalStyles} from './GooglePlacesStyles';
import RedlineLogo from '../../components/RedLineLogo';
import {ActivityIndicator} from 'react-native-paper';
import GlobalSettingsModal from '../../components/LocationModal';
import useLocationId from '../../hooks/useLocationId';

const JobDetails: React.FC<RootStackScreenProps<'jobDetail'>> = ({
  navigation,
}) => {
  const [formData, setFormData] = useState<FormData>({
    propertyName: '',
    propertyAddress: '',
    managerName: '',
    managerPhone: '',
    buildingNo: '',
    gateAccess: '',
    gateAccessrestroom: '',
    clientName: '',
    clientPhoneNumber: '',
  });
  const googlePlacesRef = useRef<GooglePlacesAutocompleteRef>(null);
  const [focusedField, setFocusedField] = useState<keyof FormData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>(
    {},
  );
  const [showAddressModal, setShowAddressModal] = useState(false);
  const {userId} = useAuth();
  const {locationId} = useLocationId(userId);
  const updateField = (
    field: keyof FormData,
    value: string | boolean,
  ): void => {
    setFormData(prev => ({...prev, [field]: value}));
    if (errors[field]) {
      setErrors(prev => ({...prev, [field]: ''}));
    }
  };

  const handleLocationSelect = (
    data: GooglePlaceData,
    details: GooglePlaceDetail | null,
  ): void => {
    try {
      if (!data || !details) {
        console.warn('Location data or details missing');
        return;
      }
      const address = data.description || '';
      const lat = details?.geometry?.location?.lat;
      const lng = details?.geometry?.location?.lng;
      if (typeof lat === 'number' && typeof lng === 'number') {
        setFormData(prev => ({
          ...prev,
          propertyAddress: address,
          latitude: lat,
          longitude: lng,
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          propertyAddress: address,
        }));
      }
      if (errors.propertyAddress) {
        setErrors(prev => ({...prev, propertyAddress: ''}));
      }
      setShowAddressModal(false);
    } catch (error) {
      console.error('Error handling location selection:', error);
      Alert.alert(
        'Error',
        'There was an error selecting the address. Please try again.',
      );
    }
  };
  const formatPhoneNumber = (value: string): string => {
    // Remove all non-digits
    const phoneNumber = value.replace(/\D/g, '');

    // Format with parentheses: (123) 456-7890
    if (phoneNumber.length <= 3) {
      return phoneNumber;
    } else if (phoneNumber.length <= 6) {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
    } else {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(
        3,
        6,
      )}-${phoneNumber.slice(6, 10)}`;
    }
  };

  const handlePhoneInputChange = (text: string, field: keyof FormData) => {
    const formattedNumber = formatPhoneNumber(text);
    updateField(field, formattedNumber);
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof FormData, string>> = {};
    const name = formData.clientName.trim();
    const propertyName = formData.propertyName.trim();

    if (!name) {
      newErrors.clientName = 'Client name is required';
    } else if (!/^[A-Za-z ]+$/.test(name)) {
      newErrors.clientName = 'Name should contain only letters.';
    }

    if (!propertyName) {
      newErrors.propertyName = 'Property name is required';
    } else if (/^\d+$/.test(propertyName)) {
      newErrors.propertyName = 'Property name cannot be numbers only';
    } else if (!/^[a-zA-Z0-9 ]+$/.test(propertyName)) {
      newErrors.propertyName =
        'Property name cannot contain special characters';
    }
    if (!formData.propertyAddress.trim()) {
      newErrors.propertyAddress = 'Property address is required';
    }

    if (!formData.managerPhone.trim()) {
      newErrors.managerPhone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.managerPhone.replace(/[^0-9]/g, ''))) {
      newErrors.managerPhone = 'Please enter a valid 10-digit phone number';
    }
    if (!formData.buildingNo.trim()) {
      newErrors.buildingNo = 'Building number is required';
    }

    if (!formData.clientPhoneNumber.trim()) {
      newErrors.clientPhoneNumber = 'Phone number is required';
    } else if (
      !/^(\+1[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}$/.test(
        formData.clientPhoneNumber.trim(),
      )
    ) {
      newErrors.clientPhoneNumber = 'Please enter a valid US phone number';
    }
    if (!formData.gateAccess.trim()) {
      newErrors.gateAccess = 'Gate access required';
    }
    if (!formData.gateAccessrestroom.trim()) {
      newErrors.gateAccessrestroom = 'Restroom access is required.';
    }

    if (!formData.managerName.trim()) {
      newErrors.managerName = 'Client name is required.';
    } else if (!/^[A-Za-z ]+$/.test(formData.managerName.trim())) {
      newErrors.managerName = 'Manager name should contain only letters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (): Promise<void> => {
    setIsLoading(true);
    try {
      if (validateForm()) {
        const jobData = {
          propertyName: formData.propertyName,
          propertyAddress: formData.propertyAddress,
          propertyManagerName: formData.managerName,
          propertyManagerPhone: formData.managerPhone,
          buildingNo: formData.buildingNo,
          gateAccess: formData.gateAccess,
          gateAccessrestroom: formData.gateAccessrestroom,
          latitude: Number(formData.latitude),
          longitude: Number(formData.longitude),
          managerId: userId,
          propertyclientName: formData.clientName,
          propertyclientPhonenumber: formData.clientPhoneNumber,
          homebaselocationId: locationId,
        };
        console.log('Submitting Job Data:', jobData);
        try {
          const response = await jobDetails(jobData);
          console.log('API Response:', response);
          if (response.jobId && response.message) {
            navigation.navigate('JobList');
          } else {
            throw new Error('Invalid response format');
          }
        } catch (error: any) {
          console.error('Full error details:', error);
        }
      }
    } catch (error) {
      console.error('Outer error:', error);
      Alert.alert('Something went wrong');
    } finally {
      setIsLoading(false);
    }
  };
  console.log('locatiod', locationId);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <View style={styles.backTitleContainer}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}>
            <AntDesign name="left" size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
        <View style={styles.logo}>
          <RedlineLogo height="29" width="101" />
        </View>
      </View>

      <KeyboardAvoidingView
        style={{flex: 1}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          <Text style={styles.headerText}>Job Details</Text>
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyName' && styles.inputFocused,
                  errors.propertyName && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., Bayside Apartments"
                  placeholderTextColor="#666666"
                  value={formData.propertyName}
                  onChangeText={text => updateField('propertyName', text)}
                  onFocus={() => setFocusedField('propertyName')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.propertyName && (
                <Text style={styles.errorText}>{errors.propertyName}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Address</Text>
              <TouchableOpacity
                onPress={() => setShowAddressModal(true)}
                style={[
                  styles.inputWrapper,
                  focusedField === 'propertyAddress' && styles.inputFocused,
                  errors.propertyAddress && styles.inputError,
                ]}>
                {!formData.propertyAddress ? (
                  <Text style={styles.addressPlaceholderText}>
                    Click here to search address
                  </Text>
                ) : (
                  <Text style={styles.addressValueText}>
                    {formData.propertyAddress}
                  </Text>
                )}
              </TouchableOpacity>
              {errors.propertyAddress && (
                <Text style={styles.errorText}>{errors.propertyAddress}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Manager's Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'managerName' && styles.inputFocused,
                  errors.managerName && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., Sarah Johnson"
                  placeholderTextColor="#666666"
                  value={formData.managerName}
                  onChangeText={text => updateField('managerName', text)}
                  onFocus={() => setFocusedField('managerName')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.managerName && (
                <Text style={styles.errorText}>{errors.managerName}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Property Manager Phone Number</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'managerPhone' && styles.inputFocused,
                  errors.managerPhone && styles.inputError,
                ]}>
                <Text style={styles.countryCode}>+1</Text>
                <View style={styles.separator} />
                <TextInput
                  style={styles.input}
                  placeholder="e.g., 8135551234"
                  placeholderTextColor="#666666"
                  keyboardType="phone-pad"
                  value={formData.managerPhone}
                  onChangeText={text =>
                    handlePhoneInputChange(text, 'managerPhone')
                  }
                  onFocus={() => setFocusedField('managerPhone')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.managerPhone && (
                <Text style={styles.errorText}>{errors.managerPhone}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Client Name</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'clientName' && styles.inputFocused,
                  errors.clientName && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="e.g Sunshine Realty Group"
                  placeholderTextColor="#666666"
                  value={formData.clientName}
                  onChangeText={text => updateField('clientName', text)}
                  onFocus={() => setFocusedField('clientName')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.clientName && (
                <Text style={styles.errorText}>{errors.clientName}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Client Phone Number</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'clientPhoneNumber' && styles.inputFocused,
                  errors.clientPhoneNumber && styles.inputError,
                ]}>
                <Text style={styles.countryCode}>+1</Text>
                <View style={styles.separator} />
                <TextInput
                  style={styles.input}
                  placeholder="e.g., 8135556789"
                  placeholderTextColor="#666666"
                  keyboardType="phone-pad"
                  value={formData.clientPhoneNumber}
                  onChangeText={text =>
                    handlePhoneInputChange(text, 'clientPhoneNumber')
                  }
                  onFocus={() => setFocusedField('clientPhoneNumber')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.clientPhoneNumber && (
                <Text style={styles.errorText}>{errors.clientPhoneNumber}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Building No. (limit of 10)</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'buildingNo' && styles.inputFocused,
                  errors.buildingNo && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., 1"
                  placeholderTextColor="#666666"
                  keyboardType="numeric"
                  maxLength={10}
                  value={formData.buildingNo}
                  onChangeText={text => updateField('buildingNo', text)}
                  onFocus={() => setFocusedField('buildingNo')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.buildingNo && (
                <Text style={styles.errorText}>{errors.buildingNo}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Gate Access</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'gateAccess' && styles.inputFocused,
                  errors.gateAccess && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., Code #4321 or Keycard Access"
                  placeholderTextColor="#666666"
                  value={formData.gateAccess}
                  onChangeText={text => updateField('gateAccess', text)}
                  onFocus={() => setFocusedField('gateAccess')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.gateAccess && (
                <Text style={styles.errorText}>{errors.gateAccess}</Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Restroom Access</Text>
              <View
                style={[
                  styles.inputWrapper,
                  focusedField === 'gateAccessrestroom' && styles.inputFocused,
                  errors.gateAccessrestroom && styles.inputError,
                ]}>
                <TextInput
                  style={styles.input}
                  placeholder="e.g, Code #7890 or Staff Only"
                  placeholderTextColor="#666666"
                  value={formData.gateAccessrestroom}
                  onChangeText={text => updateField('gateAccessrestroom', text)}
                  onFocus={() => setFocusedField('gateAccessrestroom')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
              {errors.gateAccessrestroom && (
                <Text style={styles.errorText}>
                  {errors.gateAccessrestroom}
                </Text>
              )}
            </View>

            <TouchableOpacity
              disabled={isLoading}
              style={[styles.submitButton]}
              onPress={handleSubmit}>
              {isLoading ? (
                <ActivityIndicator size="small" color="black" />
              ) : (
                <Text style={styles.submitButtonText}>Add Property</Text>
              )}
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={showAddressModal}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setShowAddressModal(false)}
        onShow={() => {
          setTimeout(() => {
            googlePlacesRef.current?.focus();
          }, 100);
        }}>
        <SafeAreaView style={styles.modalSafeArea}>
          <KeyboardAvoidingView
            style={{flex: 1}}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
            <View style={styles.modalHeaderContainer}>
              <TouchableOpacity
                onPress={() => setShowAddressModal(false)}
                style={styles.modalBackButton}>
                <AntDesign name="left" size={20} color="#FFFFFF" />
              </TouchableOpacity>
              <Text style={styles.modalTitleText}>Property Address</Text>
            </View>

            <View style={[styles.searchContainer, styles.noTopBorder]}>
              <GooglePlacesAutocomplete
                ref={googlePlacesRef}
                placeholder="click here to search address"
                onPress={handleLocationSelect}
                enablePoweredByContainer={false}
                fetchDetails={true}
                debounce={300}
                query={{
                  key: 'AIzaSyBPmUI0hbgP19R7hzF1yRmo4URTw7vjWpI',
                  language: 'en',
                  // components: 'country:us',
                }}
                styles={{
                  container: {
                    flex: 1,
                    width: '100%',
                    backgroundColor: '#000000',
                    borderWidth: 0,
                  },
                  textInputContainer: {
                    width: '100%',
                    backgroundColor: 'transparent',
                    borderTopWidth: 0,
                    borderBottomWidth: 0,
                    paddingHorizontal: 10,
                  },
                  textInput: {
                    height: 60,
                    color: '#FFFFFF',
                    fontSize: 16,
                    backgroundColor: '#090909',
                    borderRadius: 16,
                    paddingHorizontal: 16,
                    borderWidth: 2,
                    borderColor: '#242424',
                    fontFamily: 'Inter_18pt-Regular',
                    paddingLeft: 40,
                  },
                  listView: {
                    flex: 1,
                    width: '100%',
                    marginTop: 10,
                    backgroundColor: '#090909',
                    borderRadius: 16,
                    borderWidth: 2,
                    borderColor: '#242424',
                    overflow: 'hidden',
                  },
                  row: {
                    padding: 15,
                    borderBottomWidth: 1,
                    borderBottomColor: '#242424',
                    backgroundColor: '#090909',
                  },
                  separator: {
                    height: 1,
                    backgroundColor: '#242424',
                  },
                  description: {
                    color: '#FFFFFF',
                    fontFamily: 'Inter_18pt-Regular',
                  },
                  poweredContainer: {
                    backgroundColor: '#090909',
                    display: 'none',
                  },
                }}
                renderLeftButton={() => (
                  <View style={styles.searchIconContainer}>
                    <AntDesign name="search1" size={20} color="#666666" />
                  </View>
                )}
                renderRow={data => (
                  <View style={styles.addressRow}>
                    <Text style={styles.addressText}>{data.description}</Text>
                  </View>
                )}
                keyboardShouldPersistTaps="always"
              />
            </View>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
      {/* <GlobalSettingsModal />  */}
    </SafeAreaView>
  );
};

export default JobDetails;
