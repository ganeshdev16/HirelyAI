export interface UploadedImage {
  imageUrl: string;
  timeOfTaken: string; // Adjust this based on your API (could be number if timestamp)
}
