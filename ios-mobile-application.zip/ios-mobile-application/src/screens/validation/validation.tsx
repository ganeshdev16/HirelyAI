import React, {useState, useEffect, useCallback, useRef} from 'react';
// import {checkLocationPermission} from '../PermissionManager/PermissionManager';
import {styles} from './ValidationStyles';
import {RootState} from '../../store';
import {useDispatch, useSelector} from 'react-redux';

import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Modal,
  ScrollView,
  NativeModules,
  DeviceEventEmitter,
  AppState,
  Alert,
  // Alert,
} from 'react-native';
import {Polyline, PROVIDER_GOOGLE} from 'react-native-maps';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Geolocation from '@react-native-community/geolocation';
import {
  Camera,
  useCameraDevices,
  CameraDevice,
} from 'react-native-vision-camera';
import type {RootStackScreenProps} from '../../types/navigation';
import {
  LocationData,
  LocationServicesManagerInterface,
  CameraCaptureProps,
} from '../../types/validation';
import IncidentPhotoPopup from '../../components/IncidentPhotoPopup';
import RedlineLogo from '../../components/RedLineLogo';

import {setCurrentLocation} from '../../store/slices/locationSlice';
import Map from '../../components/Maps';
import ImageResizer from 'react-native-image-resizer';
import {
  getPresignedUrl,
  uploadToS3,
  submitValidationData,
  insertImageToShift,
  getShiftImage,
} from '../../services/api';
import FireWatchLogsModal from '../../components/FireWatchLogsModal';
import {useSmoothLocation} from '../../hooks/useSmoothLocation';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface Photo {
  uri: string;
  lastModified: number;
}

interface PhotoAlertPayload {
  sender_id: string;
  recepient_id: string;
  shift_id: string;
  status: string;
  message: string;
}

const {LocationServicesManager} = NativeModules as {
  LocationServicesManager: LocationServicesManagerInterface;
};

const sendPhotoAlert = async (alertPayload: PhotoAlertPayload) => {
  const url = '/'; // Replace with your actual endpoint
  const payload = alertPayload; // Use the passed payload directly

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const result = await response.json();
    console.log(result);
  } catch (error) {
    throw error;
  }
};

const CameraCapture: React.FC<CameraCaptureProps> = ({
  isVisible,
  onClose,
  onPhotoTaken,
}) => {
  const camera = useRef<Camera>(null);
  const devices = useCameraDevices();
  const device = devices.find((d: CameraDevice) => d.position === 'back');

  const takePhoto = async () => {
    try {
      if (camera.current) {
        const photo = await camera.current.takePhoto({
          flash: 'off',
        });
        onPhotoTaken(photo.path);
        onClose();
      }
    } catch (error) {
      console.error('Error taking photo:', error);
    }
  };

  if (device == null) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#FFFFFF" />
      </View>
    );
  }

  return (
    <Modal visible={isVisible} animationType="slide">
      <View style={styles.cameraContainer}>
        <Camera
          ref={camera}
          style={StyleSheet.absoluteFill}
          device={device}
          isActive={isVisible}
          photo={true}
        />
        <View style={styles.cameraControls}>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <AntDesign name="close" size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <TouchableOpacity onPress={takePhoto} style={styles.captureButton}>
            <View style={styles.captureButtonInner} />
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const SettingsModal: React.FC<{
  isVisible: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
}> = ({isVisible, onClose, onOpenSettings}) => {
  return (
    <Modal visible={isVisible} transparent={true} animationType="fade">
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Enable Location</Text>
          <Text style={styles.modalText}>
            Please enable location services to use this feature.
          </Text>
          <View style={styles.modalButtons}>
            <TouchableOpacity style={styles.modalButton} onPress={onClose}>
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, styles.modalButtonPrimary]}
              onPress={onOpenSettings}>
              <Text
                style={[styles.modalButtonText, styles.modalButtonTextPrimary]}>
                Open Settings
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

// const isValidUrl = (url: string): boolean => {
//   try {
//     // eslint-disable-next-line no-new
//     new URL(url);
//     return true;
//   } catch {
//     return false;
//   }
// };
// const uploadedPhotoUrls: string[] = [];
// const validUrls = uploadedPhotoUrls.filter((url: any) => isValidUrl(url));

// const loadUploadedImages = async (shiftId: string) => {
//   try {
//     const storedImages = await AsyncStorage.getItem(
//       `uploadedImages_${shiftId}`,
//     );
//     const parsedImages = storedImages ? JSON.parse(storedImages) : [];
//     console.log('Loaded uploaded images:', parsedImages);
//     return parsedImages.filter((url: any) => isValidUrl(url)); // Filter out invalid URLs
//   } catch (error) {
//     console.error('Error loading uploaded images:', error);
//     return [];
//   }
// };
// const saveUploadedImages = async (shiftId: string, imageUrls: string[]) => {
//   try {
//     await AsyncStorage.setItem(
//       `uploadedImages_${shiftId}`,
//       JSON.stringify(imageUrls),
//     );
//     console.log('Saved uploaded images:', imageUrls); // Debugging log
//   } catch (error) {
//     console.error('Error saving uploaded images:', error);
//   }
// };
interface UploadedImage {
  imageUrl: string;
  timeOfTaken: string; // Adjust this based on your API (could be number if timestamp)
}

export default function ValidationScreen({
  navigation,
  route,
}: RootStackScreenProps<'Validation'>) {
  const [, setError] = useState<string | null>(null);
  const selectIsInsideCircle = (state: any) => state.location.isInsideCircle;
  const isInside = useSelector(selectIsInsideCircle);
  useSmoothLocation(isInside);
  const locationHistory = useSelector(
    (state: any) => state.location.locationHistory,
  );
  const [loading, setLoading] = useState<boolean>(false);
  const steps = useSelector((state: RootState) => state.stepTracker.steps);
  const shiftId = useSelector((state: any) => state.currentShift.shiftId);
  const dispatch = useDispatch();
  const [isCameraVisible, setIsCameraVisible] = useState(false);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [uploadedPhotoUrls, setUploadedPhotoUrls] = useState<UploadedImage[]>(
    [],
  );
  const [isSettingsModalVisible, setIsSettingsModalVisible] = useState(false);
  const [isWaitingForLocationSettings, setIsWaitingForLocationSettings] =
    useState(false);
  const [showIncidentPopup, setShowIncidentPopup] = useState(false);
  const [photoTaken, setPhotoTaken] = useState<boolean>(false);
  const [lastPhotoTimestamp, setLastPhotoTimestamp] = useState<number | null>(
    null,
  );
  const [logModal, showLogModal] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  console.log(locationHistory);

  // Load photos from AsyncStorage when component mounts
  useEffect(() => {
    const loadStoredPhotos = async () => {
      try {
        const storedPhotos = await AsyncStorage.getItem(`photos_${shiftId}`);
        if (storedPhotos) {
          setPhotos(JSON.parse(storedPhotos));
        }
      } catch (error) {
        console.error('Failed to load photos from AsyncStorage:', error);
      }
    };
    loadStoredPhotos();
  }, [shiftId]);

  // Save photos to AsyncStorage
  const savePhotosToStorage = async (photosToSave: Photo[]) => {
    try {
      await AsyncStorage.setItem(
        `photos_${shiftId}`,
        JSON.stringify(photosToSave),
      );
    } catch (error) {
      console.error('Failed to save photos to AsyncStorage:', error);
    }
  };
  console.log('cccc', steps);

  useEffect(() => {
    const showModal = () => {
      showLogModal(true);
    };
    const intervalId = setInterval(showModal, 30 * 60 * 1000);
    return () => clearInterval(intervalId);
  }, []);

  const saveUploadedImages = async (shiftID: string, imageUrls: string[]) => {
    try {
      const images = imageUrls.map(imageUrl => ({
        imageUrl,
        timeOfTaken: new Date().toISOString(),
      }));
      return await insertImageToShift(shiftID, images);
    } catch (error) {
      throw error;
    }
  };

  const fetchImages = async (shiftID: string) => {
    const data = await getShiftImage(shiftID);
    return data.images;
  };

  const formatImages = (images: any[]) => {
    return images.map(image => ({
      imageUrl: image.imageUrl,
      timeOfTaken: image.timeOfTaken,
    }));
  };

  useEffect(() => {
    const fetchUploadedImages = async () => {
      try {
        const rawImages = await fetchImages(shiftId);
        const formattedImages = formatImages(rawImages);
        setUploadedPhotoUrls(formattedImages);
        console.log('cc', uploadedPhotoUrls);
      } catch (error) {
        throw error;
      }
    };
    if (shiftId) {
      fetchUploadedImages();
    }
  }, [shiftId]);

  const triggerPhotoAlert = useCallback(async () => {
    const alertPayload: PhotoAlertPayload = {
      sender_id: '12345',
      recepient_id: '67890',
      shift_id: 'shift-001',
      status: 'pending',
      message: 'John Doe missed submitting the required photo for shift-001.',
    };
    try {
      await sendPhotoAlert(alertPayload);
    } catch (error) {
      console.error('Failed to send photo alert:', error);
    }
  }, []);

  const checkPhotoInterval = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    timerRef.current = setInterval(() => {
      const currentTime = Date.now();
      const shouldShowPopup =
        !lastPhotoTimestamp || currentTime - lastPhotoTimestamp > 1.8e6;
      if (shouldShowPopup && !photoTaken) {
        setShowIncidentPopup(true);
        triggerPhotoAlert();
      }
    }, 1.8e6);
  }, [lastPhotoTimestamp, triggerPhotoAlert, photoTaken]);

  useEffect(() => {
    setPhotoTaken(false);
    checkPhotoInterval();
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [checkPhotoInterval]);

  const calculateDistance = (point1: LocationData, point2: LocationData) => {
    const R = 3958.8; // Earth's radius in miles
    const φ1 = (point1.latitude * Math.PI) / 180;
    const φ2 = (point2.latitude * Math.PI) / 180;
    const Δφ = ((point2.latitude - point1.latitude) * Math.PI) / 180;
    const Δλ = ((point2.longitude - point1.longitude) * Math.PI) / 180;
    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const calculateDistanceFromHistory = (
    locationhistory: any,
  ): number | null => {
    if (locationHistory.length <= 2) {
      return null;
    }
    const firstPoint = locationhistory[0];
    const lastPoint = locationhistory[locationhistory.length - 1];
    return calculateDistance(firstPoint, lastPoint);
  };

  const distances = calculateDistanceFromHistory(locationHistory);
  const displayDistance =
    distances !== null
      ? distances < 1
        ? `${(distances * 1609.34).toFixed(2)} meters`
        : `${distances.toFixed(2)} miles`
      : '0';

  const handleAddPhoto = async () => {
    if (photos.length >= 16) {
      return;
    }
    const hasPermission = await Camera.requestCameraPermission();
    if (hasPermission === 'granted') {
      setIsCameraVisible(true);
    } else {
      setError('Camera permission denied');
    }
  };

  const handlePhotoTaken = async (path: string) => {
    const currentTime = Date.now();
    const newPhoto: Photo = {
      uri: `file://${path}`,
      lastModified: currentTime,
    };
    const updatedPhotos = [...photos, newPhoto];
    setPhotos(updatedPhotos);
    await savePhotosToStorage(updatedPhotos); // Save to AsyncStorage
    setLastPhotoTimestamp(currentTime);
    setPhotoTaken(true);
    setShowIncidentPopup(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const handleSubmitValidation = async () => {
    const currentTime = Date.now();
    const thirtMinutes = 30 * 60 * 1000;
    // 30 * 60 * 1000;
    // Get the most recent photo timestamp from either new photos or uploaded photos
    const latestNewPhotoTime =
      photos.length > 0 ? Math.max(...photos.map(p => p.lastModified)) : null;
    const latestUploadedPhotoTime =
      uploadedPhotoUrls.length > 0
        ? Math.max(
            ...uploadedPhotoUrls.map(u => new Date(u.timeOfTaken).getTime()),
          )
        : null;
    console.log('last', latestNewPhotoTime);
    const lastPhotoTime = latestNewPhotoTime || latestUploadedPhotoTime || null;

    const hasPhotos = photos.length > 0 || uploadedPhotoUrls.length > 0;
    const isWithinTimeWindow =
      lastPhotoTime && currentTime - lastPhotoTime < thirtMinutes;
    console.log('istime', isWithinTimeWindow);

    if (!hasPhotos || !isWithinTimeWindow) {
      Alert.alert('Error', 'Please capture a photo to submit validation.');
      return;
    }

    setLoading(true);
    let newUploadedUrls: string[] = [];

    try {
      for (const photo of photos) {
        if (uploadedPhotoUrls.some(img => img.imageUrl === photo.uri)) {
          continue;
        }
        // Compress the photo
        const compressedImage = await ImageResizer.createResizedImage(
          photo.uri,
          1024,
          1024,
          'JPEG',
          80,
          0,
        );
        console.log(
          'Compressed Image:',
          compressedImage.uri,
          'Size:',
          compressedImage.size,
        );

        // Get pre-signed URL for S3
        const {uploadURL, Key, fullURL} = await getPresignedUrl(shiftId);
        console.log('S3 Presigned URL:', uploadURL, 'Key:', Key);

        // Convert compressed image to Blob
        const imageFile = await fetch(compressedImage.uri);
        const blob = await imageFile.blob();

        // Upload to S3
        await uploadToS3(uploadURL, blob);
        console.log('Image Uploaded Successfully:', Key);
        newUploadedUrls.push(fullURL);
      }

      console.log('Uploaded Photo URLs:', newUploadedUrls);

      // Submit validation data
      await submitValidationData(shiftId, newUploadedUrls);
      const newFormattedUrls = newUploadedUrls.map(url => ({
        imageUrl: url,
        timeOfTaken: new Date().toISOString(),
      }));
      const updatedUrls = [...uploadedPhotoUrls, ...newFormattedUrls];
      console.log('CCC', updatedUrls);

      setUploadedPhotoUrls(updatedUrls);
      await saveUploadedImages(shiftId, newUploadedUrls);

      // Clear photos from state and AsyncStorage
      setPhotos([]);
      await AsyncStorage.removeItem(`photos_${shiftId}`);

      Alert.alert('Success', 'Validation submitted successfully!');
      navigation.navigate('Dashboard');
    } catch (error: any) {
      console.error('Validation submission error:', error);
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenSettings = async () => {
    setIsSettingsModalVisible(false);
    try {
      // await LocationServicesManager.turnOnLocation();
    } catch (catchError) {
      console.error('Error opening settings:', catchError);
    }
  };

  const getLocation = useCallback(async () => {
    try {
      const {locationEnabled, hasPermission} =
        await LocationServicesManager.checkLocationStatus();
      if (!locationEnabled) {
        setIsSettingsModalVisible(true);
        setIsWaitingForLocationSettings(true);
        return;
      } else if (!hasPermission) {
        Alert.alert(
          'Permission Denied',
          'Please grant location permission to the app',
        );
        return;
      }
      Geolocation.getCurrentPosition(
        pos => {
          const newLocation = {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            timestamp: pos.timestamp,
          };
          dispatch(setCurrentLocation(newLocation));
        },
        err => {
          setError('Failed to get location: ' + err.message);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 10000,
        },
      );
    } catch (err) {
      console.error('Error checking location status:', err);
      setError('Failed to check location services');
    }
  }, [dispatch]);

  useEffect(() => {
    getLocation();
    const locationStateChangeListener = DeviceEventEmitter.addListener(
      'locationStateChanged',
      async (event: {locationEnabled: boolean}) => {
        console.log('Location state changed:', event);
        if (event.locationEnabled && isWaitingForLocationSettings) {
          setIsWaitingForLocationSettings(false);
          setIsSettingsModalVisible(false);
          await getLocation();
        }
      },
    );
    const appStateListener = AppState.addEventListener(
      'change',
      async nextAppState => {
        console.log('App state changed:', nextAppState);
        if (nextAppState === 'active' && isWaitingForLocationSettings) {
          setIsWaitingForLocationSettings(false);
          setIsSettingsModalVisible(false);
          await getLocation();
        }
      },
    );
    return () => {
      locationStateChangeListener.remove();
      appStateListener.remove();
    };
  }, [getLocation, isWaitingForLocationSettings]);

  const smoothLocationPath = (coordinates: any[]) => {
    if (!coordinates || coordinates.length <= 2) {
      return coordinates || [];
    }
    const validCoords = coordinates.filter(
      coord =>
        coord &&
        typeof coord.latitude === 'number' &&
        typeof coord.longitude === 'number' &&
        !isNaN(coord.latitude) &&
        !isNaN(coord.longitude) &&
        coord.latitude >= -90 &&
        coord.latitude <= 90 &&
        coord.longitude >= -180 &&
        coord.longitude <= 180,
    );
    if (validCoords.length <= 2) {
      return validCoords;
    }
    const smoothed = [];
    smoothed.push(validCoords[0]);
    for (let i = 1; i < validCoords.length - 1; i++) {
      const avg = {
        latitude:
          (validCoords[i - 1].latitude +
            validCoords[i].latitude +
            validCoords[i + 1].latitude) /
          3,
        longitude:
          (validCoords[i - 1].longitude +
            validCoords[i].longitude +
            validCoords[i + 1].longitude) /
          3,
      };
      smoothed.push(avg);
    }
    smoothed.push(validCoords[validCoords.length - 1]);
    return smoothed;
  };
  console.log('dis', distances);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.hedaerWrapper}>
        <View style={styles.header}>
          <View style={styles.backTitleContainer}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}>
              <AntDesign name="left" size={20} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
          <RedlineLogo height="29" width="101" />
        </View>
        <Text style={styles.headerTitle}>Validation Station</Text>
      </View>

      {showIncidentPopup && (
        <IncidentPhotoPopup
          visible={showIncidentPopup}
          onClose={() => {
            setShowIncidentPopup(false);
            setLastPhotoTimestamp(Date.now());
            setPhotoTaken(false);
            checkPhotoInterval();
          }}
          onCapturePhoto={handleAddPhoto}
        />
      )}

      <ScrollView style={styles.content}>
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => {
              navigation.navigate('FireWatchLogs', {shiftId: shiftId});
            }}>
            <View style={styles.iconContainer}>
              <Image
                source={require('../../assets/images/logs.png')}
                style={styles.menuIcon}
              />
              <Text style={styles.menuTitle}>Firewatch Log</Text>
            </View>
          </TouchableOpacity>
          <View style={{padding: 8, marginTop: 12}}>
            <Text style={styles.CapturesectionTitle}>Capture Photos</Text>
            <ScrollView
              horizontal
              contentContainerStyle={styles.photoContainer}
              showsHorizontalScrollIndicator={false}>
              {photos.length < 16 && (
                <TouchableOpacity
                  style={styles.addPhotoButton}
                  onPress={handleAddPhoto}>
                  <AntDesign name="plus" size={24} color="#FFFFFF" />
                </TouchableOpacity>
              )}
              {uploadedPhotoUrls.map((url, index) => (
                <Image
                  key={index}
                  source={{uri: url.imageUrl}}
                  style={styles.photo}
                  onError={error =>
                    console.error(
                      'Failed to load image:',
                      error.nativeEvent.error,
                    )
                  }
                />
              ))}
              {photos.map((photo, index) => (
                <Image
                  key={index}
                  source={{uri: photo.uri}}
                  style={styles.photo}
                />
              ))}
            </ScrollView>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.MapsectionTitle}>Map</Text>
          <View style={styles.mapContainer}>
            <Map provider={PROVIDER_GOOGLE} />
            {locationHistory && locationHistory.length > 1 && (
              <Polyline
                coordinates={smoothLocationPath(locationHistory)}
                strokeColor="#4b9cdb"
                strokeWidth={4}
                geodesic={true}
              />
            )}
          </View>
        </View>

        {/* <View style={styles.section}>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Total Distance Covered:</Text>
              <Text style={[styles.statValue, styles.DistanceValuePosition]}>
                {distances}
              </Text>
            </View>
            <Text style={[styles.statValue, styles.DistanceValuePosition]}>
              steps: {steps}
            </Text>
          </View>
        </View> */}

        <TouchableOpacity
          style={[styles.submitButton]}
          onPress={handleSubmitValidation}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="black" />
          ) : (
            <Text style={styles.submitButtonText}>Submit Validation</Text>
          )}
        </TouchableOpacity>
      </ScrollView>

      <SettingsModal
        isVisible={isSettingsModalVisible}
        onClose={() => setIsSettingsModalVisible(false)}
        onOpenSettings={handleOpenSettings}
      />

      <CameraCapture
        isVisible={isCameraVisible}
        onClose={() => setIsCameraVisible(false)}
        onPhotoTaken={handlePhotoTaken}
      />
      <FireWatchLogsModal
        handleNavigation={() => {
          navigation.navigate('FireWatchLogs', {shiftId: shiftId});
          showLogModal(false);
        }}
        visible={logModal}
        onClose={() => {
          showLogModal(false);
        }}
      />
    </SafeAreaView>
  );
}

export const darkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{color: '#242f3e'}],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{color: '#242f3e'}],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{color: '#746855'}],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{color: '#38414e'}],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{color: '#212a37'}],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{color: '#17263c'}],
  },
];
