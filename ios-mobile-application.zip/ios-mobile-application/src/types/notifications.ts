export interface NOTIFICATIONS {
  sender_id?: string;
  message: string;
  _id: string;
  type: string;
  priority: string;
  status: 'initiated' | 'archived';
  created_at: string;
  location?: string;
}
