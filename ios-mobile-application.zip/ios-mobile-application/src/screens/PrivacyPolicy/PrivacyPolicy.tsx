import React from 'react';
import {
  SafeAreaView,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import {RootStackScreenProps} from '../../types/navigation';
import AntDesign from 'react-native-vector-icons/AntDesign';
import RedlineLogo from '../../components/RedLineLogo';
import {ScrollView} from 'react-native-gesture-handler';
import privacyPolicyData from '../../constants/privacyPolicy.json'; // Import the updated JSON file

function Privacypolicy({
  navigation,
}: Readonly<RootStackScreenProps<'PrivacyPolicy'>>) {
  const policy = privacyPolicyData.privacy_policy;

  return (
    <SafeAreaView style={styles.container}>
      {/* Header with Back Button */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <RedlineLogo height="29" width="101" />
      </View>

      <Text style={styles.headertext}>Privacy Policy</Text>
      <Text style={styles.datetext}>Last Updated: {policy.last_updated}</Text>
      <ScrollView contentContainerStyle={styles.contentContainer}>
        {/* Introduction Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>Introduction</Text>
          <Text style={styles.text}>{policy.introduction.description}</Text>
          <Text style={styles.text}>{policy.introduction.modifications}</Text>
        </View>

        {/* Information We Collect Sections */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>
            {policy.information_we_collect.title}
          </Text>
          {policy.information_we_collect.items.map((item, index) => (
            <Text key={index} style={styles.text}>
              • {item}
            </Text>
          ))}
        </View>

        {/* How We Use Your Information Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>
            {policy.how_we_use_your_information.title}
          </Text>
          {policy.how_we_use_your_information.items.map((item, index) => (
            <Text key={index} style={styles.text}>
              • {item}
            </Text>
          ))}
        </View>

        {/* Sharing of Information Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>
            {policy.sharing_of_information.title}
          </Text>
          <Text style={styles.text}>
            {policy.sharing_of_information.description}
          </Text>
          {policy.sharing_of_information.items.map((item, index) => (
            <Text key={index} style={styles.text}>
              • {item}
            </Text>
          ))}
        </View>

        {/* Data Security Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>{policy.data_security.title}</Text>
          <Text style={styles.text}>{policy.data_security.description}</Text>
        </View>

        {/* Cookies and Tracking Technologies Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>
            {policy.cookies_and_tracking_technologies.title}
          </Text>
          <Text style={styles.text}>
            {policy.cookies_and_tracking_technologies.description}
          </Text>
        </View>

        {/* Your Rights and Choices Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>
            {policy.your_rights_and_choices.title}
          </Text>
          <Text style={styles.text}>
            {policy.your_rights_and_choices.description}
          </Text>
          {policy.your_rights_and_choices.items.map((item, index) => (
            <Text key={index} style={styles.text}>
              • {item}
            </Text>
          ))}
          <Text style={styles.text}>
            {policy.your_rights_and_choices.contact_note}
          </Text>
        </View>

        {/* Third-Party Links Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>{policy.third_party_links.title}</Text>
          <Text style={styles.text}>
            {policy.third_party_links.description}
          </Text>
        </View>

        {/* Children’s Privacy Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>{policy.childrens_privacy.title}</Text>
          <Text style={styles.text}>
            {policy.childrens_privacy.description}
          </Text>
        </View>

        {/* Contact Us Section */}
        <View style={styles.section}>
          <Text style={styles.subHeader}>{policy.contact_us.title}</Text>
          <Text style={styles.text}>{policy.contact_us.description}</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    margin: 8,
    display: 'flex',
    backgroundColor: '#000000',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 8,
  },
  headertext: {
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-Bold',
    fontSize: 20,
    color: 'white',
    paddingHorizontal: 16,
    paddingVertical: 5,
    backgroundColor: '#000000',
  },
  contentContainer: {
    marginTop: 32,
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginTop: 10,
  },
  subHeader: {
    fontFamily: 'Inter_18pt-Bold',
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 10,
    marginBottom: 10,
  },
  text: {
    fontFamily: 'Inter_18pt-Regular',
    fontWeight: 500,
    color: 'white',
    fontSize: 14,
    marginBottom: 5,
    letterSpacing: 0.5,
  },
  datetext: {
    fontWeight: 500,
    fontStyle: 'italic',
    fontFamily: 'Inter_18pt-Regular',

    fontSize: 12,
    paddingHorizontal: 16,
    paddingVertical: 5,
    color: '#6A6A6A',
  },
});

export default Privacypolicy;
