export interface HomeBaseLocationData {
  address_1: string;
  address_2: string | null;
  city: string;
  country_code: string;
  created_at: string;
  name: string;
  partner_merchant_id: string | null;
  phone: string;
  state: string;
  time_zone: string;
  updated_at: string;
  uuid: string;
  website: string;
  zip: string;
}
