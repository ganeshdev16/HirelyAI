// src/types/steps.ts

export interface SensorData {
  x: number;
  y: number;
  z: number;
  timestamp: number;
}

export interface StepTrackerState {
  steps: number;
  currentAcceleration: SensorData;
  currentMagnitude: number;
  averageLevel: number;
  calibrationFactor: number; // Add this property
}

export interface StepTrackerConfig {
  minMagnitude: number;
  maxMagnitude: number;
  minStepPeriod: number;
  windowSize: number;
  maxVariance: number;
  updateIntervalMs: number;
}
