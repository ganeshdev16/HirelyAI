export interface FormData {
  propertyName: string;
  propertyAddress: string;
  managerName: string;
  managerPhone: string;
  buildingNo: string;
  gateAccess: string;
  gateAccessrestroom: string;
  latitude?: number;
  longitude?: number;
  clientName: string;
  clientPhoneNumber: string;
  id?: string;
}
export interface editJobData {
  propertyName: string;
  propertyAddress: string;
  propertyManagerName: string;
  propertyManagerPhone: string;
  buildingNo: string;
  managerId: string;
  gateAccess: string;
  gateAccessrestroom: string;
  latitude?: number;
  longitude?: number;
  _id?: string;
  propertyclientPhonenumber: string;
  propertyclientName: string;
  user_id?: string;
}
