import {configureStore} from '@reduxjs/toolkit';
import userReducer from '../store/slices/userSlice';
import locationReducer from '../store/slices/locationSlice';
import {geofenceLoggingMiddleware} from '../middlewares/geofenceLoggingMiddleware';
import stepTrackerReducer from '../store/slices/stepTrackerSlice';
import currentShiftReducer from '../store/slices/currentShiftSlice';
import jobIdReducer from '../store/slices/jobSlice';
export const store = configureStore({
  reducer: {
    location: locationReducer,
    user: userReducer,
    stepTracker: stepTrackerReducer,
    currentShift: currentShiftReducer,
    job: jobIdReducer,
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(geofenceLoggingMiddleware),
});
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
