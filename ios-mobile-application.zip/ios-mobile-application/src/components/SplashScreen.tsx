import React from 'react';
import {
  View,
  ImageBackground,
  SafeAreaView,
  StatusBar,
  StyleSheet,
} from 'react-native';
import RedlineLogo from './RedLineLogo';
import Loader from './Loader';

const SplashScreen = () => {
  return (
    <>
      <StatusBar barStyle="light-content" />
      <ImageBackground
        source={require('../assets/images/welcome-2.png')}
        style={styles.backgroundImage}>
        <SafeAreaView style={styles.container}>
          <View style={styles.content}>
            <View style={styles.logoSection}>
              <RedlineLogo height="69" width="245" />
            </View>
            <Loader />
          </View>
        </SafeAreaView>
      </ImageBackground>
    </>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    backgroundColor: '#000000',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoSection: {
    marginBottom: 40,
  },
  spinner: {
    marginTop: 30, //
  },
});
