import {useEffect, useState, useCallback, useRef, useMemo} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import {RootState} from '../store';
import {
  accelerometer,
  gyroscope,
  setUpdateIntervalForType,
  SensorTypes,
} from 'react-native-sensors';
import {map, filter, throttleTime} from 'rxjs/operators';
import {Subscription} from 'rxjs';
import {updateSteps} from '../services/api';
import {
  incrementSteps,
  updateAcceleration,
  updateMagnitude,
  resetSteps as resetStepsAction,
  updateCalibrationFactor,
} from '../store/slices/stepTrackerSlice';
import {SensorData} from '../types/steps';
import {UnknownAction} from 'redux';
import {AppState, AppStateStatus} from 'react-native';

const OPTIMIZED_CONFIG = {
  baseThreshold: 0.8,
  userCalibrationFactor: 0.9,
  minStepPeriod: 400,
  maxStepPeriod: 1200,
  updateIntervalMs: 80,
  dbUpdateFrequency: 8,
  dbUpdateTimeoutMs: 10000,
  peakDetectionWindow: 6,
  valleyDetectionWindow: 3,
  lowPassFilterAlpha: 0.7,
  minConfidenceThreshold: 0.75,
  learningRate: 0.05,
  gravityValue: 9.81 as number,
  minWalkingHz: 0.8,
  maxWalkingHz: 2.5,
  fftAnalysisInterval: 24,
  motionThreshold: 0.4,
  stationaryTimeout: 3000,
} as const;

// Circular buffer for efficient memory management
class CircularBuffer {
  private buffer: number[];
  private head = 0;
  private size = 0;
  private capacity: number;

  constructor(capacity: number) {
    this.capacity = capacity;
    this.buffer = new Array(capacity);
  }

  push(value: number): void {
    this.buffer[this.head] = value;
    this.head = (this.head + 1) % this.capacity;
    if (this.size < this.capacity) this.size++;
  }

  get length(): number {
    return this.size;
  }

  get(index: number): number {
    if (index >= this.size) return 0;
    const actualIndex =
      (this.head - this.size + index + this.capacity) % this.capacity;
    return this.buffer[actualIndex];
  }

  getMiddle(): number {
    if (this.size === 0) return 0;
    return this.get(Math.floor(this.size / 2));
  }

  clear(): void {
    this.head = 0;
    this.size = 0;
  }

  toArray(): number[] {
    const result = new Array(this.size);
    for (let i = 0; i < this.size; i++) {
      result[i] = this.get(i);
    }
    return result;
  }
}

// Optimized peak detection using circular buffer
const detectPeak = (buffer: CircularBuffer, threshold: number): boolean => {
  if (buffer.length < 5) return false;

  const mid = Math.floor(buffer.length / 2);
  const midValue = buffer.get(mid);

  // Check if current point is a peak
  if (midValue <= threshold) return false;

  // Check peak conditions efficiently
  const left = buffer.get(mid - 1);
  const right = buffer.get(mid + 1);

  return (
    midValue > left &&
    midValue > right &&
    (mid <= 1 || buffer.get(mid - 2) < left) &&
    (mid >= buffer.length - 2 || buffer.get(mid + 2) < right)
  );
};

// Optimized valley detection
const detectValley = (buffer: CircularBuffer): boolean => {
  if (buffer.length < 3) return false;

  const mid = Math.floor(buffer.length / 2);
  const midValue = buffer.get(mid);
  const left = buffer.get(mid - 1);
  const right = buffer.get(mid + 1);

  return midValue < left && midValue < right;
};

// Simple frequency analysis for cadence detection
const estimateCadence = (stepPeriods: number[]): number | null => {
  if (stepPeriods.length < 3) return null;

  const avgPeriod =
    stepPeriods.reduce((sum, p) => sum + p, 0) / stepPeriods.length;
  const frequency = 1000 / avgPeriod; // Convert to Hz

  return frequency >= OPTIMIZED_CONFIG.minWalkingHz &&
    frequency <= OPTIMIZED_CONFIG.maxWalkingHz
    ? frequency
    : null;
};

export const useStepTracker = () => {
  const dispatch = useDispatch();
  const [isTracking, setIsTracking] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [calibrationMode, setCalibrationMode] = useState<boolean>(false);
  const [calibrationSteps, setCalibrationSteps] = useState<number>(0);

  const shiftId = useSelector((state: RootState) => state.currentShift.shiftId);
  const steps = useSelector((state: RootState) => state.stepTracker.steps);
  const userCalibrationFactor = useSelector(
    (state: RootState) =>
      state.stepTracker.calibrationFactor ||
      OPTIMIZED_CONFIG.userCalibrationFactor,
  );

  // Optimized refs using useMemo for initialization
  const refs = useMemo(
    () => ({
      lastStepTime: 0,
      lastDbUpdate: 0,
      lastDbUpdateTime: 0,
      filteredValue: OPTIMIZED_CONFIG.gravityValue,
      stepPatternState: 'peak' as 'peak' | 'valley',
      dynamicThreshold: OPTIMIZED_CONFIG.baseThreshold * userCalibrationFactor,
      stepConfidence: 0.8,
      walkingCadence: null as number | null,
      deviceOrientation: 'unknown' as 'vertical' | 'horizontal' | 'unknown',
      calibrationStartSteps: 0,
      lastMotionTime: Date.now(),
    }),
    [userCalibrationFactor],
  );

  // Circular buffers for efficient memory management
  const buffers = useMemo(
    () => ({
      magnitudes: new CircularBuffer(OPTIMIZED_CONFIG.peakDetectionWindow),
      deltas: new CircularBuffer(OPTIMIZED_CONFIG.peakDetectionWindow),
      stepPeriods: new CircularBuffer(8),
      accelerationBuffer: new CircularBuffer(32),
    }),
    [],
  );

  const subscriptionRef = useRef<Subscription | null>(null);
  const gyroSubscriptionRef = useRef<Subscription | null>(null);

  const calculateMagnitude = useCallback(
    (data: SensorData): number => {
      const rawMagnitude = Math.sqrt(
        data.x * data.x + data.y * data.y + data.z * data.z,
      );

      refs.filteredValue =
        OPTIMIZED_CONFIG.lowPassFilterAlpha * rawMagnitude +
        (1 - OPTIMIZED_CONFIG.lowPassFilterAlpha) * refs.filteredValue;

      return refs.filteredValue;
    },
    [refs],
  );

  // Optimized database update with batching
  const insertStepsToDatabase = useCallback(
    async (stepCount: number) => {
      if (!shiftId || stepCount <= refs.lastDbUpdate) return;

      try {
        const response = await updateSteps({
          shiftId,
          steps: stepCount,
        });

        if (response.data.message === 'Steps updated successfully') {
          refs.lastDbUpdate = stepCount;
          refs.lastDbUpdateTime = Date.now();
        }
      } catch (err) {
        console.error('Error updating steps:', err);
      }
    },
    [shiftId, refs],
  );

  // Optimized sensitivity adjustment
  const setSensitivity = useCallback(
    (multiplier: number): void => {
      const newCalibrationFactor = userCalibrationFactor * multiplier;
      refs.dynamicThreshold =
        OPTIMIZED_CONFIG.baseThreshold * newCalibrationFactor;
      dispatch(updateCalibrationFactor(newCalibrationFactor));
    },
    [dispatch, userCalibrationFactor, refs],
  );

  // Optimized confidence calculation
  const calculateConfidence = useCallback((stepPeriods: number[]): number => {
    if (stepPeriods.length < 3) return 0.5;

    const avgPeriod =
      stepPeriods.reduce((sum, p) => sum + p, 0) / stepPeriods.length;
    const variance =
      stepPeriods.reduce(
        (sum, p) => sum + Math.pow((p - avgPeriod) / avgPeriod, 2),
        0,
      ) / stepPeriods.length;

    return Math.max(0.3, Math.min(0.95, 0.9 - variance));
  }, []);

  // Optimized accelerometer data processing
  const processAccelerometerData = useCallback(
    (data: SensorData): boolean => {
      const magnitude = calculateMagnitude(data);
      const delta = Math.abs(magnitude - OPTIMIZED_CONFIG.gravityValue);
      const now = data.timestamp;

      // Update buffers
      buffers.magnitudes.push(magnitude);
      buffers.deltas.push(delta);
      buffers.accelerationBuffer.push(delta);

      // Dispatch updates less frequently
      if (steps % 4 === 0) {
        dispatch(updateAcceleration(data));
        dispatch(updateMagnitude(magnitude));
      }

      // Motion detection for power optimization
      if (delta > OPTIMIZED_CONFIG.motionThreshold) {
        refs.lastMotionTime = now;
      }

      // Skip processing if stationary for too long
      if (now - refs.lastMotionTime > OPTIMIZED_CONFIG.stationaryTimeout) {
        return false;
      }

      // Update cadence estimation periodically
      if (steps % OPTIMIZED_CONFIG.fftAnalysisInterval === 0) {
        const periods = buffers.stepPeriods.toArray();
        refs.walkingCadence = estimateCadence(periods);
      }

      let isStep = false;

      if (refs.stepPatternState === 'peak') {
        const isPeak = detectPeak(buffers.magnitudes, refs.dynamicThreshold);

        if (
          isPeak &&
          now - refs.lastStepTime > OPTIMIZED_CONFIG.minStepPeriod
        ) {
          const stepPeriod = now - refs.lastStepTime;

          // Validate step period
          if (stepPeriod < OPTIMIZED_CONFIG.maxStepPeriod) {
            buffers.stepPeriods.push(stepPeriod);

            // Calculate confidence
            const confidence = calculateConfidence(
              buffers.stepPeriods.toArray(),
            );
            refs.stepConfidence = 0.8 * refs.stepConfidence + 0.2 * confidence;

            if (refs.stepConfidence > OPTIMIZED_CONFIG.minConfidenceThreshold) {
              refs.stepPatternState = 'valley';
              refs.lastStepTime = now;
              isStep = true;

              if (calibrationMode) {
                setCalibrationSteps(prev => prev + 1);
              }
            }
          }
        }
      } else {
        if (detectValley(buffers.magnitudes)) {
          refs.stepPatternState = 'peak';
        }
      }

      return isStep;
    },
    [
      calculateMagnitude,
      calculateConfidence,
      buffers,
      refs,
      dispatch,
      steps,
      calibrationMode,
    ],
  );

  // Optimized tracking start
  const startTracking = useCallback((): void => {
    setError(null);
    setIsTracking(true);

    // Clear buffers
    buffers.magnitudes.clear();
    buffers.deltas.clear();
    buffers.stepPeriods.clear();
    buffers.accelerationBuffer.clear();

    // Reset state
    refs.stepPatternState = 'peak';
    refs.dynamicThreshold =
      OPTIMIZED_CONFIG.baseThreshold * userCalibrationFactor;
    refs.filteredValue = OPTIMIZED_CONFIG.gravityValue;
    refs.lastDbUpdateTime = Date.now();
    refs.stepConfidence = 0.8;
    refs.walkingCadence = null;
    refs.lastMotionTime = Date.now();
  }, [userCalibrationFactor, buffers, refs]);

  const stopTracking = useCallback((): void => {
    setIsTracking(false);
    refs.lastStepTime = 0;

    if (calibrationMode) {
      setCalibrationMode(false);
      setCalibrationSteps(0);
    }

    // Final database update
    if (steps > refs.lastDbUpdate) {
      insertStepsToDatabase(steps);
    }

    // Clean up subscriptions
    subscriptionRef.current?.unsubscribe();
    gyroSubscriptionRef.current?.unsubscribe();
    subscriptionRef.current = null;
    gyroSubscriptionRef.current = null;
  }, [calibrationMode, insertStepsToDatabase, steps, refs]);

  const resetSteps = useCallback((): UnknownAction => {
    refs.lastDbUpdate = 0;
    refs.lastDbUpdateTime = Date.now();
    return dispatch(resetStepsAction());
  }, [dispatch, refs]);

  const startCalibration = useCallback((): void => {
    if (!isTracking) startTracking();
    setCalibrationMode(true);
    setCalibrationSteps(0);
    refs.calibrationStartSteps = steps;
  }, [isTracking, startTracking, steps, refs]);

  const completeCalibration = useCallback(
    (knownStepCount: number): void => {
      if (calibrationSteps === 0) {
        setError('No steps detected during calibration');
        setCalibrationMode(false);
        return;
      }

      const newCalibrationFactor = knownStepCount / calibrationSteps;
      refs.dynamicThreshold =
        OPTIMIZED_CONFIG.baseThreshold * newCalibrationFactor;
      dispatch(updateCalibrationFactor(newCalibrationFactor));

      setCalibrationMode(false);
      setCalibrationSteps(0);
    },
    [calibrationSteps, dispatch, refs],
  );

  // Optimized app state handling
  useEffect(() => {
    if (!isTracking) return;

    const subscription = AppState.addEventListener(
      'change',
      (nextAppState: AppStateStatus) => {
        if (nextAppState !== 'active' && steps > refs.lastDbUpdate) {
          insertStepsToDatabase(steps);
        }
      },
    );

    return () => subscription.remove();
  }, [isTracking, steps, insertStepsToDatabase, refs]);

  // Optimized database update timer
  useEffect(() => {
    if (!isTracking) return;

    const dbUpdateTimer = setInterval(() => {
      const now = Date.now();
      if (
        steps > refs.lastDbUpdate &&
        now - refs.lastDbUpdateTime > OPTIMIZED_CONFIG.dbUpdateTimeoutMs
      ) {
        insertStepsToDatabase(steps);
      }
    }, OPTIMIZED_CONFIG.dbUpdateTimeoutMs / 3);

    return () => clearInterval(dbUpdateTimer);
  }, [isTracking, steps, insertStepsToDatabase, refs]);

  // Optimized gyroscope subscription
  useEffect(() => {
    if (!isTracking) return;

    try {
      setUpdateIntervalForType(SensorTypes.gyroscope, 2000);

      const subscription = gyroscope
        .pipe(
          map(({x, y, z}) => ({x, y, z})),
          filter(() => isTracking),
          throttleTime(1500),
        )
        .subscribe(
          gyroData => {
            refs.deviceOrientation =
              Math.abs(gyroData.z) > Math.abs(gyroData.x) &&
              Math.abs(gyroData.z) > Math.abs(gyroData.y)
                ? 'vertical'
                : 'horizontal';
          },
          error => {
            console.error('Gyroscope error:', error);
            refs.deviceOrientation = 'unknown';
          },
        );

      gyroSubscriptionRef.current = subscription;
      return () => subscription.unsubscribe();
    } catch (err) {
      console.error('Error initializing gyroscope:', err);
      refs.deviceOrientation = 'unknown';
    }
  }, [isTracking, refs]);

  // Optimized accelerometer subscription
  useEffect(() => {
    if (!isTracking) return;

    try {
      setUpdateIntervalForType(
        SensorTypes.accelerometer,
        OPTIMIZED_CONFIG.updateIntervalMs,
      );

      const subscription = accelerometer
        .pipe(
          map(
            ({x, y, z, timestamp}): SensorData => ({
              x,
              y,
              z,
              timestamp: timestamp || Date.now(),
            }),
          ),
          filter(() => isTracking),
          throttleTime(OPTIMIZED_CONFIG.updateIntervalMs / 2),
        )
        .subscribe(
          (data: SensorData) => {
            if (processAccelerometerData(data)) {
              dispatch(incrementSteps());

              // Less frequent database updates
              if (
                steps % OPTIMIZED_CONFIG.dbUpdateFrequency === 0 &&
                steps > refs.lastDbUpdate
              ) {
                insertStepsToDatabase(steps);
              }
            }
          },
          (error: Error) => {
            console.error('Accelerometer error:', error);
            setError('Error accessing accelerometer sensor');
            stopTracking();
          },
        );

      subscriptionRef.current = subscription;
      return () => subscription.unsubscribe();
    } catch (err) {
      console.error('Error initializing accelerometer:', err);
      setError('Failed to initialize step tracking');
      stopTracking();
    }
  }, [
    isTracking,
    processAccelerometerData,
    dispatch,
    stopTracking,
    insertStepsToDatabase,
    steps,
    refs,
  ]);

  return {
    isTracking,
    error,
    startTracking,
    stopTracking,
    resetSteps,
    steps,
    calibrationMode,
    calibrationSteps,
    startCalibration,
    completeCalibration,
    confidence: refs.stepConfidence,
    walkingCadence: refs.walkingCadence,
    setSensitivity,
  };
};
