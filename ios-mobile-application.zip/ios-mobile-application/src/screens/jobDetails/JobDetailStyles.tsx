import {StyleSheet, Platform} from 'react-native';
import {StatusBar} from 'react-native';

export const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#000000',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },

  iconWrapper: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: '#212121',
    borderWidth: 2,
    borderColor: '#2E2E2E',
    justifyContent: 'center',
    alignItems: 'center',
  },
  switchWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  headerText: {
    color: '#FFFFFF',
    fontFamily: 'Inter_18pt-SemiBold',
    fontSize: 20,
    lineHeight: 24,
    textAlign: 'left',
    fontWeight: '600',
    marginLeft: 20,
  },
  backTitleContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  childWithGap: {
    marginRight: 16,
  },
  countryCode: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
    marginRight: 5,
    minWidth: 25,
    textAlign: 'center',
  },
  separator: {
    height: 20,
    width: 2,
    backgroundColor: '#242424',
  },
  customToggle: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: '#151515',
    borderWidth: 2,
    borderColor: '#333333',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButton: {
    width: 38,
    height: 38,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 10,
  },
  form: {
    padding: 16,
    display: 'flex',
    marginBottom: 24,
    flexDirection: 'column',
    alignItems: 'center',
  },
  inputContainer: {
    borderStyle: 'solid',
    borderWidth: 2,
    marginTop: 16,
    width: '100%',
    gap: 10,
  },
  label: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
    marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    width: '100%',
    height: 60,
    backgroundColor: '#090909',
    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 16,
    display: 'flex',
    alignItems: 'center',
    paddingHorizontal: 16,
    gap: 10,
    flex: 0,
    alignSelf: 'stretch',
    flexGrow: 0,
  },
  logo: {
    width: 112,
    height: 35,
  },
  inputFocused: {
    borderColor: '#B40B0B',
    borderWidth: 1.5,
  },
  inputError: {
    borderColor: '#B40B0B',
    borderWidth: 1.5,
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
    padding: 0,
  },
  placeholderText: {
    color: '#666666',
  },
  errorText: {
    color: '#B40B0B',
    fontSize: 12,
    marginTop: 4,
    fontFamily: 'Inter_18pt-Regular',
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    // width: 358,
    width: 330,
    top: 10,
    height: 60,
    backgroundColor: '#090909',
    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 16,
    display: 'flex',
    paddingHorizontal: 16,
    marginBottom: 16,
    marginTop: 16,
    gap: 10,
  },
  submitButton: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    paddingVertical: 16,
    paddingHorizontal: 10,
    top: 25,
  },
  submitButtonText: {
    color: '#000000',
    fontSize: 16,
    fontFamily: 'Inter_18pt-SemiBold',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    top: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#000000',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingBottom: 16,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#242424',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
  },
  modalCloseButton: {
    padding: 4,
  },
  rowContainer: {
    padding: 15,
  },
  mainText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
  },
  scrollContent: {
    flexGrow: 1,
  },
  submitButtonContainer: {
    marginHorizontal: 16,
    marginBottom: 24,
  },
  secondaryText: {
    color: '#666666',
    fontSize: 14,
    fontFamily: 'Inter_18pt-Regular',
    marginTop: 4,
  },

  searchContainer: {
    flex: 1,
    padding: 16,
    backgroundColor: '#000000',
  },
  searchIconContainer: {
    position: 'absolute',
    left: 25,
    top: 20,
    zIndex: 1,
    justifyContent: 'center',
  },
  addressRow: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#242424',
  },
  addressText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontFamily: 'Inter_18pt-Regular',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    paddingVertical: 15,
    paddingHorizontal: 16,
    // borderBottomWidth: 2,
  },
  mapTitle: {
    // color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'right',
    right: 100,
  },

  modalBackButton: {
    width: 38,
    height: 38,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#242424',
    borderRadius: 10,
    marginRight: 10,
    left: 10,
  },

  // Add these to your JobDetailStyles.tsx file

  modalSafeArea: {
    flex: 1,
    backgroundColor: '#000000',
    borderWidth: 0,
    borderColor: 'transparent',
  },

  modalHeaderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    backgroundColor: '#000000',
    height: 70,
    borderWidth: 0,
    borderBottomWidth: 0,
    borderColor: 'transparent',
  },

  modalTitleText: {
    color: '#FFFFFF',
    fontSize: 20,
    marginLeft: 15,
    fontFamily: 'Inter_18pt-SemiBold',
    borderWidth: 0,
  },

  noTopBorder: {
    borderTopWidth: 0,
  },

  addressPlaceholderText: {
    color: '#666666',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },

  addressValueText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },

  flexFiller: {
    flex: 1,
  },
  disablebtn: {backgroundColor: '#B3B3B3'},
  disablebtntxt: {color: '#606060'},
});
