import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  SafeAreaView,
  StatusBar,
  Alert,
} from 'react-native';

import {RootStackScreenProps} from '../../types/navigation';
import RedlineLogo from '../../components/RedLineLogo';
import GlobalSettingsModal from '../../components/LocationModal';
import {checkShiftStatus} from '../../services/api';
import {useAuth} from '../../context/AuthContext';
import {useDispatch} from 'react-redux';
import {setCurrentShiftId} from '../../store/slices/currentShiftSlice';
import {setSteps} from '../../store/slices/stepTrackerSlice';
import {setLocationHistoryData} from '../../store/slices/locationSlice';
import Loader from '../../components/Loader';
import {useStepTracker} from '../../hooks/useStepTracker';
import {useGeofenceTracker} from '../../hooks/useGeofenceTracker';
import {useLocationTracker} from '../../hooks/useLocationTracker';
import {setJobId} from '../../store/slices/jobSlice';
// import InfoModal from '../../components/InfoModal';

export default function ManagerDashboard({
  navigation,
}: Readonly<RootStackScreenProps<'ManagerDashboard'>>) {
  const {userId} = useAuth();
  const [isinfoModalVisible, setIsinfoModalVisible] = useState(true);

  const handleContinue = () => {
    setIsinfoModalVisible(false);
  };
  const handleRequest = () => {
    // Navigate to the incident page
    navigation.navigate('RequestScreen');
  };

  const handleLocation = async () => {
    try {
      const shiftResponse = await checkShiftStatus(userId);
      console.log(shiftResponse);

      if (!shiftResponse.isActive) {
        navigation.navigate('JobList');
      }
    } catch (error) {
      Alert.alert('Unable to verify shift status. Please try again.');
    }
  };
  const handleNotification = () => {
    navigation.navigate('Notification');
  };
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(true);

  const {startTracking} = useStepTracker();

  const {startWatchingLocation} = useGeofenceTracker('', {
    latitude: 0,
    longitude: 0,
  });
  const {startLocationTracking} = useLocationTracker();

  useEffect(() => {
    const initializeData = async () => {
      setIsLoading(true);
      try {
        console.log(userId);

        // First check if there's an active shift
        const shiftResponse = await checkShiftStatus(userId);
        console.log(shiftResponse);

        if (shiftResponse.isActive && shiftResponse.shiftData) {
          // If shift is active, update Redux and navigate to Dashboard
          dispatch(setCurrentShiftId(shiftResponse.shiftData.shiftId));
          setCurrentShiftId(shiftResponse.shiftData.shiftId);
          dispatch(setSteps(shiftResponse.shiftData.steps));
          dispatch(setLocationHistoryData(shiftResponse.shiftData.coordinates));
          // Start tracking services
          startTracking();
          startLocationTracking({
            latitude: shiftResponse.shiftData.latitude,
            longitude: shiftResponse.shiftData.longitude,
          });
          // startWatchingLocation();
          dispatch(setJobId(shiftResponse.shiftData.jobId));

          // Navigate to Dashboard
          navigation.navigate('Dashboard');
        }
      } catch (error) {
        console.error('Error in initialization:', error);
      } finally {
        setIsLoading(false);
      }
    };

    initializeData();
  }, [
    dispatch,
    navigation,
    userId,
    startLocationTracking,
    startTracking,
    startWatchingLocation,
  ]);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.loaderContainer}>
        <Loader text="Loading jobs..." />
      </SafeAreaView>
    );
  }

  return (
    <>
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />

        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.logo}>
            <RedlineLogo height="29" width="101" />
          </View>
        </View>
        <View style={styles.dashboard}>
          <Text style={styles.Title}>Dashboard</Text>
          <TouchableOpacity onPress={handleNotification}>
            <Image
              source={require('../../assets/images/Bell-icon.png')}
              style={styles.Bellicon}
            />
          </TouchableOpacity>
        </View>

        {/* Main Content Section */}
        <View style={styles.mainContent}>
          {/* Requests Card */}
          <TouchableOpacity style={styles.card} onPress={handleRequest}>
            <Image
              source={require('../../assets/images/Request1.png')}
              style={styles.requestIcon}
            />
            <Text style={styles.cardText}>Requests</Text>
          </TouchableOpacity>

          {/* Location Card */}
          <TouchableOpacity style={styles.card} onPress={handleLocation}>
            <Image
              source={require('../../assets/images/location.png')}
              style={styles.locationIcon}
            />
            <Text style={styles.cardText}>Locations</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
      {/* <GlobalSettingsModal /> */}
      {/* <InfoModal isVisible={isinfoModalVisible} onContinue={handleContinue} /> */}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
  },

  dashboard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 10,
    height: 22,
  },
  Title: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '600',
    lineHeight: 24,
    marginLeft: 10,
  },
  Bellicon: {
    width: 18,
    height: 22,
    marginRight: 13,
    right: 10,
  },
  mainContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    height: '100%',
    width: '100%',
    marginTop: 32,
    padding: 16,
  },
  card: {
    width: '100%',
    height: 100,
    backgroundColor: '#151515',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  logo: {top: 8, bottom: 8},
  cardText: {
    color: '#FFFFFF',
    fontSize: 19,
    fontWeight: '400',
    lineHeight: 24,
    fontFamily: 'Inter_18pt-Regular',
    marginLeft: 10,
  },
  requestIcon: {
    width: 34,
    height: 35,
    tintColor: '#FFFFFF',
    marginRight: 14,
  },
  locationIcon: {
    width: 25,
    height: 35,
    tintColor: '#FFFFFF',
    marginRight: 18,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
