import {useEffect, useCallback} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {setLocationStatus} from '../store/slices/locationSlice';
import {LocationServicesManagerInterface} from '../types/validation';
import {NativeModules, AppState, AppStateStatus} from 'react-native';

const {LocationServicesManager} = NativeModules as {
  LocationServicesManager: LocationServicesManagerInterface;
};

export const useCheckLocation = () => {
  const dispatch = useDispatch();
  const {isLocationEnabled} = useSelector((state: any) => state.location);

  const checkLocationStatus = useCallback(async () => {
    try {
      const {locationEnabled} =
        await LocationServicesManager.checkLocationStatus();
      if (locationEnabled !== isLocationEnabled) {
        dispatch(setLocationStatus(locationEnabled)); // Only dispatch if status changed
      }
    } catch (err) {
      dispatch(setLocationStatus(false));
    }
  }, [dispatch, isLocationEnabled]);

  // Initial check on mount
  useEffect(() => {
    checkLocationStatus();
  }, [checkLocationStatus]);

  // Periodic polling when app is active
  useEffect(() => {
    let pollInterval: NodeJS.Timeout;

    const handleAppStateChange = (nextAppState: AppStateStatus) => {
      if (nextAppState === 'active') {
        checkLocationStatus(); // Immediate check on focus
        pollInterval = setInterval(() => {
          checkLocationStatus(); // Poll every 2 seconds
        }, 2000);
      } else if (nextAppState === 'background' || nextAppState === 'inactive') {
        clearInterval(pollInterval); // Stop polling when app is not active
      }
    };

    // Subscribe to app state changes
    const subscription = AppState.addEventListener(
      'change',
      handleAppStateChange,
    );

    // Start polling immediately if app is already active
    if (AppState.currentState === 'active') {
      checkLocationStatus();
      pollInterval = setInterval(() => {
        checkLocationStatus();
      }, 2000);
    }

    // Cleanup
    return () => {
      subscription.remove();
      clearInterval(pollInterval);
    };
  }, [checkLocationStatus]);

  const openSettings = async () => {
    try {
      await LocationServicesManager.turnOnLocation();
      // Rely on polling or AppState to detect the change
    } catch (error) {
      throw error;
    }
  };

  return {
    isLocationEnabled,
    openSettings,
    checkLocationStatus,
  };
};
