package com.redlinefirewatch;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.UiThreadUtil;
import com.facebook.react.modules.core.DeviceEventManagerModule;

public class LocationServicesManager extends ReactContextBaseJavaModule {
    private static final String MODULE_NAME = "LocationServicesManager";
    private static final int LOCATION_PERMISSION_CODE = 1001;
    private final ReactApplicationContext reactContext;
    private Promise pendingPromise;
    private boolean isCheckingSettings = false;

    public LocationServicesManager(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @Override
    public String getName() {
        return MODULE_NAME;
    }

    private void sendEvent(String eventName, WritableMap params) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
            .emit(eventName, params);
    }

    @ReactMethod
    public void checkLocationStatus(final Promise promise) {
        try {
            WritableMap status = Arguments.createMap();
            status.putBoolean("locationEnabled", isLocationEnabled());
            status.putBoolean("hasPermission", hasLocationPermission());
            promise.resolve(status);
        } catch (Exception e) {
            promise.reject("ERROR", "Failed to check location status: " + e.getMessage());
        }
    }

    @ReactMethod
    public void requestLocationPermission(final Promise promise) {
        Activity currentActivity = getCurrentActivity();
        if (currentActivity == null) {
            promise.reject("ERROR", "Activity not found");
            return;
        }

        if (hasLocationPermission()) {
            promise.resolve(true);
            return;
        }

        pendingPromise = promise;
        
        try {
            ActivityCompat.requestPermissions(
                currentActivity,
                new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                },
                LOCATION_PERMISSION_CODE
            );
        } catch (Exception e) {
            pendingPromise = null;
            promise.reject("ERROR", "Failed to request permission: " + e.getMessage());
        }
    }

    @ReactMethod
    public void turnOnLocation(final Promise promise) {
        UiThreadUtil.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (isLocationEnabled()) {
                        WritableMap result = Arguments.createMap();
                        result.putBoolean("locationEnabled", true);
                        result.putString("status", "ALREADY_ENABLED");
                        promise.resolve(result);
                        return;
                    }

                    Activity currentActivity = getCurrentActivity();
                    if (currentActivity == null) {
                        promise.reject("ERROR", "Activity not found");
                        return;
                    }

                    isCheckingSettings = true;
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                    currentActivity.startActivity(intent);

                    WritableMap result = Arguments.createMap();
                    result.putBoolean("locationEnabled", false);
                    result.putString("status", "SETTINGS_OPENED");
                    promise.resolve(result);
                    
                    // Start location state monitoring
                    startMonitoringLocationState();
                    
                } catch (Exception e) {
                    promise.reject("ERROR", "Failed to open location settings: " + e.getMessage());
                }
            }
        });
    }

    private void startMonitoringLocationState() {
        // Check location state every second for 30 seconds
        new Thread(new Runnable() {
            @Override
            public void run() {
                int attempts = 0;
                while (attempts < 30 && isCheckingSettings) {
                    try {
                        Thread.sleep(1000);
                        boolean enabled = isLocationEnabled();
                        
                        WritableMap status = Arguments.createMap();
                        status.putBoolean("locationEnabled", enabled);
                        sendEvent("locationStateChanged", status);
                        
                        if (enabled) {
                            isCheckingSettings = false;
                            break;
                        }
                    } catch (InterruptedException e) {
                        break;
                    }
                    attempts++;
                }
                isCheckingSettings = false;
            }
        }).start();
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) reactContext.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            return false;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return locationManager.isLocationEnabled();
        } else {
            try {
                return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                       locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            } catch (Exception e) {
                return false;
            }
        }
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(
            reactContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED;
    }

    // Handle permission result
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_CODE && pendingPromise != null) {
            boolean isGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            pendingPromise.resolve(isGranted);
            pendingPromise = null;
        }
    }
}
