import React, {useEffect, useState} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Keyboard,
} from 'react-native';
import type {RootStackScreenProps} from '../../types/navigation';
import {forgotPasswordOtp, forgotPasswordUpdate} from '../../services/api';
import ProfileIcon from '../../components/ProfileIcon';
import RedlineLogo from '../../components/RedLineLogo';

export default function OtpPasswordSetup({
  navigation,
  route,
}: Readonly<RootStackScreenProps<'OtpPasswordSetup'>>) {
  const {email} = route.params;

  const [focusedField, setFocusedField] = useState<
    'otp' | 'password' | 'confirmPassword' | null
  >(null);
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otpError, setOtpError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  const [loading, setLoading] = useState(false);
  const handleBlur = () => setFocusedField(null);
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [resendLoading, setResendLoading] = useState(false); // Tracks resend in progress
  const [resendSuccess, setResendSuccess] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [disableResend, setDisableResend] = useState(false);
  const [timer, setTimer] = useState(0);
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setKeyboardVisible(true),
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setKeyboardVisible(false),
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const handleFocus = (field: 'otp' | 'password' | 'confirmPassword') => {
    setFocusedField(field);
  };

  const validateOtp = (value: string): boolean => {
    if (value.length !== 6) {
      setOtpError('OTP must be 6 digits');
      return false;
    }
    setOtpError('');
    return true;
  };

  const validatePassword = (value: string): boolean => {
    const specialCharRegex = /[!@#$%^&*(),.?":{}|<>]/;
    if (value.length < 8) {
      setPasswordError('Password must be at least 8 characters long');
      return false;
    }
    if (!specialCharRegex.test(value)) {
      setPasswordError('Password must contain at least one special character');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const validateConfirmPassword = (value: string): boolean => {
    if (value !== password) {
      setConfirmPasswordError('Passwords do not match');
      return false;
    }
    setConfirmPasswordError('');
    return true;
  };

  const handleOtpChange = (value: string) => {
    setOtp(value);
    setOtpError('');
    if (value.length === 6) {
      validateOtp(value);
    }
  };

  const handlePasswordChange = (value: string) => {
    setPassword(value);
    setPasswordError('');
    validatePassword(value);
    if (confirmPassword) {
      validateConfirmPassword(confirmPassword);
    }
  };

  const handleConfirmPasswordChange = (value: string) => {
    setConfirmPassword(value);
    setConfirmPasswordError('');
    validateConfirmPassword(value);
  };

  const handleSubmit = async () => {
    if (!email) {
      Alert.alert('Error', 'Email is required');
      return;
    }

    const isOtpValid = validateOtp(otp);
    const isPasswordValid = validatePassword(password);
    const isConfirmPasswordValid = validateConfirmPassword(confirmPassword);

    if (isOtpValid && isPasswordValid && isConfirmPasswordValid) {
      setLoading(true);
      try {
        const response = await forgotPasswordUpdate(email, otp, password);

        // Check if the response is successful
        if (response && response.status) {
          // Success case
          navigation.navigate('SignIn');
        } else if (response && response.message) {
          // Handle specific error messages from backend
          if (response.message.toLowerCase().includes('invalid otp')) {
            setOtpError('Invalid OTP. Please try again.');
          } else if (response.message.toLowerCase().includes('expired')) {
            setOtpError('OTP has expired. Please request a new one.');
          } else {
            Alert.alert('Error', response.message);
          }
        } else {
          Alert.alert('Error', 'Failed to update password. Please try again.');
        }
      } catch (error: any) {
        console.error('Error during password update:', error);

        if (error.response) {
          switch (error.response.status) {
            case 400:
              setOtpError('Invalid OTP. Please try again.');
              break;
            case 401:
              setOtpError('OTP has expired. Please request a new one.');
              break;
            case 404:
              setOtpError('Invalid OTP. Please try again.');
              break;
            case 500:
              setOtpError('Failed to update password. Please try again.');
              break;
            default:
              setOtpError('Failed to update password. Please try again.');
          }
        } else if (error.message?.includes('Network')) {
          Alert.alert('Error', 'Network error. Please check your connection.');
        } else {
          Alert.alert('Error', 'Failed to update password. Please try again.');
        }
      } finally {
        setLoading(false);
      }
    }
  };
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (disableResend && timer > 0) {
      interval = setInterval(() => {
        setTimer(prev => prev - 1);
      }, 1000);
    }

    if (timer === 0) {
      setDisableResend(false);
      clearInterval(interval!);
    }

    return () => clearInterval(interval!);
  }, [timer, disableResend]);
  const handleResendOtp = async () => {
    if (!email) {
      Alert.alert('Error', 'Email is required to resend OTP');
      return;
    }

    setResendLoading(true);
    setResendSuccess(false);
    setDisableResend(true);
    setTimer(20); // Set timer for 10 seconds

    try {
      const response = await forgotPasswordOtp(email);
      if (response && response.status) {
        setResendSuccess(true);
        setTimeout(() => {
          setResendSuccess(false); // Reset message after 5 seconds
        }, 1000); // Changed to 20 seconds as per your comment
      } else {
        Alert.alert('Error', 'Failed to send OTP. Please try again.');
        setDisableResend(false);
        setTimer(0);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to send OTP. Please try again.');
      setDisableResend(false);
      setTimer(0);
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Set Up Your Password</Text>
        <View>
          <RedlineLogo height="29" width="101" />
        </View>
      </View>

      <KeyboardAvoidingView
        style={styles.contentContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        {!isKeyboardVisible && <ProfileIcon />}
        <View style={styles.inputSection}>
          <Text style={styles.label}>Enter OTP</Text>
          <View
            style={[
              styles.inputContainer,
              focusedField === 'otp' && styles.inputContainerFocused,
              otpError && styles.inputError,
            ]}>
            <TextInput
              style={styles.input}
              value={otp}
              onChangeText={handleOtpChange}
              placeholder="Enter OTP"
              placeholderTextColor="#666666"
              keyboardType="numeric"
              onFocus={() => handleFocus('otp')}
              onBlur={handleBlur}
              maxLength={6}
            />
          </View>
          {otpError ? <Text style={styles.errorText}>{otpError}</Text> : null}

          <Text style={styles.label}>New Password</Text>
          <View
            style={[
              styles.inputContainer,
              focusedField === 'password' && styles.inputContainerFocused,
              passwordError && styles.inputError,
            ]}>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={handlePasswordChange}
              placeholder="Enter your new password"
              placeholderTextColor="#666666"
              secureTextEntry
              onFocus={() => handleFocus('password')}
              onBlur={handleBlur}
            />
          </View>
          {passwordError ? (
            <Text style={styles.errorText}>{passwordError}</Text>
          ) : null}

          <Text style={styles.label}>Confirm Password</Text>
          <View
            style={[
              styles.inputContainer,
              focusedField === 'confirmPassword' &&
                styles.inputContainerFocused,
              confirmPasswordError && styles.inputError,
            ]}>
            <TextInput
              style={styles.input}
              value={confirmPassword}
              onChangeText={handleConfirmPasswordChange}
              placeholder="Confirm your new password"
              placeholderTextColor="#666666"
              secureTextEntry={!showPassword}
              onFocus={() => handleFocus('confirmPassword')}
              onBlur={handleBlur}
            />
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              style={styles.iconWrapper}>
              <AntDesign
                name="eye"
                size={20}
                color={showPassword ? '#fff' : '#787878'}
              />
            </TouchableOpacity>
          </View>
          {confirmPasswordError ? (
            <Text style={styles.errorText}>{confirmPasswordError}</Text>
          ) : null}
        </View>
        <View style={styles.inputSection}>
          <View style={styles.resendOtpContainer}>
            <Text style={styles.resendText}>Didn't get OTP? </Text>
            <TouchableOpacity
              disabled={resendLoading || disableResend}
              onPress={handleResendOtp}>
              <Text
                style={[styles.resendLink, disableResend && styles.signUpText]}>
                {resendLoading
                  ? 'Sending OTP...'
                  : resendSuccess
                  ? 'Otp Sent'
                  : disableResend
                  ? `Resend Otp in ${timer}s`
                  : 'Resend OTP'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.submitbtn]}
            onPress={handleSubmit}
            disabled={loading}>
            <Text style={styles.buttonText}>
              <Text style={styles.buttonText}>
                {loading ? 'Updating..' : 'Submit'}
              </Text>
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.signUpContainer}>
          <Text style={styles.signUpText}>Don't have an account? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
            <Text style={styles.signUpLink}>Sign up</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#090909',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 40,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 5,
  },
  logo: {
    width: 150,
    height: 40,
  },
  headerText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-SemiBold',

    marginLeft: 8,
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingBottom: 40,
  },
  inputSection: {
    marginBottom: 20,
    paddingHorizontal: 16,
  },
  inputOtpSection: {
    paddingHorizontal: 16,
  },
  label: {
    color: '#FFFFFF',
    fontSize: 14,
    marginBottom: 8,
    fontFamily: 'Inter_18pt-Medium',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#3A3A3C',
    borderRadius: 12,
    height: 56,
    padding: 8,
    backgroundColor: '#090909',
    marginBottom: 8,
  },
  inputContainerFocused: {
    borderColor: '#B40B0B',
    backgroundColor: '#151515',
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  buttonContainer: {
    paddingHorizontal: 16,
  },
  submitButton: {
    marginBottom: 16,
  },
  signUpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  signUpText: {
    color: '#8C8C8C',
    fontFamily: 'Inter_18pt-Regular',
    fontSize: 16,
  },
  signUpLink: {
    color: '#B40B0B',
    fontSize: 16,
    fontWeight: 'medium',
  },
  errorText: {
    color: '#E63946',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'left',
  },
  inputError: {
    borderColor: '#E63946',
  },
  resendOtpContainer: {
    flexDirection: 'row',
    marginLeft: 8,
    alignItems: 'center',
  },
  resendText: {
    fontFamily: 'Inter_18pt-Regular',
    color: '#8C8C8C',
    fontSize: 16,
  },
  resendLink: {
    color: '#B40B0B',
    fontSize: 16,
    fontWeight: '500',
  },
  iconWrapper: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: '#212121',
    borderWidth: 2,
    borderColor: '#2E2E2E',
    justifyContent: 'center',
    alignItems: 'center',
  },
  submitbtn: {
    height: 56,
    backgroundColor: '#B40B0B',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
    marginBottom: 16,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-SemiBold',
  },
});
