/* eslint-disable react/react-in-jsx-scope */
import {Image, View} from 'react-native';
import {StyleSheet} from 'react-native';
export default function ProfileIcon() {
  return (
    <View>
      <View style={style.container}>
        <View style={style.lineOne} />
        <View style={style.lineTwo}>
          <Image
            style={style.img}
            source={require('../assets/images/userprofile.png')}
          />
        </View>

        <View style={style.contentContainer} />
      </View>
    </View>
  );
}
const style = StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  lineOne: {
    height: 1,
    width: 83,
    backgroundColor: '#4c4848',
  },
  lineTwo: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  img: {height: 148, width: 148},
  contentContainer: {
    height: 1,
    width: 83,
    backgroundColor: '#4c4848',
  },
});
