import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Modal,
  Image,
} from 'react-native';

interface IncidentPhotoPopupProps {
  visible: boolean;
  onClose: () => void;
  onCapturePhoto: () => void;
}

const IncidentPhotoPopup: React.FC<IncidentPhotoPopupProps> = ({ visible, onClose, onCapturePhoto }) => {
  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="fade"
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={onClose}
          >
            <Text style={styles.closeButtonText}>×</Text>
          </TouchableOpacity>

          <View style={styles.contentContainer}>
          <View style={styles.topContent}>
              <Image
                source={require('../assets/images/bell-icon-popup.png')}
                style={styles.bellIcon}
                resizeMode="contain"
              />
              <Text style={styles.title}>Capture Incident Photos</Text>
              <Text style={styles.description}>
                  Please take photos of the incident to ensure proper documentation.{'\n'}
              </Text>
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.captureButton}
                onPress={onCapturePhoto}
              >
                <Text style={styles.captureButtonText}>Capture Photo</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: 358,
    height: 270,
    backgroundColor: '#090909',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#FFFFFF',
    padding: 0,
  },
  closeButton: {
    position: 'absolute',
    right: 16,
    top: 16,
    zIndex: 1,
    width: 30,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    fontSize: 32,
    color: '#FFFFFF',
    lineHeight: 32,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 24,
    paddingBottom: 32,
    paddingHorizontal: 16,
  },
  topContent: {
    alignItems: 'center',
    width: '100%',
  },
  bellIcon: {
    width: 54,
    height: 54,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    color: '#5A5A5A',
    textAlign: 'center',
    lineHeight: 22,
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
    marginTop: 'auto',
  },
  captureButton: {
    backgroundColor: '#B40B0B',
    width: 160,
    height: 44,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  captureButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
});

export default IncidentPhotoPopup;
