
import {StyleSheet} from 'react-native';

export const googlePlacesStyles = StyleSheet.create({
    textInput: {
        height: 56,
        color: '#FFFFFF',
        fontSize: 16,
        backgroundColor: 'transparent',
        borderWidth: 0,
        paddingHorizontal: 0,
      },
      container: {
        flex: 1,
        backgroundColor: 'transparent',
      },
      listView: {
        backgroundColor: '#151515',
        borderRadius: 8,
        position: 'absolute',
        top: '100%',
        left: 0,
        right: 0,
        borderWidth: 1,
        borderColor: '#242424',
        zIndex: 2,
        marginTop: 10,
      },
      row: {
        backgroundColor: '#151515',
        padding: 15,
      },
      separator: {
        height: 1,
        backgroundColor: '#333333',
      },
      description: {
        color: '#FFFFFF',
        fontSize: 16,
      },

      textInputs: {
        color: '#FFFFFF',
        fontSize: 16,
        height: 56,
        width: '100%',
        backgroundColor: 'transparent',
      },
});



