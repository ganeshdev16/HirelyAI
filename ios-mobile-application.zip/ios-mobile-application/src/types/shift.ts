export interface shiftData {
  jobID?: string;
  startTime: string;
  status: string;
  userID: string | null;
  coordinates: number[];
}
export interface JobData {
  id: string;
  propertyName: string;
  longitude: number;
  latitude: number;
}
