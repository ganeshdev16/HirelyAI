export interface FireWatchLog {
  startTime: Date;
  endTime: Date;
  name: string;
  note: string;
  isAllClear: boolean;
}
export interface FirewatchLogsModalProps {
  visible: boolean;
  onClose: () => void;
  handleNavigation: () => void;
}
