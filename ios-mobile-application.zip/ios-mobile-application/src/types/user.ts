export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

export interface UserProfile {
  bio: string;
  location: string;
  website?: string;
  preferences: {
    notifications: boolean;
    theme: 'light' | 'dark';
  };
}

export interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  user: User | null;
}

export interface UserState {
  profile: UserProfile | null;
  settings: Record<string, any>;
  loading: boolean;
  error: string | null;
}
