// useLocationTracker.js
import { useState, useEffect, useRef } from 'react';
import Geolocation from '@react-native-community/geolocation';
import { Alert, Platform, PermissionsAndroid } from 'react-native';

const useLocationTracker = (options = {}) => {
  const [coordinates, setCoordinates] = useState([]);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState(null);
  const watchId = useRef(null);
  const locationBuffer = useRef([]);
  const lastValidLocation = useRef(null);

  const defaultOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 3000,
    distanceFilter: 3, // minimum distance (in meters) to trigger location update
    accuracyThreshold: 20, // only accept locations with accuracy better than 20m
    smoothingFactor: 0.3, // for location smoothing (0-1, lower = more smoothing)
    bufferSize: 5, // number of recent locations to average
    ...options
  };

  // Request location permissions
  const requestLocationPermission = async () => {
    if (Platform.OS === 'ios') {
      return true; // iOS permissions handled in Info.plist
    }

    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Access Required',
          message: 'This app needs to access your location to track your movement',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  };

  // Start tracking location
  const startLocationTracking = async () => {
    const hasPermission = await requestLocationPermission();
    
    if (!hasPermission) {
      setError('Location permission denied');
      Alert.alert('Permission Required', 'Please enable location services to track your movement');
      return;
    }

    setIsTracking(true);
    setError(null);

    // Get initial position
    Geolocation.getCurrentPosition(
      (position) => {
        const newCoord = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          timestamp: position.timestamp
        };
        setCurrentLocation(newCoord);
        setCoordinates([newCoord]);
      },
      (err) => {
        console.error('Error getting initial position:', err);
        setError(err.message);
      },
      defaultOptions
    );

    // Start watching position
    watchId.current = Geolocation.watchPosition(
      (position) => {
        const rawCoord = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          timestamp: position.timestamp,
          accuracy: position.coords.accuracy,
          speed: position.coords.speed
        };

        // Filter out inaccurate readings
        if (position.coords.accuracy > defaultOptions.accuracyThreshold) {
          console.log(`Rejected location - Poor accuracy: ${position.coords.accuracy}m`);
          return;
        }

        // Add to buffer for smoothing
        locationBuffer.current.push(rawCoord);
        if (locationBuffer.current.length > defaultOptions.bufferSize) {
          locationBuffer.current.shift();
        }

        // Calculate smoothed location
        const smoothedCoord = smoothLocation(locationBuffer.current, lastValidLocation.current, defaultOptions.smoothingFactor);
        
        console.log('Raw location:', rawCoord);
        console.log('Smoothed location:', smoothedCoord);

        // Update current location with smoothed coordinates
        setCurrentLocation(smoothedCoord);
        lastValidLocation.current = smoothedCoord;
        
        // Only add to path if moved significantly
        setCoordinates(prev => {
          const lastCoord = prev[prev.length - 1];
          
          if (!lastCoord) {
            return [smoothedCoord];
          }
          
          const distance = calculateDistanceBetweenPoints(lastCoord, smoothedCoord);
          
          if (distance > defaultOptions.distanceFilter) {
            console.log(`Adding point - Distance: ${distance.toFixed(2)}m`);
            return [...prev, smoothedCoord];
          }
          
          return prev;
        });
      },
      (err) => {
        console.error('Location watch error:', err);
        setError(err.message);
      },
      defaultOptions
    );
  };

  // Stop tracking location
  const stopTracking = () => {
    if (watchId.current !== null) {
      Geolocation.clearWatch(watchId.current);
      watchId.current = null;
    }
    setIsTracking(false);
  };

  // Clear all coordinates
  const clearPath = () => {
    setCoordinates([]);
    locationBuffer.current = [];
  };

  // Reset everything
  const reset = () => {
    stopTracking();
    setCoordinates([]);
    setCurrentLocation(null);
    setError(null);
    locationBuffer.current = [];
    lastValidLocation.current = null;
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchId.current !== null) {
        Geolocation.clearWatch(watchId.current);
      }
    };
  }, []);

  return {
    coordinates,
    currentLocation,
    isTracking,
    error,
    startLocationTracking,
    stopTracking,
    clearPath,
    reset
  };
};

// Helper function to smooth location using weighted average
const smoothLocation = (locationBuffer, lastLocation, smoothingFactor) => {
  if (locationBuffer.length === 0) return null;
  
  // If we only have one location, return it
  if (locationBuffer.length === 1) {
    return locationBuffer[0];
  }
  
  // Calculate weighted average of recent locations
  let totalWeight = 0;
  let weightedLat = 0;
  let weightedLng = 0;
  
  locationBuffer.forEach((location, index) => {
    // Give more weight to recent locations
    const weight = (index + 1) / locationBuffer.length;
    totalWeight += weight;
    weightedLat += location.latitude * weight;
    weightedLng += location.longitude * weight;
  });
  
  const averagedLocation = {
    ...locationBuffer[locationBuffer.length - 1], // Keep other properties from latest
    latitude: weightedLat / totalWeight,
    longitude: weightedLng / totalWeight
  };
  
  // Apply smoothing with previous location if available
  if (lastLocation && smoothingFactor > 0) {
    return {
      ...averagedLocation,
      latitude: lastLocation.latitude + (averagedLocation.latitude - lastLocation.latitude) * smoothingFactor,
      longitude: lastLocation.longitude + (averagedLocation.longitude - lastLocation.longitude) * smoothingFactor
    };
  }
  
  return averagedLocation;
};

// Helper function to calculate distance between two points
const calculateDistanceBetweenPoints = (point1, point2) => {
  const R = 6371000; // Earth's radius in meters
  const dLat = (point2.latitude - point1.latitude) * Math.PI / 180;
  const dLon = (point2.longitude - point1.longitude) * Math.PI / 180;
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(point1.latitude * Math.PI / 180) * Math.cos(point2.latitude * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in meters
};

export default useLocationTracker;