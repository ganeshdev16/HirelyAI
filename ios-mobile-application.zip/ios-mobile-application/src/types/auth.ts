// Define types for our auth state
export interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  userId: string | null;
  role?: string;
  username: null | string;
}

// Define the response type from your auth service
export interface AuthResponse {
  access_token: string;
  refresh_token: string;
  user_id: string;
  username: string;
  role?: string;
}

export interface AuthContextType extends AuthState {
  setAuthTokens: (response: AuthResponse) => Promise<void>;
  signOut: () => Promise<void>;
  isAuthenticated: boolean;
  isLoading: boolean;
}
