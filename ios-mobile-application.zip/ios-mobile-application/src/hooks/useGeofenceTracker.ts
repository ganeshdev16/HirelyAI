import {useEffect, useCallback, useRef} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../store';
import {
  setError,
  setCurrentLocation,
  setLocationHistory,
} from '../store/slices/locationSlice';
import {useLocationTracker} from '../hooks/useLocationTracker';
import Geolocation from '@react-native-community/geolocation';
import {Dimensions} from 'react-native';

const screen = Dimensions.get('window');
const ASPECT_RATIO = screen.width / screen.height;
const LATITUDE_DELTA = 0.04;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const MIN_DISTANCE_THRESHOLD = 5; // 5 meter threshold for location history updates

export const useGeofenceTracker = (
  shiftId: string,
  _jobLocation?: {latitude: any; longitude: any},
) => {
  const {
    startLocationTracking,
    stopLocationTracking,
    checkIfInsideCircle,
    calculateDistance,
  } = useLocationTracker();
  const dispatch = useDispatch();

  const currentLocation = useSelector(
    (state: RootState) => state.location.currentLocation,
  );
  const isInsideCircle = useSelector(
    (state: RootState) => state.location.isInsideCircle,
  );
  const isTracking = useSelector(
    (state: RootState) => state.location.isTracking,
  );

  const watchIdRef = useRef<number | null>(null);
  const prevLocationHistoryRef = useRef<{
    latitude: number;
    longitude: number;
  } | null>(null);

  // Helper function to calculate distance between two coordinates using Haversine formula
  const haversineDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number,
  ): number => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in meters
  };

  const startWatchingLocation = useCallback(() => {
    console.log('Starting geofence tracking for shift:', shiftId);

    // Clear any existing watch
    if (watchIdRef.current !== null && Geolocation) {
      Geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }

    watchIdRef.current = Geolocation.watchPosition(
      position => {
        const {latitude, longitude, accuracy, altitude, heading, speed} =
          position.coords;
        const timestamp = Date.now();

        // Create location object
        const location = {
          latitude,
          longitude,
          accuracy,
          altitude,
          latitudeDelta: LATITUDE_DELTA,
          longitudeDelta: LONGITUDE_DELTA,
          heading,
          speed,
          timestamp,
        };

        // Always update current location for real-time tracking
        dispatch(setCurrentLocation(location));

        // Check distance from previous location history point
        if (prevLocationHistoryRef.current) {
          const distance = haversineDistance(
            prevLocationHistoryRef.current.latitude,
            prevLocationHistoryRef.current.longitude,
            latitude,
            longitude,
          );

          // Update location history only if moved at least 5 meters
          if (distance >= MIN_DISTANCE_THRESHOLD) {
            dispatch(setLocationHistory(location));

            // Update previous location history reference
            prevLocationHistoryRef.current = {
              latitude,
              longitude,
            };
          } else {
            console.log('Less than 5 meters moved - skipping history update');
          }
        } else {
          // First location reading - save it as previous and add to history

          prevLocationHistoryRef.current = {
            latitude,
            longitude,
          };
          dispatch(setLocationHistory(location));
        }
      },
      error => {
        dispatch(setError(`Geolocation error: ${error.message}`));
      },
      {
        distanceFilter: 5, // Get updates when device moves at least 1 meter
        enableHighAccuracy: true,
        maximumAge: 0,
      },
    );
  }, [dispatch, shiftId]);

  const stopWatchingLocation = useCallback(() => {
    if (watchIdRef.current !== null && Geolocation) {
      Geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
      console.log('Stopped watching location');
    }
    prevLocationHistoryRef.current = null; // Reset previous location
  }, []);

  useEffect(() => {
    if (shiftId) {
      startWatchingLocation();
    }

    return () => {
      stopWatchingLocation();
      stopLocationTracking();
    };
  }, [
    shiftId,
    startWatchingLocation,
    stopWatchingLocation,
    startLocationTracking,
    stopLocationTracking,
  ]);

  return {
    startWatchingLocation,
    stopWatchingLocation,
    startLocationTracking,
    stopLocationTracking,
    checkIfInsideCircle,
    calculateDistance,
    isTracking,
    currentLocation,
    isInsideCircle,
  };
};
