import React, {useEffect, useState} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  Alert,
  Keyboard,
} from 'react-native';
import type {RootStackScreenProps} from '../../types/navigation';
import {forgotPasswordOtp} from '../../services/api';
import RedlineLogo from '../../components/RedLineLogo';
import ProfileIcon from '../../components/ProfileIcon';

export default function ForgotPassword({
  navigation,
}: Readonly<RootStackScreenProps<'ForgotPassword'>>) {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [loading, setLoading] = useState(false);
  const [focusedField, setFocusedField] = useState<'email' | null>(null);
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setKeyboardVisible(true),
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setKeyboardVisible(false),
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const isValidEmail = (emailText: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(emailText);
  };

  const handleEmailChange = (text: string) => {
    setEmail(text);
    setEmailError('');
  };

  const handleSubmit = async () => {
    if (!email) {
      setEmailError('Please enter your email');
      return;
    }

    if (!isValidEmail(email)) {
      setEmailError('Please enter a valid email address');
      return;
    }

    setLoading(true);
    try {
      const response = await forgotPasswordOtp(email);

      // Check if the response is successful
      if (response && response.status) {
        navigation.navigate('OtpPasswordSetup', {email});
      } else if (response && response.message) {
        // Display backend error message
        if (response.message.toLowerCase().includes('not found')) {
          setEmailError('Account not found');
        } else if (response.message.toLowerCase().includes('invalid')) {
          setEmailError('Invalid email address');
        } else {
          setEmailError(response.message);
        }
      } else {
        setEmailError('Failed to send reset instructions. Please try again.');
      }
    } catch (error: any) {
      console.error('Forgot password error:', error);

      if (error.response) {
        switch (error.response.status) {
          case 200:
            navigation.navigate('OtpPasswordSetup', {email});
            break;
          case 400:
            setEmailError('Account not found');
            break;
          case 401:
            setEmailError('Invalid email address');
            break;
          case 404:
            setEmailError('Account not found');
            break;
          case 429:
            setEmailError('Too many attempts. Please try again later.');
            break;
          case 500:
            setEmailError('Attempt limit exceeded. Please try again later.');
            break;
          default:
            setEmailError(
              'Failed to send reset instructions. Please try again.',
            );
        }
      } else if (error.message?.includes('Network')) {
        Alert.alert('Error', 'Network error. Please check your connection.');
      } else {
        Alert.alert(
          'Error',
          'Failed to send reset instructions. Please try again.',
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Forgot Password</Text>
        <RedlineLogo height="29" width="101" />
      </View>

      <View style={styles.contentContainer}>
        {!isKeyboardVisible && (
          <>
            <ProfileIcon />
            <Text style={styles.description}>
              Enter your email address and we'll send you instructions to reset
              your password.
            </Text>
          </>
        )}

        <View style={styles.formContainer}>
          <Text style={styles.enterEmailText}>Email</Text>
          <View style={styles.inputGroup}>
            <View
              style={[
                styles.inputContainer,
                focusedField === 'email' && styles.inputContainerFocused,
                emailError && styles.inputError,
              ]}>
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={handleEmailChange}
                placeholder="Enter your email"
                placeholderTextColor="#666666"
                autoCapitalize="none"
                onFocus={() => setFocusedField('email')}
                onBlur={() => setFocusedField(null)}
              />
              {email.length > 0 && isValidEmail(email) && (
                <AntDesign
                  name="checkcircle"
                  size={20}
                  color="#4CAF50"
                  style={styles.checkIcon}
                />
              )}
            </View>
            {emailError ? (
              <Text style={styles.errorText}>{emailError}</Text>
            ) : null}
          </View>

          <TouchableOpacity
            style={[styles.submitbtn]}
            onPress={handleSubmit}
            disabled={loading}>
            <Text style={styles.buttonText}>
              {loading ? 'Updating..' : 'Submit'}
            </Text>
          </TouchableOpacity>

          <View style={styles.signUpContainer}>
            <Text style={styles.signUpText}>Don't have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
              <Text style={styles.signUpLink}>Sign up</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  // ... existing styles remain unchanged
  container: {
    flex: 1,
    backgroundColor: '#090909',
    justifyContent: 'flex-end',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 40,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 5,
  },
  logo: {
    width: 150,
    height: 40,
  },
  headerText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 20,
    justifyContent: 'center',
  },
  description: {
    color: '#FFFFFF',
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 35,
    textAlign: 'center',
    fontFamily: 'Inter_18pt-Regular',
  },
  formContainer: {
    width: '100%',
    marginBottom: 90,
  },
  enterEmailText: {
    color: '#FFFFFF',
    fontSize: 14,
    marginBottom: 8,
    fontFamily: 'Inter_18pt-Medium',
  },
  inputGroup: {
    marginBottom: 40,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#3A3A3C',
    borderRadius: 16,
    height: 56,
    padding: 16,
    backgroundColor: '#090909',
    marginBottom: 4,
  },
  inputContainerFocused: {
    backgroundColor: '#151515',
    borderColor: '#B40B0B',
  },
  inputError: {
    borderColor: '#B40B0B',
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
  },
  checkIcon: {
    marginRight: 8,
  },
  errorText: {
    color: '#B40B0B',
    fontSize: 12,
    marginTop: 4,
  },
  submitButton: {
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Inter_18pt-SemiBold',
  },
  signUpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  signUpText: {
    color: '#8C8C8C',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  signUpLink: {
    color: '#B40B0B',
    fontSize: 16,
    fontWeight: 'medium',
    fontFamily: 'Inter_18pt-Regular',
  },
  submitbtn: {
    height: 56,
    backgroundColor: '#B40B0B',
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'Inter_18pt-SemiBold',
  },
});
