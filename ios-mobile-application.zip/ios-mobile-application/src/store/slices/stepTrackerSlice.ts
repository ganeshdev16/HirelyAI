// src/redux/slices/stepTrackerSlice.ts
import {createSlice, PayloadAction} from '@reduxjs/toolkit';
import {StepTrackerState, SensorData} from '../../types/steps';

const initialState: StepTrackerState = {
  steps: 0,
  currentAcceleration: {x: 0, y: 0, z: 0, timestamp: 0},
  currentMagnitude: 0,
  averageLevel: 0,
  calibrationFactor: 1.0,
};

const stepTrackerSlice = createSlice({
  name: 'stepTracker',
  initialState,
  reducers: {
    incrementSteps: state => {
      state.steps += 1;
    },
    updateAcceleration: (state, action: PayloadAction<SensorData>) => {
      state.currentAcceleration = action.payload;
    },
    updateMagnitude: (state, action: PayloadAction<number>) => {
      state.currentMagnitude = action.payload;
    },
    updateAverageLevel: (state, action: PayloadAction<number>) => {
      state.averageLevel = action.payload;
    },
    resetSteps: state => {
      state.steps = 0;
    },
    setSteps: (state, action: PayloadAction<number>) => {
      state.steps = action.payload;
    },
    updateCalibrationFactor: (state, action: PayloadAction<number>) => {
      state.calibrationFactor = action.payload;
    },
  },
});

export const {
  incrementSteps,
  updateAcceleration,
  updateMagnitude,
  updateAverageLevel,
  resetSteps,
  setSteps,
  updateCalibrationFactor,
} = stepTrackerSlice.actions;

export default stepTrackerSlice.reducer;
