import React, {useState, useEffect} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import type {RootStackScreenProps} from '../../types/navigation';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {resendOtp, signIn, updateFCMToken} from '../../services/api';
import {useAuth} from '../../context/AuthContext';
import RedlineLogo from '../../components/RedLineLogo';
import messaging from '@react-native-firebase/messaging';

export default function SignIn({
  navigation,
}: Readonly<RootStackScreenProps<'SignIn'>>) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [focusedField, setFocusedField] = useState<'email' | 'password' | null>(
    null,
  );
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const {setAuthTokens} = useAuth();
  useEffect(() => {
    const loadSavedEmail = async () => {
      try {
        const savedEmail = await AsyncStorage.getItem('userEmail');
        if (savedEmail) {
          setEmail(savedEmail);
          setRememberMe(true);
        }
      } catch (error) {
        throw error;
      }
    };

    loadSavedEmail();
  }, []);

  const isValidEmail = (emailText: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(emailText);
  };
  const handleForgotPassword = () => {
    navigation.navigate('ForgotPassword');
  };

  const handleEmailChange = (text: string) => {
    setEmail(text);
    setEmailError('');
  };
  const handleResetOtp = async () => {
    try {
      const response = await resendOtp(email);
      if (response) {
        navigation.navigate('OtpVerification', {email: email});
      } else {
        Alert.alert('Error', 'Failed to send OTP. Please try again.');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to send OTP. Please try again.');
    }
  };

  const handleSignIn = async () => {
    setEmailError('');
    setPasswordError('');
    let hasError = false;

    if (!email) {
      setEmailError('Please enter your email');
      hasError = true;
    } else if (!isValidEmail(email)) {
      setEmailError('Please enter a valid email address');
      hasError = true;
    }

    if (!password) {
      setPasswordError('Please enter your password');
      hasError = true;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      hasError = true;
    }

    if (!hasError) {
      setIsLoading(true);
      try {
        const response = await signIn({
          email,
          password,
        });
        console.log(response.role);

        // Check if the response is successful
        if (response.status === 'success') {
          console.log(response);

          setAuthTokens({
            access_token: response.access_token,
            refresh_token: response.refresh_token,
            user_id: response.user_id,
            role: response.role,
            username: response.username,
          });
          // Save email if "Remember Me" is checked
          if (rememberMe) {
            await AsyncStorage.setItem('userEmail', email);
          } else {
            await AsyncStorage.removeItem('userEmail');
          }

          // Dispatch action to save credentials in Redux
          // dispatch(setCredentials({
          //   token: response.token,
          //   userId: response.userId,
          //   roles: response.roles,
          //   email: email,
          // }));
          // Role-based redirection

          if (response.role.includes('Manager')) {
            try {
              await messaging().deleteToken();

              const authStatus = await messaging().requestPermission({
                provisional: true,
              });

              if (
                authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
                authStatus === messaging.AuthorizationStatus.PROVISIONAL
              ) {
                const fcmToken = await messaging().getToken();

                await updateFCMToken({
                  email: email,
                  fcmToken: fcmToken,
                });

                messaging().onMessage(async remoteMessage => {
                  Alert.alert(
                    remoteMessage.notification?.title || 'New Message',
                    remoteMessage.notification?.body,
                    [{text: 'OK'}],
                  );
                });

                messaging().setBackgroundMessageHandler(async remoteMessage => {
                  console.log('Background message received:', remoteMessage);
                });

                navigation.replace('ManagerDashboard');
              } else {
                navigation.replace('ManagerDashboard');
              }
            } catch (fcmError) {
              console.error('FCM token handling failed:', fcmError);
              // Still navigate even if FCM fails
              navigation.replace('ManagerDashboard');
            }
          } else {
            navigation.navigate('JobList');
          }
          // navigation.navigate('JobList')
        } else if (response && response.message) {
          // Display backend error message
          if (response.message.includes('not found')) {
            setEmailError('Account not found');
          } else {
            setPasswordError(response.message);
          }
        } else {
          Alert.alert('Error', 'Failed to sign in. Please try again.');
        }
      } catch (error: any) {
        if (error.response) {
          switch (error.response.status) {
            case 401:
              setPasswordError('Invalid email or password');
              break;
            case 403:
              setPasswordError(
                'User is not confirmed. Please check your email and confirm your account.',
              );
              await handleResetOtp();
              break;
            case 404:
              setEmailError('Account not found');
              break;
            default:
              Alert.alert('Error', 'Failed to sign in. Please try again.');
          }
        } else {
          Alert.alert('Error', 'Network error. Please check your connection.');
        }
      } finally {
        setIsLoading(false);
      }
    }
  };
  // const textStyle = styles.headerTitle;

  // // Log the style object to the console
  // console.log('Text Style:', textStyle);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headertxtContainer}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.backButton}>
            <AntDesign name="left" size={20} color="#FFFFFF" />
          </TouchableOpacity>

          <Text style={styles.headerTitle}>Sign In</Text>
        </View>

        <RedlineLogo height="29" width="101" />
      </View>

      <View style={styles.form}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Email</Text>
          <View
            style={[
              styles.inputContainer,
              focusedField === 'email' ? styles.inputFocused : null,
              emailError ? styles.inputError : null,
            ]}>
            <TextInput
              style={[styles.input, styles.emailInput]}
              value={email}
              onChangeText={handleEmailChange}
              placeholder="Enter your email"
              placeholderTextColor="#666666"
              autoComplete="email"
              autoCapitalize="none"
              keyboardType="email-address"
              onFocus={() => setFocusedField('email')}
              onBlur={() => setFocusedField(null)}
            />
            {email.length > 0 && isValidEmail(email) && (
              <View style={styles.iconWrapper}>
                <AntDesign name="check" size={20} color="#787878" />
              </View>
            )}
          </View>
          {emailError ? (
            <Text style={styles.errorText}>{emailError}</Text>
          ) : null}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Password</Text>
          <View
            style={[
              styles.inputContainer,
              focusedField === 'password' ? styles.inputFocused : null,
              passwordError ? styles.inputError : null,
            ]}>
            <TextInput
              style={styles.input}
              placeholder="Enter your password"
              placeholderTextColor="#666"
              value={password}
              onChangeText={text => {
                setPassword(text);
                setPasswordError('');
              }}
              secureTextEntry={!showPassword}
              onFocus={() => setFocusedField('password')}
              onBlur={() => setFocusedField(null)}
            />
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              style={styles.iconWrapperpwd}>
              <AntDesign
                name="eye"
                size={20}
                color={showPassword ? '#fff' : '#787878'}
              />
            </TouchableOpacity>
          </View>
          {passwordError ? (
            <Text style={styles.errorText}>{passwordError}</Text>
          ) : null}
        </View>

        <View style={styles.rememberForgotContainer}>
          <TouchableOpacity
            style={styles.rememberContainer}
            onPress={() => setRememberMe(!rememberMe)}>
            <View style={[styles.checkbox]}>
              {rememberMe && <AntDesign name="check" size={18} color="white" />}
            </View>
            <Text style={styles.rememberText}>Remember Me</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.forgotButton}
            hitSlop={20}
            onPress={handleForgotPassword}>
            <Text style={styles.forgotPassword}>Forgot Password?</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={[styles.signInButton, isLoading && styles.disabledButton]}
          onPress={handleSignIn}
          disabled={isLoading}>
          {isLoading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.signInButtonText}>Sign In</Text>
          )}
        </TouchableOpacity>

        <View style={styles.signUpContainer}>
          <Text style={styles.signUpText}>Don't have an account? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
            <Text style={styles.signUpLink}>Sign up</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    display: 'flex',
    justifyContent: 'space-between',
    padding: 16,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 8,
  },
  headerTitle: {
    color: '#FFFFFF',
    marginVertical: 16,
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 16,
    fontFamily: 'Inter_18pt-SemiBold',
  },
  logo: {
    position: 'absolute',
    left: 245, //change
    top: 30,
    width: 112,
    height: 35,
    paddingVertical: 13,
    paddingHorizontal: 16,
  },
  form: {
    height: 434,
    rowGap: 24,
    // backgroundColor: 'red',
    width: '100%', // Ensure the form takes the full width
    padding: 16, // Add padding to the sides
    alignItems: 'center', // Align form fields to the left
  },
  inputGroup: {
    width: '100%', // Ensure input groups take the full width
  },
  label: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'medium',
    fontFamily: 'Inter_18pt-Medium',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    borderWidth: 1,
    height: 56,
    borderColor: '#6A6A6A',
    borderRadius: 16,
    backgroundColor: '#090909',
  },
  inputFocused: {
    borderColor: '#B40B0B',
    borderWidth: 1.5,
  },
  inputError: {
    borderColor: '#B40B0B',
    borderWidth: 1.5,
  },
  input: {
    flex: 1,
    padding: 16,
    fontSize: 16,
    fontWeight: 'medium',
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
  },
  emailInput: {
    flex: 1,
  },
  iconWrapper: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#2E2E2E',
    justifyContent: 'center',
    alignItems: 'center',
    right: 8,
  },
  iconWrapperpwd: {
    width: 30,
    height: 30,
    borderRadius: 24,
    backgroundColor: 'black',
    borderWidth: 2,
    borderColor: '#2E2E2E',
    justifyContent: 'center',
    alignItems: 'center',
    right: 8,
  },
  errorText: {
    color: '#B40B0B',
    fontSize: 12,
    marginTop: 4,
    fontFamily: 'Inter-Regular',
  },
  rememberForgotContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%', // Ensure the container takes the full width
  },
  rememberContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 28,
    height: 28,
    borderWidth: 1.5,
    borderColor: '#666666',
    borderRadius: 8,
    marginRight: 12,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
  },

  rememberText: {
    color: '#E5E5E5',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  forgotPassword: {
    color: '#5A5A5A',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Regular',
  },
  signInButton: {
    backgroundColor: '#B40B0B',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 32,
    height: 61,
    // width: 358,
    width: '100%',
  },
  disabledButton: {
    opacity: 0.7,
  },
  signInButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 18,
    fontFamily: 'Inter_18pt-SemiBold',
  },
  signUpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  signUpText: {
    color: '#8C8C8C',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
  },
  signUpLink: {
    color: '#B40B0B',
    fontSize: 16,
    fontFamily: 'Inter_18pt-Medium',
  },
  forgotButton: {
    right: 20,
  },
  headertxtContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
