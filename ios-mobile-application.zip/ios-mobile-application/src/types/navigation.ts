import type {StackScreenProps} from '@react-navigation/stack';

export type RootStackParamList = {
  Welcome: undefined;
  SignUp: undefined;
  SignIn: undefined;
  ClockIn: undefined;
  TestScreen: undefined;
  OtpPasswordSetup: {
    email: string;
  };
  JobList: undefined;
  ForgotPassword: undefined;
  SetupPassword: undefined;

  OtpVerification: {
    email: string;
  };
  Dashboard: undefined;
  Validation: undefined;
  LocationService: undefined;
  jobDetail: undefined;
  reportIncident: undefined;
  EmergencyOption: undefined;
  ManagerDashboard: undefined;
  EditJobDetail: {jobId?: string; page: string};
  Notification: undefined;
  RequestScreen: undefined;
  TermsAndConditions: undefined;
  PrivacyPolicy: undefined;
  FireWatchLogs: {shiftId: string};
};

export type RootStackScreenProps<T extends keyof RootStackParamList> =
  StackScreenProps<RootStackParamList, T>;
