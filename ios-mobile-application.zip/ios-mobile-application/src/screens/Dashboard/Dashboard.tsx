import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Alert,
  Animated,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import {StackNavigationProp} from '@react-navigation/stack';
import {RootStackParamList} from '../../types/navigation';
import {RouteProp} from '@react-navigation/native';
import {endSession, pdfGenerator} from '../../services/api';
// import GlobalSettingsModal from '../../components/LocationModal';
import {useDispatch, useSelector} from 'react-redux';
import {resetSteps} from '../../store/slices/stepTrackerSlice';
import {clearCurrentShiftId} from '../../store/slices/currentShiftSlice';
import {useAuth} from '../../context/AuthContext';

import {
  clearCurrentLocation,
  clearLocationHistory,
} from '../../store/slices/locationSlice';
import RedlineLogo from '../../components/RedLineLogo';
import {LocationData} from '../../types/location';

import {useSmoothLocation} from '../../hooks/useSmoothLocation';
import {clearJobId} from '../../store/slices/jobSlice';
type DashboardScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'Dashboard'
>;
type Props = {
  route: RouteProp<RootStackParamList, 'Dashboard'>;
  navigation: DashboardScreenNavigationProp;
};
import {RootState} from '../../store';

const Dashboard = ({navigation}: Props) => {
  const shiftId = useSelector((state: any) => state.currentShift.shiftId);
  const jobId = useSelector((state: RootState) => state.job.jobId);
  const {userId} = useAuth();

  const locationHistory = useSelector(
    (state: RootState) => state.location.locationHistory,
  );
  const selectIsInsideCircle = (state: RootState) =>
    state.location.isInsideCircle;

  const totalDistance = useSelector(
    (state: RootState) => state.location.totalDistance,
  );

  const isInside = useSelector(selectIsInsideCircle);
  useSmoothLocation(isInside);
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);

  const handlePanic = () => {
    navigation.navigate('EmergencyOption');
  };

  const handleEditJobNavigation = () => {
    navigation.navigate('EditJobDetail', {
      page: 'JobList',
    });
  };
  console.log('his', locationHistory);

  const captureStaticMapFromHistory = async (
    locsHistory: LocationData[],
    apiKey: string,
  ): Promise<string | null> => {
    try {
      if (!locsHistory || locsHistory.length === 0) {
        console.error('No location history points for map capture');
        return null;
      }

      // Use a size that fits the PDF content frame
      const size = '500x300';

      // Handle single location case
      if (locsHistory.length === 1) {
        const singleLocation = locsHistory[0];

        // Create URL for single location with marker
        const staticMapUrl =
          'https://maps.googleapis.com/maps/api/staticmap?' +
          `size=${size}&maptype=roadmap&` +
          `center=${singleLocation.latitude},${singleLocation.longitude}&` +
          'zoom=15&' +
          `markers=size:mid|color:blue|label:L|${singleLocation.latitude},${singleLocation.longitude}&` +
          'scale=1&' +
          `key=${apiKey}`;

        console.log('Fetching static map for single location');

        const response = await fetch(staticMapUrl);
        if (!response.ok) {
          throw new Error(
            `Google Maps API returned ${response.status}: ${response.statusText}`,
          );
        }

        const blob = await response.blob();

        return new Promise(resolve => {
          const reader = new FileReader();
          reader.readAsDataURL(blob);
          reader.onloadend = () => {
            const base64data = reader.result as string;
            console.log('Successfully captured map for single location');
            resolve(base64data);
          };
        });
      }

      // Handle multiple locations case (original logic)
      // Calculate the bounding box of all points to center the map properly
      let minLat = locsHistory[0].latitude;
      let maxLat = locsHistory[0].latitude;
      let minLng = locsHistory[0].longitude;
      let maxLng = locsHistory[0].longitude;

      locsHistory.forEach(point => {
        minLat = Math.min(minLat, point.latitude);
        maxLat = Math.max(maxLat, point.latitude);
        minLng = Math.min(minLng, point.longitude);
        maxLng = Math.max(maxLng, point.longitude);
      });

      // Use bounds parameter to ensure the whole route is visible
      const bounds = `${minLat},${minLng}|${maxLat},${maxLng}`;

      // Format path for Google Static Maps API with a thicker line
      const pathParam = 'path=color:0x0066FF|weight:8';

      // Create a properly formatted path string with all coordinates
      const pathPoints = locsHistory
        .map(loc => `${loc.latitude},${loc.longitude}`)
        .join('|');

      // Build the complete URL with path included
      const staticMapUrl =
        'https://maps.googleapis.com/maps/api/staticmap?' +
        `size=${size}&maptype=roadmap&` +
        `${pathParam}|${pathPoints}&` +
        `bounds=${bounds}&` +
        'scale=1&' +
        `key=${apiKey}`;

      console.log('Fetching static map with start and end markers');

      // Add a marker for the ending location
      const endLocation = locsHistory[locsHistory.length - 1];
      const endMarkerParam = `&markers=size:mid|color:red|label:E|${endLocation.latitude},${endLocation.longitude}`;

      // Add a marker for the starting point
      const startLocation = locsHistory[0];
      const startMarkerParam = `&markers=size:mid|color:green|label:S|${startLocation.latitude},${startLocation.longitude}`;

      const fullUrl = staticMapUrl + endMarkerParam + startMarkerParam;

      const response = await fetch(fullUrl);
      if (!response.ok) {
        throw new Error(
          `Google Maps API returned ${response.status}: ${response.status}`,
        );
      }

      const blob = await response.blob();

      return new Promise(resolve => {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const base64data = reader.result as string;
          console.log('Successfully captured map with S and E markers');
          resolve(base64data);
        };
      });
    } catch (error) {
      console.error('Static map capture failed:', error);
      if (error instanceof Error) {
        console.error('Error message:', error.message);
      }
      return null;
    }
  };
  console.log(locationHistory);

  const handleEndSession = async () => {
    setIsLoading(true);

    try {
      // First, capture the static map image
      let mapImage = null;
      try {
        const API_KEY = 'AIzaSyBPmUI0hbgP19R7hzF1yRmo4URTw7vjWpI'; // Replace with your actual API key
        console.log(
          `Capturing map from ${locationHistory.length} location points...`,
        );

        // Only try to capture map if we have location history
        if (locationHistory && locationHistory.length >= 1) {
          mapImage = await captureStaticMapFromHistory(
            locationHistory,
            API_KEY,
          );
          console.log('Map with route captured successfully');
        } else {
          console.warn('Not enough location history to create a route map');
        }
      } catch (mapError) {
        console.error('Error capturing map:', mapError);
        // Continue even if map capture fails
      }

      console.log(`Ending session for shiftId: ${shiftId}`);
      const endTime = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZone: 'America/New_York',
      });

      const response = await endSession(shiftId, endTime);

      if (response.message === 'success') {
        console.log('Session ended successfully, generating PDF...');
        try {
          // Log details being sent to PDF generator
          console.log(
            `Generating PDF with: shiftId=${shiftId}, jobId=${jobId}, totalDistance=${totalDistance}`,
          );
          console.log(`Map image available: ${mapImage !== null}`);

          await pdfGenerator(shiftId, jobId, mapImage, totalDistance, userId);
          console.log('PDF generated successfully');
        } catch (pdfError) {
          console.error('Error generating PDF:', pdfError);
          console.log(pdfError);
        }

        // Clear all data and navigate back to job list
        dispatch(resetSteps());
        dispatch(clearJobId());
        dispatch(clearCurrentShiftId());
        dispatch(clearCurrentLocation());
        dispatch(clearLocationHistory());

        navigation.reset({
          index: 0,
          routes: [{name: 'JobList'}],
        });
      } else {
        Alert.alert('Error', 'Failed to end session. Please try again.');
      }
    } catch (error) {
      console.error('Error ending session:', error);
      Alert.alert('Error', 'Something went wrong while ending the session.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleValidationStation = () => {
    navigation.navigate('Validation');
  };

  const handleNotification = () => {
    navigation.navigate('Notification');
  };
  return (
    <SafeAreaView style={styles.container}>
      {/* Logo Section */}
      <View style={styles.logoContainer}>
        <RedlineLogo height="29" width="101" />
      </View>
      {/* <Map/> */}
      {/* Dashboard and Bell Icon */}
      <View style={styles.titleContainer}>
        <Text style={styles.headerTitle}>Dashboard</Text>
        <TouchableOpacity onPress={handleNotification}>
          <Animated.Image
            source={require('../../assets/images/Bell-icon.png')}
            style={[styles.bellIcon]}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>

      {/* Menu Section */}
      <View style={styles.menuContainer}>
        <TouchableOpacity
          style={styles.menuItem}
          onPress={handleValidationStation}>
          <View style={styles.iconContainer}>
            <Image
              source={require('../../assets/images/validationStation.png')}
              style={styles.menuIcon}
            />
          </View>
          <Text style={styles.menuTitle}>Validation Station</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => {
            handleEditJobNavigation();
          }}>
          <View style={styles.iconContainer}>
            <Image
              source={require('../../assets/images/location.png')}
              style={styles.menuIcon}
            />
          </View>
          <Text style={styles.menuTitle}>Property Details</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        {/* End Session Button */}
        <TouchableOpacity
          disabled={isLoading}
          style={styles.endSessionButton}
          onPress={handleEndSession}>
          {isLoading ? (
            <ActivityIndicator color="black" size="small" />
          ) : (
            <Text style={styles.endSessionText}>End Session</Text>
          )}
        </TouchableOpacity>

        {/* Panic Button */}
        <View style={styles.panicContainer}>
          <TouchableOpacity onPress={handlePanic}>
            <Animated.View style={[styles.panicButton]}>
              <Image
                source={require('../../assets/images/PanicButton.png')}
                style={styles.panicIcon}
              />
            </Animated.View>
          </TouchableOpacity>
          <Text style={styles.panicText}>PANIC BUTTON</Text>
        </View>
      </View>
      {/* <GlobalSettingsModal /> */}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    paddingHorizontal: 16,
    // justifyContent: 'space-between',
  },
  logoContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginRight: 16,
    marginVertical: 16,
  },

  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 24,
    paddingHorizontal: 16,
    marginBottom: 60,
  },
  headerTitle: {
    width: 106,
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '600',
  },
  bellIcon: {
    width: 24,
    height: 24,
    tintColor: '#FFFFFF',
  },
  menuContainer: {
    gap: 16,
    marginBottom: 16,
    padding: 16,
  },
  menuItem: {
    flexDirection: 'row',
    backgroundColor: '#151515',
    borderRadius: 16,
    height: 100,
    alignItems: 'center',
    paddingHorizontal: 16,
    elevation: 4,
  },
  iconContainer: {
    borderRadius: 16,
    padding: 12,
    marginRight: 16,
  },
  menuIcon: {
    tintColor: '#FFFFFF',
  },
  menuTitle: {
    width: 212,
    fontFamily: 'Inter_18pt-SemiBold',
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '500',
  },
  footer: {
    alignItems: 'center',
    marginBottom: 24,
    padding: 16,
  },
  endSessionButton: {
    backgroundColor: '#FFFFFF',
    width: '100%',
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  endSessionText: {
    color: '#000000',
    fontSize: 18,
    width: 107,
    fontWeight: '600',
  },
  panicContainer: {
    alignItems: 'center',
  },
  panicButton: {
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
  },
  panicIcon: {
    width: 140,
    height: 140,
  },
  panicText: {
    color: '#5A5A5A',
    fontSize: 14,
    fontWeight: '400',
    textTransform: 'uppercase',
    marginTop: 16,
  },
});

export default Dashboard;
