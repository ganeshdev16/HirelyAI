import React, {useEffect} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import AppNavigator from './navigation/AppNavigator';
import {PaperProvider} from 'react-native-paper';
import {Provider} from 'react-redux';
import {store} from './store';
import {websocketService} from './services/websocketService';
import AuthProvider from './context/AuthContext';
import {navigationRef} from './services/NavigationService';
// test
// Import notification service setup
import {
  requestUserPermission,
  createNotificationChannel,
  listenForForegroundMessages,
  listenForNotificationEvents,
} from './services/NotificationService';

export default function App() {
  useEffect(() => {
    // Init push notifications (Notifee + FCM)
    requestUserPermission();
    createNotificationChannel();
    listenForForegroundMessages();
    listenForNotificationEvents(); // You can pass navigation if needed

    if (process.env.WEB_SOCKET_URI) {
      websocketService.init({
        url: 'wss://aldq43ovrj.execute-api.us-east-1.amazonaws.com/prod',
      });
    } else {
      console.error('WEB_SOCKET_URI environment variable is not set');
    }
  }, []);

  return (
    <Provider store={store}>
      <PaperProvider>
        <NavigationContainer ref={navigationRef}>
          <AuthProvider>
            <AppNavigator />
          </AuthProvider>
        </NavigationContainer>
      </PaperProvider>
    </Provider>
  );
}
