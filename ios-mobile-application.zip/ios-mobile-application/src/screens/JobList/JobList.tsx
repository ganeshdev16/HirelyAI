import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Platform,
  View,
  UIManager,
  LayoutAnimation,
  Alert,
} from 'react-native';
import {useStepTracker} from '../../hooks/useStepTracker';

import Feather from 'react-native-vector-icons/Feather';
import {Pressable, TouchableOpacity} from 'react-native';
import React, {useCallback, useEffect, useState} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {RootStackScreenProps} from '../../types/navigation';
import {Text} from 'react-native';
import {FlatList} from 'react-native-gesture-handler';
import CustomAlertModal from '../../components/CustomAlertModal';
import {ActivityIndicator, Checkbox} from 'react-native-paper';
import {EmptyComponent} from '../../components/EmptyJobComponent';
import ReportReminderManager from '../../screens/JobList/ReportReminderManager';
import notifee, {AndroidImportance} from '@notifee/react-native';

import {
  checkShiftStatus,
  deleteJobByManager,
  fetchAllJobLocations,
  fetchJobList,
  fetchTampaJobLocation,
  fetchNewJerseyJobLocation, // Add New Jersey API
  fetchFloridaJobLocation, // Add Florida API
  startShift,
  fetchNewJerseyLocation,
} from '../../services/api';

import {FormData} from '../../types/jobDetails';
import {useDispatch} from 'react-redux';
import {setCurrentShiftId} from '../../store/slices/currentShiftSlice';
import {useGeofenceTracker} from '../../hooks/useGeofenceTracker';
// import PushNotification from 'react-native-push-notification';
import {useLocationTracker} from '../../hooks/useLocationTracker';
import {useAuth} from '../../context/AuthContext';
import RedlineLogo from '../../components/RedLineLogo';
import Loader from '../../components/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {setSteps} from '../../store/slices/stepTrackerSlice';
import {setLocationHistoryData} from '../../store/slices/locationSlice';
import {useFocusEffect} from '@react-navigation/native';
import CustomJobListSettingsModal from '../../components/CusomJobListModal';
import {setJobId} from '../../store/slices/jobSlice';
import GlobalSettingsModal from '../../components/LocationModal';
import useLocationId from '../../hooks/useLocationId';
// import InfoModal from '../../components/InfoModal';

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

// Define tab types
type TabType = 'default' | 'tampa' | 'newjersey' | 'florida';

export default function ({
  navigation,
}: Readonly<RootStackScreenProps<'JobList'>>) {
  const [location, setLocation] = useState<FormData[]>([]);
  const [selectedlocation, setSelectedLocation] = useState<FormData>();
  const [isModalVisible, setModalVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [shiftId, setShiftId] = useState<string | null>(null);
  const [isinfoModalVisible, setIsinfoModalVisible] = useState(true);

  // Updated tab state management with useState
  const [currentTab, setCurrentTab] = useState<TabType>('default');

  const handleContinue = () => {
    setIsinfoModalVisible(false);
  };

  const [isStartShift, setIsStartShift] = useState(false);
  const dispatch = useDispatch();
  const {startLocationTracking} = useLocationTracker();
  const {startWatchingLocation} = useGeofenceTracker(shiftId || '', {
    latitude: selectedlocation?.latitude || 0,
    longitude: selectedlocation?.longitude || 0,
  });

  const {startTracking} = useStepTracker();

  const [locationToDelete, setLocationToDelete] = useState<string>();
  const {userId, role} = useAuth();
  const {locationId} = useLocationId(userId);
  console.log('CCC', userId);

  // Updated fetchLocations function to handle all tabs
  const fetchLocations = useCallback(async () => {
    setIsLoading(true);
    try {
      let result;

      switch (currentTab) {
        case 'tampa':
          result = await fetchTampaJobLocation();
          break;
        case 'newjersey':
          result = await fetchNewJerseyLocation();

          break;
        default:
          // Original logic for default tab
          if (userId == '68498a4853d04671772a5436') {
            //jake's user Id
            result = await fetchAllJobLocations();
          } else {
            result = await fetchJobList(locationId);
          }
          break;
      }

      setLocation(result?.data || []);
    } catch (error) {
      console.error('Error fetching job list:', error);
      setLocation([]);
    } finally {
      setIsLoading(false);
    }
  }, [locationId, currentTab]);

  useFocusEffect(
    useCallback(() => {
      fetchLocations();
    }, [fetchLocations]),
  );

  useEffect(() => {
    const initializeData = async () => {
      console.log('initializing data');
      setIsLoading(true);
      try {
        // First check if there's an active shift
        const shiftResponse = await checkShiftStatus(userId);
        console.log(shiftResponse);
        if (shiftResponse.isActive && shiftResponse.shiftData) {
          // If shift is active, update Redux and navigate to Dashboard
          dispatch(setCurrentShiftId(shiftResponse.shiftData.shiftId));
          setShiftId(shiftResponse.shiftData.shiftId);
          dispatch(setSteps(shiftResponse.shiftData.steps));
          dispatch(setLocationHistoryData(shiftResponse.shiftData.coordinates)); // Start tracking services
          dispatch(setJobId(shiftResponse.shiftData.jobId));
          startTracking();
          startLocationTracking({
            latitude: shiftResponse.shiftData.latitude,
            longitude: shiftResponse.shiftData.longitude,
          });
          startWatchingLocation();

          // Navigate to Dashboard
          navigation.navigate('Dashboard');
        } else {
          // If no active shift, fetch locations
          await fetchLocations();
        }
      } catch (error) {
        console.error('Error in initialization:', error);
      } finally {
        setIsLoading(false);
      }
    };

    initializeData();
  }, [
    dispatch,
    navigation,
    userId,
    startLocationTracking,
    startTracking,
    startWatchingLocation,
    fetchLocations,
  ]);

  // Tab switching handler using useState
  const handleTabSwitch = (tab: TabType) => {
    setCurrentTab(tab);
    setSelectedLocation(undefined); // Clear selection when switching tabs
  };

  // Get tab display name
  const getTabDisplayName = (tab: TabType) => {
    switch (tab) {
      case 'tampa':
        return 'Tampa Locations';
      case 'newjersey':
        return 'New Jersey Locations';
      default:
        return 'Location List';
    }
  };

  const handleCheckboxPress = async (id?: string | undefined) => {
    const selectedItem = location.find(item => item.id === id);

    // Toggle selection
    const isSelected = selectedlocation?.id === id;
    setSelectedLocation(isSelected ? undefined : selectedItem);
  };

  const handleDeletePress = (id?: string) => {
    setLocationToDelete(id);
    setModalVisible(true);
  };

  const handleDeleteConfirm = async () => {
    if (!locationToDelete) {
      return;
    }

    try {
      const response = await deleteJobByManager(locationToDelete);
      if (response.message === 'success') {
        if (Platform.OS === 'android') {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
        }
        setLocation(prevLocations =>
          prevLocations.filter(item => item.id !== locationToDelete),
        );
        setModalVisible(false);
      } else {
        Alert.alert('Error', 'Failed to delete the job');
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong while deleting the job');
    } finally {
      setLocationToDelete(undefined);
    }
  };

  const handleEditJobNavigation = (job_id?: string) => {
    if (job_id) {
      dispatch(setJobId(job_id));
      navigation.navigate('EditJobDetail', {
        page: 'JobList',
      });
    }
  };

  const addLocation = () => {
    navigation.navigate('jobDetail');
  };

  const handleStartShift = async () => {
    if (!selectedlocation) {
      return;
    }
    setIsStartShift(true);

    const isInside = await startLocationTracking({
      latitude: selectedlocation.latitude,
      longitude: selectedlocation.longitude,
    });
    try {
      if (isInside) {
        try {
          const timeOnly = new Date().toLocaleTimeString('en-US', {
            hour: '2-digit',
            timeZone: 'America/New_York',
            minute: '2-digit',
            hour12: true,
          });
          const payload = {
            jobID: selectedlocation.id,
            startTime: timeOnly,
            userID: userId,
            status: 'Active',
            coordinates: [
              selectedlocation.latitude ?? 0,
              selectedlocation.longitude ?? 0,
            ],
            images: [],
          };

          const response = await startShift(payload);
          console.log('shiftres', response);

          if (response.shiftId) {
            dispatch(setCurrentShiftId(response.shiftId));
            setShiftId(response.shiftId);
            startTracking();
            startLocationTracking({
              latitude: selectedlocation.latitude,
              longitude: selectedlocation.longitude,
              timestamp: Date.now(),
            });
            dispatch(setJobId(selectedlocation.id!));
            startWatchingLocation();
            await AsyncStorage.setItem('managerID', response.managerID);
            const storedManagerId = await AsyncStorage.getItem('managerID');
            console.log('Stored Manager ID:', storedManagerId);
            navigation.navigate('Dashboard');

            ReportReminderManager.initiateReportCheck({
              shift_id: response.shiftId,
              recepient_id: storedManagerId,
            }).catch(error =>
              console.error('Error initiating report check:', error),
            );
          }
        } catch (error) {
          console.error('Error starting shift:', error);
        }
      } else {
        console.log('out');
        await notifee.createChannel({
          id: 'smooth-location-channel',
          name: 'Location Alerts',
          description: 'Channel for location-based alerts',
          sound: 'default',
          importance: AndroidImportance.HIGH,
          vibration: true,
        });

        await notifee.displayNotification({
          title: 'Location Alert',
          body: 'You have moved outside the designated area!',
          android: {
            channelId: 'smooth-location-channel',
            smallIcon: 'ic_launcher',
            importance: AndroidImportance.HIGH,
            pressAction: {
              id: 'default',
            },
          },
        });
      }
    } catch (error) {
      Alert.alert('Something went wrong');
    } finally {
      setIsStartShift(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.loaderContainer}>
        <Loader text="Loading jobs..." />
      </SafeAreaView>
    );
  }

  return (
    <>
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={[styles.header, role === 'Guard' && styles.hedaerGuard]}>
          {role === 'Manager' && (
            <TouchableOpacity
              onPress={() =>
                navigation.reset({
                  index: 0,
                  routes: [{name: 'ManagerDashboard'}],
                })
              }
              style={styles.backButton}>
              <AntDesign name="left" size={20} color="#FFFFFF" />
            </TouchableOpacity>
          )}
          <RedlineLogo height="29" width="101" />
        </View>

        {userId === '68498a4853d04671772a5436' && (
          <View style={styles.tabContainer}>
            <TouchableOpacity
              onPress={() => handleTabSwitch('default')}
              style={[
                styles.tabButton,
                currentTab === 'default' && styles.activeTab,
              ]}>
              <Text
                style={[
                  styles.tabText,
                  currentTab === 'default' && styles.activeTabText,
                ]}>
                All
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => handleTabSwitch('tampa')}
              style={[
                styles.tabButton,
                currentTab === 'tampa' && styles.activeTab,
              ]}>
              <Text
                style={[
                  styles.tabText,
                  currentTab === 'tampa' && styles.activeTabText,
                ]}>
                Tampa
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => handleTabSwitch('newjersey')}
              style={[
                styles.tabButton,
                currentTab === 'newjersey' && styles.activeTab,
              ]}>
              <Text
                style={[
                  styles.tabText,
                  currentTab === 'newjersey' && styles.activeTabText,
                ]}>
                NJ
              </Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.addLocation}>
          <Text style={styles.locationLists}>Location List</Text>
          {role === 'Manager' && (
            <Pressable onPress={addLocation} style={styles.addLocationButton}>
              <AntDesign name="pluscircleo" color="white" size={23} />
            </Pressable>
          )}
        </View>

        <View style={styles.locationContainer}>
          <FlatList
            style={styles.flatlist}
            ListEmptyComponent={<EmptyComponent />}
            data={location}
            renderItem={({item}) => (
              <View style={styles.locationCard}>
                <Pressable
                  onPress={() => handleCheckboxPress(item?.id)}
                  style={styles.locationDetails}>
                  <View style={styles.selectLocation}>
                    <TouchableOpacity
                      onPress={() => handleCheckboxPress(item?.id)}
                      style={{
                        width: 24,
                        height: 24,
                        borderWidth: 2,
                        borderColor: '#242424',
                        borderRadius: 4,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor:
                          selectedlocation?.id === item.id
                            ? 'white'
                            : 'transparent',
                      }}>
                      {selectedlocation?.id === item.id && (
                        <AntDesign name="check" size={16} color="black" />
                      )}
                    </TouchableOpacity>
                    <Text style={styles.locationText}>{item.propertyName}</Text>
                  </View>
                  <View style={styles.buttonContainer}>
                    <TouchableOpacity
                      hitSlop={25}
                      onPress={() => {
                        handleEditJobNavigation(item.id);
                      }}>
                      <Feather name="edit" size={16} color="#bcbcbc" />
                    </TouchableOpacity>
                    {role === 'Manager' && currentTab === 'default' && (
                      <TouchableOpacity
                        onPress={() => handleDeletePress(item?.id)}>
                        <AntDesign name="delete" size={20} color="#b40b0b" />
                      </TouchableOpacity>
                    )}
                  </View>
                </Pressable>
              </View>
            )}
            keyExtractor={item => item.id as string}
          />
        </View>
        <TouchableOpacity
          disabled={isStartShift}
          onPress={() => handleStartShift()}
          style={styles.clockInButton}>
          {isStartShift ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text style={styles.clockInText}>Start Shift</Text>
          )}
        </TouchableOpacity>
      </SafeAreaView>
      <CustomAlertModal
        handleDelete={handleDeleteConfirm}
        isModalVisible={isModalVisible}
        setModalVisible={setModalVisible}
      />
    </>
  );
}

const styles = StyleSheet.create({
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'black',
  },
  container: {
    flex: 1,
  },
  header: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 18,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    columnGap: 10,
    paddingHorizontal: 10,
  },
  // Tab styles for 4 tabs
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#242424',
    alignItems: 'center',
    marginHorizontal: 2,
  },
  activeTab: {
    borderBottomColor: '#B40B0B',
  },
  tabText: {
    color: '#bcbcbc',
    fontSize: 14,
    fontFamily: 'Inter_18pt-Medium',
    fontWeight: '500',
    textAlign: 'center',
  },
  activeTabText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  locationContainer: {
    width: '100%',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  locationLists: {
    color: 'white',
    fontSize: 20,
    fontFamily: 'Inter_18pt-SemiBold',
    paddingHorizontal: 8,
    fontWeight: '600',
  },
  flatlist: {
    width: '100%',
    padding: 16,
    marginBottom: 20,
    backgroundColor: 'black',
  },
  locationCard: {
    height: 'auto',
    minHeight: 64,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    backgroundColor: '',
    color: '#fff',
    marginBottom: 10,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationDetails: {
    height: '100%',
    borderRadius: 10,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'black',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
  },
  buttonContainer: {
    gap: 8,
    flexDirection: 'row',
  },
  clockInButton: {
    alignSelf: 'center',
    zIndex: 20000,
    width: '90%',
    maxWidth: 448,
    backgroundColor: '#B40B0B',
    display: 'flex',
    justifyContent: 'center',
    height: 61,
    borderRadius: 16,
    bottom: 20,
  },
  clockInText: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontSize: 16,
    fontFamily: 'Inter_18pt-SemiBold',
    fontWeight: '600',
  },
  locationText: {
    color: '#fff',
    fontFamily: 'Inter_18pt-Medium',
    fontWeight: '500',
  },
  addLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'black',
    marginBottom: 16,
  },
  addLocationButton: {
    marginRight: 12,
  },
  selectLocation: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  hedaerGuard: {
    justifyContent: 'flex-end',
  },
});
