import React from 'react';
import {View, Text, Modal, StyleSheet, Pressable} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
interface Props {
  handleDelete: () => void;
  isModalVisible: boolean;
  setModalVisible: React.Dispatch<React.SetStateAction<boolean>>;
}
const CustomAlertModal = ({
  isModalVisible,
  setModalVisible,
  handleDelete,
}: Props) => {
  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  return (
    <Modal
      transparent={true}
      animationType="fade"
      visible={isModalVisible}
      onRequestClose={toggleModal}>
      <View style={styles.overlay}>
        <View style={styles.modalContainer}>
          {/* Header Icon */}
          <View style={styles.iconContainer}>
            <AntDesign name="delete" size={24} color="#fff" />
          </View>

          {/* Title */}
          <Text style={styles.title}>Are you sure?</Text>

          {/* Description */}
          <Text style={styles.description}>
            Do you really want to delete this location? This action cannot be
            undone.
          </Text>

          {/* Buttons */}
          <View style={styles.buttonContainer}>
            <Pressable
              style={[styles.button, styles.cancelButton]}
              onPress={toggleModal}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </Pressable>
            <Pressable
              style={[styles.button, styles.deleteButton]}
              onPress={() => {
                handleDelete();
                toggleModal();
                console.log('Location deleted!');
              }}>
              <Text style={styles.deleteButtonText}>Delete</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  openButton: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    backgroundColor: 'red',
    borderRadius: 8,
  },
  openButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    borderWidth: 1,
    borderColor: 'white',
    width: '85%',
    backgroundColor: 'black',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
  },
  iconContainer: {
    backgroundColor: 'red',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  trashIcon: {
    fontSize: 32,
    color: 'white',
  },
  title: {
    fontSize: 18,

    color: 'white',
    marginBottom: 8,
    fontFamily: 'Inter_18pt-SemiBold',
  },
  description: {
    fontSize: 14,
    color: 'gray',
    textAlign: 'center',
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    fontFamily: 'Inter_18pt-Regular',

    width: '100%',
  },
  button: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: 'white',
    fontFamily: 'Inter_18pt-SemiBold',
  },
  cancelButtonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: 'red',
  },
  deleteButtonText: {
    color: 'white',
    fontFamily: 'Inter_18pt-SemiBold',
  },
});

export default CustomAlertModal;
