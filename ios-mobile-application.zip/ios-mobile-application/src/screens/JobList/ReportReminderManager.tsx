import {checkingreport} from '../../services/api';

interface ReportReminderParams {
  shift_id: string;
  recepient_id: string | null;
}

class ReportReminderManager {
  static async initiateReportCheck(params: ReportReminderParams) {
    await new Promise(resolve => setTimeout(resolve, 60 * 60 * 1000));
    while (true) {
      const response = await checkingreport({
        shiftId: params.shift_id,
        managerId: params.recepient_id,
      });
      console.log('Lambda Response:', response);

      if (response && response.isReportFilled === true) {
        console.log('Report is filled. Stopping further calls.');
        break;
      } else {
        console.log('Report is not filled. Will retry in 2 minutes.');
      }

      await new Promise(resolve => setTimeout(resolve, 60 * 60 * 1000));
    }
  }
}

export default ReportReminderManager;
