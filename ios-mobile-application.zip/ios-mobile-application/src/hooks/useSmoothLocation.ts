import {useEffect, useRef, useCallback} from 'react';
import notifee, {AndroidImportance} from '@notifee/react-native';

export const useSmoothLocation = (isInside: boolean) => {
  const notificationSentRef = useRef(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const prevIsInsideRef = useRef<boolean | undefined>(undefined);

  const createLocationChannel = useCallback(async () => {
    try {
      await notifee.createChannel({
        id: 'smooth-location-channel',
        name: 'Location Alerts',
        description: 'Channel for location-based alerts',
        sound: 'default',
        importance: AndroidImportance.HIGH,
        vibration: true,
      });
    } catch (error) {
      console.error('Error creating location channel:', error);
    }
  }, []);

  const sendNotification = useCallback(async (message: string) => {
    await notifee.displayNotification({
      title: 'Location Alert',
      body: message,
      android: {
        channelId: 'smooth-location-channel',
        smallIcon: 'ic_launcher',
        importance: AndroidImportance.HIGH,
        pressAction: {
          id: 'default',
        },
      },
    });
  }, []);

  const sendOutsideNotification = useCallback(async () => {
    await sendNotification('You have moved outside the designated area!');
    console.log('Notification sent: User is outside the designated area');
  }, [sendNotification]);

  const sendInsideNotification = useCallback(async () => {
    await sendNotification('You are now inside the designated area!');
  }, [sendNotification]);

  useEffect(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    const run = async () => {
      await createLocationChannel();

      if (!isInside && !notificationSentRef.current) {
        await sendOutsideNotification();
        notificationSentRef.current = true;

        intervalRef.current = setInterval(() => {
          sendOutsideNotification();
        }, 15 * 50 * 1000); // 12.5 minutes
      } else if (isInside) {
        notificationSentRef.current = false;
      }

      if (prevIsInsideRef.current === false && isInside) {
        await sendInsideNotification();
      }

      prevIsInsideRef.current = isInside;
    };

    run();

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [
    isInside,
    createLocationChannel,
    sendOutsideNotification,
    sendInsideNotification,
  ]);

  const triggerNotificationManually = useCallback(async () => {
    if (!notificationSentRef.current) {
      await createLocationChannel();
      await sendNotification('You have moved outside the designated area!');
      notificationSentRef.current = true;
    }
  }, [createLocationChannel, sendNotification]);

  return {triggerNotificationManually};
};
