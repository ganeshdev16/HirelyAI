import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import {RootStackParamList} from '../../types/navigation';
import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ImageBackground,
  StyleSheet,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import RedlineLogo from '../../components/RedLineLogo';
type WelcomeScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'Welcome'
>;

const WelcomeScreen: React.FC = () => {
  const navigation = useNavigation<WelcomeScreenNavigationProp>();

  const handleSignIn = () => {
    navigation.navigate('SignIn');
  };

  const handleSignUp = () => {
    navigation.navigate('SignUp');
  };

  return (
    <>
      <StatusBar barStyle="light-content" />
      <ImageBackground
        source={require('../../assets/images/welcome-2.png')}
        style={styles.backgroundImage}>
        <SafeAreaView style={styles.container}>
          <View style={styles.content}>
            <View style={styles.logoSection}>
              <RedlineLogo height="69" width="245" />
              {/* <Text style={styles.description}>Lorem ipsum dolor sit </Text> */}
            </View>

            <View style={styles.buttonSection}>
              <TouchableOpacity
                style={styles.signInButton}
                onPress={handleSignIn}>
                <Text style={styles.signInText}>Sign In</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.signUpButton}
                onPress={handleSignUp}>
                <Text style={styles.signUpText}>Sign Up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </ImageBackground>
    </>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    backgroundColor: '#000000',
  },
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  logoSection: {
    position: 'absolute',
    top: 300,
    width: '100%',
    alignItems: 'center',
  },
  logo: {
    width: 270,
    height: 80,
    marginBottom: 12,
  },
  resizeMode: {
    resizeMode: 'contain',
  },
  description: {
    color: '#FFFFFF',
    fontSize: 16,
    opacity: 0.8,
    fontFamily: 'Inter-Regular',
    width: 270,
    textAlign: 'center',
    marginTop: 27,
  },
  buttonSection: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 48,
    paddingHorizontal: 16,
    width: '100%',
    gap: 16,
    top: 550,
  },
  signInButton: {
    width: 358,
    height: 61,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#FF0000',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  signInText: {
    color: '#B40B0B',
    fontSize: 18,
    fontWeight: '500',
    fontFamily: 'Inter_18pt-Regular',
  },
  signUpButton: {
    width: 358,
    height: 61,
    borderRadius: 10,
    backgroundColor: '#B21F1F',
    justifyContent: 'center',
    alignItems: 'center',
  },
  signUpText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '400',
    fontFamily: 'Inter_18pt-Regular',
  },
});

export default WelcomeScreen;
