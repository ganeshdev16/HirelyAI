import { NativeModules } from 'react-native';

interface LocationServicesManagerInterface {
  checkLocationStatus(): Promise<{ locationEnabled: boolean; hasPermission: boolean }>;
  requestLocationPermission(): Promise<boolean>;
  turnOnLocation(): Promise<{ locationEnabled: boolean; status: string }>;
}

const { LocationServicesManager } = NativeModules as { LocationServicesManager: LocationServicesManagerInterface };

const requestWithTimeout = async (promise: Promise<any>, timeoutMs: number) => {
  const timeoutPromise = new Promise(resolve => setTimeout(() => resolve('timeout'), timeoutMs));
  const result = await Promise.race([promise, timeoutPromise]);
  return result !== 'timeout' ? result : null;
};


export const checkLocationPermission = async (_navigation: any) => {
  try {
    console.log('Starting permission check...');

    const { hasPermission } = await LocationServicesManager.checkLocationStatus();
    if (!hasPermission) {
      const locationGranted = await requestWithTimeout(
        LocationServicesManager.requestLocationPermission(),
        1000
      );
      if (locationGranted) {
      }
      return locationGranted;
    }
  } catch (error) {
    console.error('Error:', error);
    return false;
  }
};

