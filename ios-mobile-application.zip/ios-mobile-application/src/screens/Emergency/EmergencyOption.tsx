import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  SafeAreaView,
  StatusBar,
  Animated,
  Linking,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {RootStackScreenProps} from '../../types/navigation';
import {emergency911CallAlert} from '../../services/api';
import GlobalSettingsModal from '../../components/LocationModal';
import {useSelector} from 'react-redux';
import {useSmoothLocation} from '../../hooks/useSmoothLocation';
import {useAuth} from '../../context/AuthContext';
import {RootState} from '../../store';
import RedlineLogo from '../../components/RedLineLogo';

export default function EmergencyOption({
  navigation,
}: Readonly<RootStackScreenProps<'EmergencyOption'>>) {
  const shiftId = useSelector((state: RootState) => state.currentShift.shiftId);
  const [managerID, setManagerId] = useState<string | null>(null);
  const selectIsInsideCircle = (state: any) => state.location.isInsideCircle;
  const isInside = useSelector(selectIsInsideCircle);
  useSmoothLocation(isInside);
  const {userId, username} = useAuth();
  console.log('shiftid', shiftId);

  useEffect(() => {
    const fetchManagerId = async () => {
      try {
        const storedManagerId = await AsyncStorage.getItem('managerID');
        if (storedManagerId) {
          setManagerId(storedManagerId);
          console.log('Retrieved Manager ID:', storedManagerId);
        }
      } catch (error) {
        console.error('Failed to retrieve managerId:', error);
      }
    };

    fetchManagerId();
  }, []);

  const handleCall911 = async () => {
    if (!managerID) {
      console.error('Manager ID not found!');
      return;
    }

    try {
      const response = await emergency911CallAlert({
        sender_id: userId as string,
        sender_name: capitalizeName(username as string),
        recepient_id: managerID,
        shift_id: shiftId as string,
        status: 'initiated',
      });

      console.log('DD', response);

      try {
        await Linking.openURL('tel:911');
        console.log('Calling 911...');
      } catch (callError) {
        console.error('Failed to initiate call:', callError);
      }
    } catch (error) {
      console.error('Error sending alert:', error);
      try {
        await Linking.openURL('tel:911');
        console.log('Calling 911...');
      } catch (callError) {
        console.error('Failed to initiate call:', callError);
      }
    }
  };

  const handleReportIncident = () => {
    navigation.navigate('reportIncident');
  };
  function capitalizeName(name: string) {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
  console.log('c', capitalizeName(username as string));

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Header Section */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          <AntDesign name="left" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <RedlineLogo height="29" width="101" />
      </View>
      <View>
        <Text style={styles.headerTitle}>Emergency Options</Text>
      </View>

      {/* Main Content Section */}
      <View style={styles.mainContent}>
        {/* Call 911 Button */}
        <View style={styles.call911Content}>
          <TouchableOpacity onPress={handleCall911}>
            <Animated.View style={[styles.call911Button]}>
              <Image
                source={require('../../assets/images/call-icon.png')}
                style={styles.call911Button}
              />
            </Animated.View>
          </TouchableOpacity>
          <Text style={styles.call911Text}>CALL 911</Text>
        </View>
        {/* Report Incident Card */}
        <View style={styles.reportContent}>
          <TouchableOpacity
            style={styles.reportIncidentCard}
            onPress={handleReportIncident}>
            <View style={styles.cardContent}>
              <Image
                source={require('../../assets/images/report-icon.png')}
                style={styles.reportIcon}
              />
              <View>
                <Text style={styles.cardTitle}>Report Incident</Text>
                <Text style={styles.cardSubtitle}>
                  Log the incident details for{'\n'}documentation
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      </View>
      {/* <GlobalSettingsModal /> */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 10,
  },
  headerContainer: {
    flexGrow: 1,
    paddingHorizontal: 10,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '600',
    lineHeight: 24,
    marginLeft: 16,
    fontFamily: 'Inter_18pt-SemiBold',

    marginBottom: 30,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderColor: '#242424',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 112,
    height: 35,
  },
  mainContent: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  call911Content: {
    marginTop: 35,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  call911Button: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 140,
    height: 140,
    marginBottom: 12,
    elevation: 6,
  },
  call911Text: {
    color: '#5A5A5A',
    fontSize: 14,
    fontWeight: '500',
    fontFamily: 'Inter_18pt-Regular',
  },
  reportContent: {
    marginTop: 30,
    width: '100%',
    alignItems: 'center',
  },
  reportIncidentCard: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: '#090909',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 4,
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  reportIcon: {
    width: 40,
    height: 40,
    marginRight: 16,
    tintColor: '#FFFFFF',
  },
  cardTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Inter_18pt-Medium',

    marginBottom: 4,
  },
  cardSubtitle: {
    color: '#5A5A5A',
    fontSize: 14,
    fontFamily: 'Inter_18pt-Regular',

    lineHeight: 20,
  },
});
